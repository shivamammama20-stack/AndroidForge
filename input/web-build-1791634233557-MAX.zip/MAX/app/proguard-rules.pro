# MAX release rules. Minification is disabled by default; add rules here if enabled.
