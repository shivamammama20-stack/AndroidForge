package com.max.assistant

import com.max.assistant.apps.AppInfo
import com.max.assistant.apps.AppMatcher
import com.max.assistant.brain.ConfirmationPolicy
import com.max.assistant.brain.RiskEngine
import com.max.assistant.briefing.BriefingComposer
import com.max.assistant.briefing.BriefingInputs
import com.max.assistant.contacts.ContactMatch
import com.max.assistant.contacts.ContactResolution
import com.max.assistant.contacts.ContactResolver
import com.max.assistant.context.PendingConfirmation
import com.max.assistant.core.RiskLevel
import com.max.assistant.intent.IntentDetector
import com.max.assistant.intent.IntentType
import com.max.assistant.news.NewsItem
import com.max.assistant.news.NewsFeed
import com.max.assistant.news.NewsRepository
import com.max.assistant.news.NewsResult
import com.max.assistant.news.RssParser
import com.max.assistant.settings.BriefingMode
import com.max.assistant.time.DurationParser
import com.max.assistant.time.TimeParseResult
import com.max.assistant.time.TimeParser
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

class IntentDetectorTest {
    private val d = IntentDetector()

    @Test fun openApp() {
        val i = d.detect("MAX, open WhatsApp.")
        assertEquals(IntentType.OPEN_APP, i.type); assertEquals("whatsapp", i.entities["app"])
    }
    @Test fun hinglishCall() {
        val i = d.detect("MAX, Rahul ko call karo.")
        assertEquals(IntentType.CALL, i.type); assertEquals("rahul", i.entities["contact"])
    }
    @Test fun followUpMessageUsesLastContact() {
        val i = d.detect("MAX, usko message bhejo.")
        assertEquals(IntentType.MESSAGE, i.type); assertEquals("__last__", i.entities["contact"])
    }
    @Test fun reminderHinglish() = assertEquals(IntentType.REMINDER, d.detect("MAX, kal subah 6 baje yaad dilana.").type)
    @Test fun weather() = assertEquals(IntentType.WEATHER, d.detect("MAX, aaj ka weather batao.").type)
    @Test fun currentAffairs() = assertEquals(IntentType.CURRENT_AFFAIRS, d.detect("MAX, aaj ke world current affairs batao.").type)
    @Test fun briefing() = assertEquals(IntentType.DAILY_BRIEFING, d.detect("MAX, give me my daily briefing.").type)
    @Test fun startBriefing() = assertEquals(IntentType.DAILY_BRIEFING, d.detect("Jarvis, start briefing").type)
    @Test fun briefingHinglish() = assertEquals(IntentType.DAILY_BRIEFING, d.detect("MAX, aaj ki briefing do.").type)
    @Test fun briefingShortMode() = assertEquals("SHORT", d.detect("MAX, tell me only the important news").entities["mode"])
    @Test fun explainSecondHeadline() {
        val i = d.detect("MAX, explain the second headline.")
        assertEquals(IntentType.BRIEFING_FOLLOWUP, i.type); assertEquals("2", i.entities["index"])
    }
    @Test fun skipSports() {
        val i = d.detect("skip sports")
        assertEquals(IntentType.BRIEFING_FOLLOWUP, i.type); assertEquals("sports", i.entities["category"])
    }
    @Test fun confirmations() {
        assertEquals(IntentType.CONFIRM_YES, d.detect("yes").type)
        assertEquals(IntentType.CONFIRM_NO, d.detect("cancel").type)
    }
    @Test fun unrelatedSpeechIsNotConfirmation() = assertEquals(IntentType.CONVERSATION, d.detect("yes please tell me a joke about cats").type)
}

class TimeParserTest {
    // Fixed instant: 2026-10-10 10:00 in Asia/Kolkata. Nothing is hardcoded to India in the parser itself.
    private val zone = ZoneId.of("Asia/Kolkata")
    private val clock = Clock.fixed(ZonedDateTime.of(2026, 10, 10, 10, 0, 0, 0, zone).toInstant(), zone)
    private val p = TimeParser(clock)

    private fun at(s: String) = (p.parse(s) as TimeParseResult.At).time

    @Test fun tomorrowMorning6() {
        val t = at("kal subah 6 baje")
        assertEquals(11, t.dayOfMonth); assertEquals(6, t.hour); assertEquals(0, t.minute)
    }
    @Test fun relativeMinutes() = assertEquals(10, at("in 10 minutes").minute)
    @Test fun tonight8() = assertEquals(20, at("tonight 8 pm").hour)
    @Test fun sixBajeWithoutPeriodIsAmbiguous() = assertTrue(p.parse("kal 6 baje") is TimeParseResult.Ambiguous)
    @Test fun noTimeAskedBack() = assertTrue(p.parse("tomorrow") is TimeParseResult.Ambiguous)
    @Test fun pastTimeTodayRollsToTomorrow() = assertEquals(11, at("9 am").dayOfMonth)
    @Test fun usesInjectedZoneNotIndia() {
        val ny = ZoneId.of("America/New_York")
        val c = Clock.fixed(ZonedDateTime.of(2026, 3, 1, 8, 0, 0, 0, ny).toInstant(), ny)
        val t = (TimeParser(c).parse("tomorrow 7 am") as TimeParseResult.At).time
        assertEquals(ny, t.zone); assertEquals(2, t.dayOfMonth)
    }
    @Test fun timerDuration() {
        assertEquals(330, DurationParser.parseSeconds("5 minutes 30 seconds"))
        assertEquals(5400, DurationParser.parseSeconds("1 hour 30 minutes"))
        assertNull(DurationParser.parseSeconds("a while"))
    }
}

class RiskEngineTest {
    private val r = RiskEngine { setOf("com.bank.app") }
    @Test fun lowToolNeedsNoConfirm() {
        val d = r.assess("device_info", RiskLevel.LOW, emptyMap(), ConfirmationPolicy.ASK_MEDIUM_AND_UP)
        assertFalse(d.needsConfirmation)
    }
    @Test fun callIsHighAndConfirmed() {
        val d = r.assess("call_contact", RiskLevel.MEDIUM, emptyMap())
        assertEquals(RiskLevel.HIGH, d.level); assertTrue(d.needsConfirmation); assertFalse(d.needsAuthentication)
    }
    @Test fun protectedAppIsSensitiveAndNeedsAuth() {
        val d = r.assess("open_app", RiskLevel.LOW, mapOf("package" to "com.bank.app"))
        assertEquals(RiskLevel.SENSITIVE, d.level); assertTrue(d.needsAuthentication)
    }
    @Test fun notificationsAreSensitive() = assertTrue(r.assess("read_notifications", RiskLevel.LOW, emptyMap()).needsAuthentication)
    @Test fun riskDependsOnOperationNotWording() {
        // Same tool, different arguments -> different risk.
        assertEquals(RiskLevel.LOW, r.assess("open_app", RiskLevel.LOW, mapOf("package" to "com.x")).level)
    }
    @Test fun staleConfirmationExpires() {
        val p = PendingConfirmation("call_contact", emptyMap(), "x", createdAtMs = 0, requiresBiometric = false)
        assertTrue(p.isExpired(31_000)); assertFalse(p.isExpired(10_000))
    }
}

class MatchingTest {
    private val apps = listOf(AppInfo("WhatsApp", "com.whatsapp"), AppInfo("YouTube", "com.google.android.youtube"), AppInfo("YouTube Music", "com.google.android.apps.youtube.music"))
    @Test fun exactWins() = assertEquals(listOf("YouTube"), AppMatcher.rank("youtube", apps).map { it.label })
    @Test fun aliasWorks() = assertEquals("WhatsApp", AppMatcher.rank("wa", apps).first().label)
    @Test fun multipleMatches() = assertEquals(2, AppMatcher.rank("you", apps).size)
    @Test fun missing() = assertTrue(AppMatcher.rank("zzz", apps).isEmpty())

    @Test fun duplicateContactRowsCollapse() {
        val r = ContactResolver.resolve(listOf(ContactMatch("Rahul", "+91 98765 43210"), ContactMatch("Rahul", "9876543210")))
        assertTrue(r is ContactResolution.Single)
    }
    @Test fun differentRahulsNeedClarification() {
        val r = ContactResolver.resolve(listOf(ContactMatch("Rahul Sharma", "1111111111"), ContactMatch("Rahul Verma", "2222222222")))
        assertTrue(r is ContactResolution.Multiple)
    }
    @Test fun noContact() = assertTrue(ContactResolver.resolve(emptyList()) is ContactResolution.None)
}

class NewsAndBriefingTest {
    private val now = Instant.parse("2026-10-10T05:00:00Z")
    private fun rss(vararg items: Triple<String, String, String>) =
        "<rss><channel>" + items.joinToString("") { "<item><title>${it.first}</title><link>${it.second}</link><pubDate>${it.third}</pubDate><description>&lt;b&gt;sum&lt;/b&gt;</description></item>" } + "</channel></rss>"

    @Test fun parsesRss() {
        val l = RssParser.parse(rss(Triple("A", "http://a", "Sat, 10 Oct 2026 04:00:00 GMT")), "Src", "world")
        assertEquals(1, l.size); assertEquals("A", l[0].title); assertNotNull(l[0].publishedAt)
    }
    @Test fun rejectsDoctypeXxe() {
        val bad = "<!DOCTYPE x [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><rss><channel><item><title>&e;</title><link>l</link></item></channel></rss>"
        val r = runCatching { RssParser.parse(bad, "s", "c") }
        assertTrue(r.isFailure)
    }
    @Test fun staleAndUndatedAreDropped() = runBlocking {
        val xml = rss(
            Triple("Fresh", "http://f", "Sat, 10 Oct 2026 03:00:00 GMT"),
            Triple("Old", "http://o", "Mon, 01 Jan 2024 03:00:00 GMT"),
            Triple("NoDate", "http://n", ""),
        )
        val repo = NewsRepository(listOf(NewsFeed("world", "S", "u")), nowProvider = { now }, fetcher = { xml })
        val r = repo.fetch(listOf("world"))
        assertEquals(listOf("Fresh"), r.items.map { it.title }); assertEquals(2, r.skippedUndatedOrStale)
    }
    @Test fun failedFeedIsReportedNotInvented() = runBlocking {
        val repo = NewsRepository(listOf(NewsFeed("world", "S", "u")), nowProvider = { now }, fetcher = { throw java.io.IOException("down") })
        val r = repo.fetch(listOf("world"))
        assertTrue(r.items.isEmpty()); assertTrue(r.failures.containsKey("world"))
    }
    @Test fun dedupe() {
        val a = NewsItem("Same Story!", "u1", "A", "world", now, "")
        val b = NewsItem("same story", "u2", "B", "india", now, "")
        assertEquals(1, NewsRepository.dedupe(listOf(a, b)).size)
    }

    private fun item(t: String, c: String) = NewsItem(t, "http://$t", "Src", c, now, "summary")
    private val zoned = ZonedDateTime.ofInstant(now, ZoneId.of("UTC"))
    private fun inputs(items: List<NewsItem>) = BriefingInputs(zoned, null, "Weather unavailable", null, "Calendar skipped", emptyList(), NewsResult(items, emptyMap(), 0), null)
    private val all = setOf("world", "india", "sports", "technology")
    private val items = listOf(item("w1", "world"), item("w2", "world"), item("i1", "india"), item("s1", "sports"), item("t1", "technology"))

    @Test fun shortModeOnePerCategory() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.SHORT, all)
        assertEquals(1, b.sections.first { it.title == "World" }.items.size)
    }
    @Test fun normalModeTwoPerCategory() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all)
        assertEquals(2, b.sections.first { it.title == "World" }.items.size)
    }
    @Test fun emptyCategoriesAreSkipped() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all + "health")
        assertTrue(b.sections.none { it.title == "Health" })
    }
    @Test fun skipExcludesCategory() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all, excluded = setOf("sports"))
        assertTrue(b.sections.none { it.title == "Sports" })
    }
    @Test fun onlyTechnology() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all, only = "technology")
        assertEquals(listOf("Technology & AI"), b.sections.map { it.title })
    }
    @Test fun missingDataProducesNotesNotFakeSections() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all)
        assertTrue(b.sections.none { it.title == "Weather" || it.title == "Calendar" })
        assertTrue(b.notes.any { it.contains("Weather") }); assertTrue(b.notes.any { it.contains("Calendar") })
    }
    @Test fun headlinesOrderMatchesDisplayForFollowUps() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all)
        assertEquals("w2", b.headlines[1].title)
    }
    @Test fun speechHasNoUrls() {
        val b = BriefingComposer.compose(inputs(items), BriefingMode.NORMAL, all)
        assertFalse(BriefingComposer.toSpeech(b, now).contains("http"))
    }
}
