package com.max.assistant.time

import java.time.Clock
import java.time.DayOfWeek
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.TemporalAdjusters

sealed class TimeParseResult {
    data class At(val time: ZonedDateTime) : TimeParseResult()
    /** Something was understood but is not precise enough; ask the user. */
    data class Ambiguous(val question: String) : TimeParseResult()
    object None : TimeParseResult()
}

/**
 * Interprets English/Hinglish relative date-times using the *device* timezone (injected Clock).
 * Pure Kotlin so it is unit-testable.
 */
class TimeParser(private val clock: Clock) {

    private val zone: ZoneId get() = clock.zone
    private fun now(): ZonedDateTime = ZonedDateTime.now(clock)

    fun parse(textRaw: String): TimeParseResult {
        val text = textRaw.lowercase().trim()

        // "in 10 minutes" / "10 minute baad/mein" / "in 2 hours"
        Regex("""(?:in\s+)?(\d{1,3})\s*(minutes?|mins?|min|minute|hours?|hrs?|ghante|ghanta|ghanta|minat|minute)\s*(?:baad|mein|me|later)?""")
            .find(text)?.let { m ->
                val relativeHint = text.contains("in ") || text.contains("baad") || text.contains("later") ||
                    text.contains("mein") || text.endsWith(m.value.trim())
                if (relativeHint && !text.contains(" baje") && !Regex("""\d\s*(am|pm)""").containsMatchIn(text)) {
                    val n = m.groupValues[1].toLong()
                    val unit = m.groupValues[2]
                    val dur = if (unit.startsWith("h") || unit.startsWith("ghant")) Duration.ofHours(n) else Duration.ofMinutes(n)
                    return TimeParseResult.At(now().plus(dur).withSecond(0).withNano(0))
                }
            }

        val date = parseDate(text)
        val time = parseTimeOfDay(text)

        if (time == null) {
            return if (date != null) TimeParseResult.Ambiguous("What time should I set it for?") else TimeParseResult.None
        }
        if (time.ambiguousMeridiem) {
            return TimeParseResult.Ambiguous("Do you mean ${time.hour12}:${"%02d".format(time.minute)} AM or PM?")
        }
        var d = date ?: now().toLocalDate()
        var candidate = ZonedDateTime.of(LocalDateTime.of(d, LocalTime.of(time.hour24, time.minute)), zone)
        // No explicit date and the time already passed today -> next occurrence tomorrow.
        if (date == null && !candidate.isAfter(now())) {
            d = d.plusDays(1)
            candidate = ZonedDateTime.of(LocalDateTime.of(d, LocalTime.of(time.hour24, time.minute)), zone)
        }
        return TimeParseResult.At(candidate)
    }

    private fun parseDate(t: String): LocalDate? {
        val today = now().toLocalDate()
        return when {
            Regex("""\b(day after tomorrow|parso)\b""").containsMatchIn(t) -> today.plusDays(2)
            Regex("""\b(tomorrow|kal|tmrw)\b""").containsMatchIn(t) -> today.plusDays(1)
            Regex("""\b(today|aaj|tonight)\b""").containsMatchIn(t) -> today
            Regex("""\bnext week\b|\bagle hafte\b""").containsMatchIn(t) ->
                today.with(TemporalAdjusters.next(DayOfWeek.MONDAY))
            else -> {
                val days = mapOf(
                    "monday" to DayOfWeek.MONDAY, "tuesday" to DayOfWeek.TUESDAY, "wednesday" to DayOfWeek.WEDNESDAY,
                    "thursday" to DayOfWeek.THURSDAY, "friday" to DayOfWeek.FRIDAY, "saturday" to DayOfWeek.SATURDAY,
                    "sunday" to DayOfWeek.SUNDAY,
                )
                days.entries.firstOrNull { Regex("""\b${it.key}\b""").containsMatchIn(t) }
                    ?.let { today.with(TemporalAdjusters.next(it.value)) }
            }
        }
    }

    private data class Tod(val hour24: Int, val minute: Int, val ambiguousMeridiem: Boolean, val hour12: Int)

    private fun parseTimeOfDay(t: String): Tod? {
        val m = Regex("""\b(\d{1,2})(?::(\d{2}))?\s*(am|pm|baje|bje|o'clock)?""").findAll(t)
            .firstOrNull { it.groupValues[3].isNotEmpty() || it.groupValues[2].isNotEmpty() || t.contains("at ${it.groupValues[1]}") }
            ?: return null
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        if (h > 24 || min > 59) return null
        val suffix = m.groupValues[3]
        val morning = Regex("""\b(morning|subah|subha|savere|am)\b""").containsMatchIn(t)
        val afternoon = Regex("""\b(afternoon|dopahar|dophar)\b""").containsMatchIn(t)
        val evening = Regex("""\b(evening|shaam|sham|night|raat|tonight)\b""").containsMatchIn(t)
        return when {
            h >= 13 -> Tod(h % 24, min, false, h - 12)
            suffix == "pm" -> Tod(if (h == 12) 12 else h + 12, min, false, h)
            suffix == "am" -> Tod(if (h == 12) 0 else h, min, false, h)
            morning -> Tod(if (h == 12) 0 else h, min, false, h)
            afternoon -> Tod(if (h < 12) h + 12 else h, min, false, h)
            evening -> Tod(if (h < 12) h + 12 else h, min, false, h)
            h == 0 -> Tod(0, min, false, 12)
            else -> Tod(h, min, true, h) // e.g. "6 baje" with no period -> ask
        }
    }
}
