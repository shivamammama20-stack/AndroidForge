package com.max.assistant.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.max.assistant.brain.ConfirmationPolicy
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "max_settings")

enum class BriefingMode { SHORT, NORMAL, DETAILED }

data class AppSettings(
    val confirmationPolicy: ConfirmationPolicy = ConfirmationPolicy.ASK_MEDIUM_AND_UP,
    val ttsRate: Float = 1.0f,
    /** BCP-47 tag, e.g. "en-IN", "hi-IN", "en-US". */
    val speechLanguage: String = "en-IN",
    val speakResponses: Boolean = true,
    val memoryEnabled: Boolean = true,
    val storeConversationHistory: Boolean = true,
    val offlineOnly: Boolean = false,
    val weatherPlace: String = "",
    val aiBaseUrl: String = "https://api.openai.com/v1",
    val aiModel: String = "",
    val briefingMode: BriefingMode = BriefingMode.NORMAL,
    val briefingCategories: Set<String> = setOf("world", "india", "business", "technology", "science", "sports", "health", "entertainment"),
    val quietStartHour: Int = 22,
    val quietEndHour: Int = 7,
    val protectedPackages: Set<String> = emptySet(),
    /** entries look like "Name|TRUSTED" */
    val trustedUsers: Set<String> = emptySet(),
    val privacyMode: Boolean = false,
    val reduceAnimations: Boolean = false,
)

class SettingsRepository(private val context: Context) {

    private object K {
        val confirm = stringPreferencesKey("confirm_policy")
        val rate = floatPreferencesKey("tts_rate")
        val lang = stringPreferencesKey("speech_lang")
        val speak = booleanPreferencesKey("speak_responses")
        val memory = booleanPreferencesKey("memory_enabled")
        val history = booleanPreferencesKey("store_history")
        val offline = booleanPreferencesKey("offline_only")
        val place = stringPreferencesKey("weather_place")
        val aiUrl = stringPreferencesKey("ai_base_url")
        val aiModel = stringPreferencesKey("ai_model")
        val bMode = stringPreferencesKey("briefing_mode")
        val bCats = stringSetPreferencesKey("briefing_categories")
        val qStart = intPreferencesKey("quiet_start")
        val qEnd = intPreferencesKey("quiet_end")
        val prot = stringSetPreferencesKey("protected_packages")
        val trusted = stringSetPreferencesKey("trusted_users")
        val privacy = booleanPreferencesKey("privacy_mode")
        val anim = booleanPreferencesKey("reduce_animations")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p -> p.toSettings() }

    suspend fun current(): AppSettings = settings.first()

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            confirmationPolicy = this[K.confirm]?.let { runCatching { ConfirmationPolicy.valueOf(it) }.getOrNull() } ?: d.confirmationPolicy,
            ttsRate = this[K.rate] ?: d.ttsRate,
            speechLanguage = this[K.lang] ?: d.speechLanguage,
            speakResponses = this[K.speak] ?: d.speakResponses,
            memoryEnabled = this[K.memory] ?: d.memoryEnabled,
            storeConversationHistory = this[K.history] ?: d.storeConversationHistory,
            offlineOnly = this[K.offline] ?: d.offlineOnly,
            weatherPlace = this[K.place] ?: d.weatherPlace,
            aiBaseUrl = this[K.aiUrl] ?: d.aiBaseUrl,
            aiModel = this[K.aiModel] ?: d.aiModel,
            briefingMode = this[K.bMode]?.let { runCatching { BriefingMode.valueOf(it) }.getOrNull() } ?: d.briefingMode,
            briefingCategories = this[K.bCats] ?: d.briefingCategories,
            quietStartHour = this[K.qStart] ?: d.quietStartHour,
            quietEndHour = this[K.qEnd] ?: d.quietEndHour,
            protectedPackages = this[K.prot] ?: d.protectedPackages,
            trustedUsers = this[K.trusted] ?: d.trustedUsers,
            privacyMode = this[K.privacy] ?: d.privacyMode,
            reduceAnimations = this[K.anim] ?: d.reduceAnimations,
        )
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p ->
            val n = transform(p.toSettings())
            p[K.confirm] = n.confirmationPolicy.name
            p[K.rate] = n.ttsRate
            p[K.lang] = n.speechLanguage
            p[K.speak] = n.speakResponses
            p[K.memory] = n.memoryEnabled
            p[K.history] = n.storeConversationHistory
            p[K.offline] = n.offlineOnly
            p[K.place] = n.weatherPlace
            p[K.aiUrl] = n.aiBaseUrl
            p[K.aiModel] = n.aiModel
            p[K.bMode] = n.briefingMode.name
            p[K.bCats] = n.briefingCategories
            p[K.qStart] = n.quietStartHour
            p[K.qEnd] = n.quietEndHour
            p[K.prot] = n.protectedPackages
            p[K.trusted] = n.trustedUsers
            p[K.privacy] = n.privacyMode
            p[K.anim] = n.reduceAnimations
        }
    }
}
