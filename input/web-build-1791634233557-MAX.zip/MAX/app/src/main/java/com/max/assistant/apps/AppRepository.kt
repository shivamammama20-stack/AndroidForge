package com.max.assistant.apps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

data class AppInfo(val label: String, val packageName: String)

/** Pure ranking so it can be unit-tested without Android. */
object AppMatcher {
    private val aliases = mapOf(
        "yt" to "youtube", "insta" to "instagram", "fb" to "facebook", "wa" to "whatsapp",
        "gmail" to "gmail", "maps" to "maps", "chrome" to "chrome", "settings" to "settings",
        "camera" to "camera", "photos" to "photos", "tg" to "telegram", "x" to "twitter",
    )

    fun rank(query: String, apps: List<AppInfo>): List<AppInfo> {
        val q0 = query.lowercase().trim()
        if (q0.isEmpty()) return emptyList()
        val q = aliases[q0] ?: q0
        val exact = apps.filter { it.label.equals(q, true) }
        if (exact.isNotEmpty()) return exact.distinctBy { it.packageName }
        val starts = apps.filter { it.label.startsWith(q, true) }
        if (starts.isNotEmpty()) return starts.distinctBy { it.packageName }
        return apps.filter { it.label.contains(q, true) || it.packageName.contains(q.replace(" ", ""), true) }
            .distinctBy { it.packageName }
    }
}

class AppRepository(private val context: Context) {
    @Volatile private var cache: List<AppInfo>? = null

    /** Visible launchable apps. Android's package-visibility rules mean this may not be every installed package. */
    fun launchableApps(forceRefresh: Boolean = false): List<AppInfo> {
        cache?.takeIf { !forceRefresh }?.let { return it }
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
        cache = list
        return list
    }

    fun search(query: String): List<AppInfo> = AppMatcher.rank(query, launchableApps())

    fun launchIntent(pkg: String): Intent? =
        context.packageManager.getLaunchIntentForPackage(pkg)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
