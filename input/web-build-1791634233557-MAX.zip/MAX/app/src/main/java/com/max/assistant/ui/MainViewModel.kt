package com.max.assistant.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.max.assistant.MaxApp
import com.max.assistant.brain.AssistantState
import com.max.assistant.brain.BrainReply
import com.max.assistant.data.ConversationEntity
import com.max.assistant.settings.AppSettings
import com.max.assistant.voice.VoiceEvent
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

data class ChatLine(val fromUser: Boolean, val text: String, val isError: Boolean = false)

sealed class UiEvent {
    data class Navigate(val route: String) : UiEvent()
    data class RequestPermission(val permission: String) : UiEvent()
    object Authenticate : UiEvent()
    data class OpenUrl(val url: String) : UiEvent()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as MaxApp).container
    val container get() = c

    val state: StateFlow<AssistantState> = c.brain.state
    val settings: StateFlow<AppSettings> =
        c.settings.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _chat = MutableStateFlow<List<ChatLine>>(
        listOf(ChatLine(false, "MAX online. Type or tap the mic. Try: \"open Chrome\", \"remind me in 10 minutes to stretch\", \"daily briefing\"."))
    )
    val chat: StateFlow<List<ChatLine>> = _chat.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    /** Result text for the dedicated Briefing / Current Affairs screens. */
    private val _screenResult = MutableStateFlow("")
    val screenResult: StateFlow<String> = _screenResult.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    val speaking = c.tts.speaking
    val ttsStatus = c.tts.status

    init {
        c.tts.init()
        viewModelScope.launch {
            c.settings.settings.collect { c.tts.setRate(it.ttsRate) }
        }
        viewModelScope.launch {
            c.voice.events.collect { ev ->
                when (ev) {
                    is VoiceEvent.Listening -> c.brain.setState(AssistantState.LISTENING)
                    is VoiceEvent.Partial -> _partial.value = ev.text
                    is VoiceEvent.Final -> { _partial.value = ""; c.voice.acknowledge(); submit(ev.text) }
                    is VoiceEvent.Error -> {
                        _partial.value = ""
                        addChat(ChatLine(false, ev.message, true))
                        c.brain.setState(AssistantState.ERROR)
                        c.voice.acknowledge()
                    }
                    VoiceEvent.Idle -> if (c.brain.state.value == AssistantState.LISTENING) c.brain.setState(AssistantState.IDLE)
                }
            }
        }
        viewModelScope.launch {
            c.tts.speaking.collect { sp ->
                if (sp) c.brain.setState(AssistantState.SPEAKING)
                else if (c.brain.state.value == AssistantState.SPEAKING) c.brain.setState(AssistantState.IDLE)
            }
        }
    }

    private fun addChat(l: ChatLine) { _chat.value = (_chat.value + l).takeLast(200) }

    fun submit(text: String, forScreen: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        c.tts.stop()
        viewModelScope.launch {
            _busy.value = true
            addChat(ChatLine(true, t))
            persist("USER", t)
            val reply = c.brain.process(t)
            handle(reply, forScreen)
            _busy.value = false
        }
    }

    private suspend fun persist(role: String, text: String) {
        val s = c.settings.current()
        if (s.storeConversationHistory && !s.privacyMode)
            c.db.conversation().insert(ConversationEntity(timestampMs = System.currentTimeMillis(), role = role, text = text))
    }

    private suspend fun handle(reply: BrainReply, forScreen: Boolean) {
        addChat(ChatLine(false, reply.text, reply.isError))
        _screenResult.value = reply.text
        persist("MAX", reply.text)
        reply.navigateTo?.let { _events.emit(UiEvent.Navigate(it)) }
        reply.requestPermission?.let { _events.emit(UiEvent.RequestPermission(it)) }
        if (reply.needsAuthentication) _events.emit(UiEvent.Authenticate)
        reply.openUrl?.let { _events.emit(UiEvent.OpenUrl(it)) }
        val s = c.settings.current()
        val speech = reply.speech
        if (speech != null && s.speakResponses) {
            val queued = c.tts.speak(speech, s.speechLanguage)
            if (!queued) c.brain.setState(if (reply.isError) AssistantState.ERROR else AssistantState.IDLE)
        }
    }

    fun onAuthResult(success: Boolean) {
        viewModelScope.launch {
            val reply = if (success) c.brain.onAuthenticated() else c.brain.onAuthenticationFailed()
            handle(reply, false)
        }
    }

    fun onPermissionResult(granted: Boolean, permission: String) {
        addChat(ChatLine(false, if (granted) "Permission granted. Please repeat your request." else "Permission denied. That feature stays unavailable until you allow it in the Permission Center.", !granted))
    }

    fun startListening() {
        c.tts.stop()
        viewModelScope.launch {
            val lang = c.settings.current().speechLanguage
            c.voice.start(lang)
        }
    }

    fun stopListening() { c.voice.stop(); c.brain.setState(AssistantState.IDLE) }
    fun stopSpeaking() { c.tts.stop() }

    fun clearChat() {
        _chat.value = emptyList()
        c.ctx.clear()
    }

    override fun onCleared() {
        c.voice.shutdown()
        super.onCleared()
    }
}
