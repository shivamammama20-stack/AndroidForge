package com.max.assistant.net

import com.max.assistant.core.ErrorCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

class NetException(val category: ErrorCategory, message: String) : Exception(message)

object Http {
    suspend fun get(url: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 12_000): String =
        request("GET", url, headers, null, timeoutMs)

    suspend fun postJson(url: String, json: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 30_000): String =
        request("POST", url, headers + ("Content-Type" to "application/json"), json, timeoutMs)

    private suspend fun request(method: String, url: String, headers: Map<String, String>, body: String?, timeoutMs: Int): String =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = timeoutMs
                    readTimeout = timeoutMs
                    setRequestProperty("User-Agent", "MAX-Assistant/0.1")
                    headers.forEach { (k, v) -> setRequestProperty(k, v) }
                    if (body != null) {
                        doOutput = true
                        outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                when {
                    code in 200..299 -> text
                    code == 401 || code == 403 -> throw NetException(ErrorCategory.MISSING_CREDENTIALS, "Provider rejected the credentials (HTTP $code).")
                    code == 429 -> throw NetException(ErrorCategory.API_FAILURE, "Rate limit reached (HTTP 429). Try again later.")
                    else -> throw NetException(ErrorCategory.API_FAILURE, "Provider returned HTTP $code.")
                }
            } catch (e: NetException) {
                throw e
            } catch (e: SocketTimeoutException) {
                throw NetException(ErrorCategory.TIMEOUT, "The request timed out.")
            } catch (e: UnknownHostException) {
                throw NetException(ErrorCategory.NETWORK, "No network connection or host not reachable.")
            } catch (e: IOException) {
                throw NetException(ErrorCategory.NETWORK, "Network error: ${e.javaClass.simpleName}")
            } finally {
                conn?.disconnect()
            }
        }
}
