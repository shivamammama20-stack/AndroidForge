package com.max.assistant.tools

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import com.max.assistant.briefing.BriefingComposer
import com.max.assistant.briefing.BriefingInputs
import com.max.assistant.context.ConversationContext
import com.max.assistant.core.Availability
import com.max.assistant.core.ErrorCategory
import com.max.assistant.core.RiskLevel
import com.max.assistant.core.Tool
import com.max.assistant.core.ToolArgs
import com.max.assistant.core.ToolResult
import com.max.assistant.core.Verification
import com.max.assistant.data.MaxDatabase
import com.max.assistant.data.MemoryEntity
import com.max.assistant.data.ReminderEntity
import com.max.assistant.net.NetException
import com.max.assistant.news.NewsRepository
import com.max.assistant.notifications.MaxNotificationListener
import com.max.assistant.notifications.NotificationStore
import com.max.assistant.reminders.Notifier
import com.max.assistant.reminders.ReminderScheduler
import com.max.assistant.settings.BriefingMode
import com.max.assistant.settings.SettingsRepository
import com.max.assistant.time.TimeParseResult
import com.max.assistant.time.TimeParser
import com.max.assistant.weather.WeatherProvider
import com.max.assistant.weather.WeatherReport
import com.max.assistant.web.SearchOutcome
import com.max.assistant.web.SearchProvider
import java.time.Clock
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class ReminderTool(
    private val context: Context,
    private val db: MaxDatabase,
    private val timeParser: TimeParser,
    private val clock: Clock,
) : Tool {
    override val id = "reminder"
    override val description = "Create a reminder that fires a notification"
    override val inputSchema = mapOf("when*" to "Time text", "text" to "What to remind", "repeat" to "NONE|DAILY")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES

    override suspend fun execute(args: ToolArgs): ToolResult {
        val at = when (val r = timeParser.parse(args["when"].orEmpty())) {
            is TimeParseResult.At -> r.time
            is TimeParseResult.Ambiguous -> return ToolResult.fail(r.question, ErrorCategory.AMBIGUOUS)
            TimeParseResult.None -> return ToolResult.fail("When should I remind you?", ErrorCategory.AMBIGUOUS)
        }
        if (!at.toInstant().isAfter(Instant.now(clock))) return ToolResult.fail("That time is in the past.", ErrorCategory.INVALID_INPUT)
        val repeat = if (args["repeat"] == "DAILY" || args["when"].orEmpty().contains("roz") || args["when"].orEmpty().contains("every day")) "DAILY" else "NONE"
        val text = args["text"]?.takeIf { it.isNotBlank() } ?: "Reminder"
        val id = try { db.reminders().insert(ReminderEntity(text = text, triggerAtMs = at.toInstant().toEpochMilli(), repeat = repeat)) }
        catch (e: Exception) { return ToolResult.fail("Could not save the reminder (database error).", ErrorCategory.DATABASE) }
        val saved = db.reminders().get(id) ?: return ToolResult.fail("The reminder was not saved.", ErrorCategory.DATABASE)
        val mode = ReminderScheduler.schedule(context, saved)
        if (mode == "FAILED") {
            db.reminders().delete(saved)
            return ToolResult.fail("I could not schedule the alarm for this reminder, so nothing was saved.", ErrorCategory.SCHEDULING)
        }
        db.reminders().update(saved.copy(scheduleMode = mode))
        val whenText = at.format(DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.getDefault()))
        val warnings = buildList {
            if (mode == "INEXACT") add("Exact alarms are not allowed for MAX, so it may fire a few minutes late. Allow \"Alarms & reminders\" in Permission Center for exact timing.")
            if (!context.getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled()) add("Notifications are blocked, so you will NOT see it. Enable them in Permission Center.")
        }
        val msg = "Reminder set for $whenText: $text" + if (repeat == "DAILY") " (repeats daily)" else ""
        return if (warnings.isEmpty()) ToolResult.ok(msg, Verification.VERIFIED)
        else ToolResult.partial(msg + "\n" + warnings.joinToString(" "), Verification.VERIFIED)
    }
}

class ListRemindersTool(private val db: MaxDatabase) : Tool {
    override val id = "list_reminders"
    override val description = "List upcoming reminders"
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val list = db.reminders().all().filter { !it.done }
        if (list.isEmpty()) return ToolResult.ok("You have no upcoming reminders.", Verification.VERIFIED)
        val f = DateTimeFormatter.ofPattern("EEE d MMM, h:mm a", Locale.getDefault())
        return ToolResult.ok(list.take(10).joinToString("\n") {
            "• ${ZonedDateTime.ofInstant(Instant.ofEpochMilli(it.triggerAtMs), ZoneId.systemDefault()).format(f)} — ${it.text}"
        }, Verification.VERIFIED)
    }
}

/** Reads local calendar events. Used by the CalendarTool and the briefing; data never leaves the device. */
class CalendarReader(private val context: Context) {
    fun hasPermission() = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun upcoming(from: ZonedDateTime, hours: Long = 24): List<String> {
        if (!hasPermission()) return emptyList()
        val start = from.toInstant().toEpochMilli()
        val end = from.plusHours(hours).toInstant().toEpochMilli()
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, start); ContentUris.appendId(it, end)
        }.build()
        val out = ArrayList<String>()
        context.contentResolver.query(
            uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
            null, null, "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { c ->
            val f = DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault())
            while (c.moveToNext() && out.size < 15) {
                val allDay = c.getInt(2) == 1
                val time = if (allDay) "all day" else ZonedDateTime.ofInstant(Instant.ofEpochMilli(c.getLong(1)), from.zone).format(f)
                out += "$time — ${c.getString(0).orEmpty().ifBlank { "(no title)" }}"
            }
        }
        return out
    }
}

class CalendarTool(private val reader: CalendarReader, private val clock: Clock) : Tool {
    override val id = "calendar"
    override val description = "Show calendar events for the next 24 hours"
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = listOf(Manifest.permission.READ_CALENDAR)
    override val baseRisk = RiskLevel.MEDIUM
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val ev = reader.upcoming(ZonedDateTime.now(clock))
        return if (ev.isEmpty()) ToolResult.ok("No calendar events in the next 24 hours.", Verification.VERIFIED)
        else ToolResult.ok(ev.joinToString("\n") { "• $it" }, Verification.VERIFIED)
    }
}

class MemoryTool(private val db: MaxDatabase, private val settings: SettingsRepository) : Tool {
    override val id = "memory"
    override val description = "Save or show things MAX remembers"
    override val inputSchema = mapOf("action*" to "save|show|delete_all", "text" to "What to remember")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        when (args["action"]) {
            "save" -> {
                if (!settings.current().memoryEnabled) return ToolResult.fail("Memory is turned off in settings, so I did not save that.", ErrorCategory.UNSUPPORTED)
                val t = args["text"].orEmpty().ifBlank { return ToolResult.fail("What should I remember?", ErrorCategory.INVALID_INPUT) }
                db.memory().insert(MemoryEntity(text = t, createdAtMs = System.currentTimeMillis()))
                return ToolResult.ok("Saved to memory: $t", Verification.VERIFIED)
            }
            "show" -> {
                val all = db.memory().all()
                return if (all.isEmpty()) ToolResult.ok("Memory is empty.", Verification.VERIFIED)
                else ToolResult.ok(all.take(10).joinToString("\n") { "• ${it.text}" }, Verification.VERIFIED)
            }
            "delete_all" -> { db.memory().deleteAll(); return ToolResult.ok("All memory deleted.", Verification.VERIFIED) }
        }
        return ToolResult.fail("Unknown memory action.", ErrorCategory.INVALID_INPUT)
    }
}

class ReadNotificationsTool(private val context: Context) : Tool {
    override val id = "read_notifications"
    override val description = "Summarise currently active notifications"
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.SENSITIVE
    override fun availability() =
        if (MaxNotificationListener.isEnabled(context)) Availability.YES else Availability.no("Notification access is not enabled")

    override suspend fun execute(args: ToolArgs): ToolResult {
        if (!MaxNotificationListener.isEnabled(context))
            return ToolResult(com.max.assistant.core.Status.FAILURE, "Notification access is off. Enable MAX in the notification access screen.", emptyMap(), ErrorCategory.PERMISSION_DENIED, Verification.NOT_APPLICABLE, "notification_listener")
        if (!NotificationStore.connected)
            return ToolResult.fail("Notification access is on but the listener has not connected yet. Try again in a moment.", ErrorCategory.SERVICE_UNAVAILABLE)
        val items = NotificationStore.items.value
        if (items.isEmpty()) return ToolResult.ok("No active notifications that I can see.", Verification.VERIFIED)
        val grouped = items.groupBy { it.appLabel }
        val text = grouped.entries.take(6).joinToString("\n") { (app, list) ->
            "• $app (${list.size}): " + list.first().let { n -> listOf(n.title, n.text).filter { it.isNotBlank() }.joinToString(" — ").take(100) }
        }
        return ToolResult.ok("${items.size} notifications from ${grouped.size} apps:\n$text", Verification.VERIFIED)
    }
}

class WeatherTool(
    private val context: Context,
    private val provider: WeatherProvider,
    private val settings: SettingsRepository,
) : Tool {
    override val id = "weather"
    override val description = "Current weather and today's forecast"
    override val inputSchema = mapOf("place" to "City name (optional if set in settings)")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES

    suspend fun fetchReport(placeArg: String?): Pair<WeatherReport?, String?> {
        val s = settings.current()
        if (s.offlineOnly) return null to "Offline-only mode is on, so live weather is unavailable."
        val place = placeArg?.takeIf { it.isNotBlank() } ?: s.weatherPlace.takeIf { it.isNotBlank() }
        return try {
            if (place != null) {
                val g = provider.geocode(place) ?: return null to "I couldn't find a place called \"$place\"."
                provider.report(g.latitude, g.longitude, "${g.name}, ${g.country}") to null
            } else {
                val loc = lastKnownLocation() ?: return null to "No weather city is set and device location is unavailable. Set a city in Settings or allow location."
                provider.report(loc.latitude, loc.longitude, "Your location") to null
            }
        } catch (e: NetException) {
            null to "Live weather is unavailable: ${e.message}"
        } catch (e: Exception) {
            null to "Could not read the weather response."
        }
    }

    private fun lastKnownLocation(): Location? {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val lm = context.getSystemService(LocationManager::class.java)
        return runCatching {
            lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        }.getOrNull()
    }

    override suspend fun execute(args: ToolArgs): ToolResult {
        val (report, err) = fetchReport(args["place"])
        if (report == null) return ToolResult.fail(err ?: "Weather unavailable.", ErrorCategory.PROVIDER_UNAVAILABLE)
        val sb = StringBuilder("${report.placeLabel}: ${report.temperature}${report.temperatureUnit}, ${report.conditionText} (observed ${report.observedAtLocal}, ${report.timezone}).")
        if (report.todayMin != null && report.todayMax != null) sb.append(" Today's forecast: ${report.todayMin}–${report.todayMax}${report.temperatureUnit}.")
        report.rainProbabilityPercent?.let { sb.append(" Chance of rain: $it%.") }
        return ToolResult.ok(sb.toString(), Verification.VERIFIED)
    }
}

class CurrentAffairsTool(
    private val news: NewsRepository,
    private val ctx: ConversationContext,
    private val settings: SettingsRepository,
) : Tool {
    override val id = "current_affairs"
    override val description = "Fresh headlines from public RSS feeds, with sources and dates"
    override val inputSchema = mapOf("category" to "world|india|business|technology|science|health|sports|entertainment")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        if (settings.current().offlineOnly) return ToolResult.fail("Offline-only mode is on; I can't fetch current affairs.", ErrorCategory.NETWORK)
        val cat = args["category"]
        if (cat != null && cat !in news.supportedCategories())
            return ToolResult.fail("I don't have a news source configured for \"$cat\". Available: ${news.supportedCategories().joinToString()}.", ErrorCategory.UNSUPPORTED)
        val cats = if (cat != null) listOf(cat) else listOf("world", "india")
        val r = news.fetch(cats, perCategory = 4)
        if (r.items.isEmpty()) {
            val why = r.failures.values.firstOrNull() ?: "no recent dated stories were returned"
            return ToolResult.fail("I couldn't get fresh news: $why", ErrorCategory.NETWORK)
        }
        ctx.lastHeadlines = r.items
        ctx.selectedHeadline = null
        val now = Instant.now()
        val body = r.items.mapIndexed { i, n -> "${i + 1}. ${n.title} — ${n.source}, ${BriefingComposer.ageText(n.publishedAt, now)}" }.joinToString("\n")
        val note = if (r.failures.isNotEmpty()) "\n\nSome sources failed: ${r.failures.keys.joinToString()}." else ""
        return ToolResult.ok(body + note + "\n\nSay \"explain the second headline\" for details.", Verification.VERIFIED)
    }
}

class WebSearchTool(private val provider: SearchProvider, private val settings: SettingsRepository) : Tool {
    override val id = "web_search"
    override val description = "Search the web via the configured provider"
    override val inputSchema = mapOf("query*" to "Search text")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = if (provider.isConfigured()) Availability.YES else Availability.no("No search API key configured")
    override suspend fun execute(args: ToolArgs): ToolResult {
        if (settings.current().offlineOnly) return ToolResult.fail("Offline-only mode is on.", ErrorCategory.NETWORK)
        return when (val o = provider.search(args["query"].orEmpty())) {
            is SearchOutcome.Unavailable -> ToolResult.fail("Web search unavailable: ${o.reason}", o.category)
            is SearchOutcome.Found ->
                if (o.sources.isEmpty()) ToolResult.ok("No results found.", Verification.VERIFIED)
                else ToolResult.ok(o.sources.joinToString("\n\n") { "• ${it.title}${it.age?.let { a -> " ($a)" } ?: ""}\n  ${it.url}\n  ${it.snippet.take(180)}" }, Verification.VERIFIED)
        }
    }
}

class CameraOcrTool : Tool {
    override val id = "camera_ocr"
    override val description = "Open the camera screen to scan text (you press the shutter)"
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs) = ToolResult.ok("Opening the text scanner. Point at text and tap the shutter.", Verification.NOT_APPLICABLE, nav = "ocr")
}

class SimpleNavTool(override val id: String, override val description: String, private val route: String, private val msg: String) : Tool {
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs) = ToolResult.ok(msg, Verification.NOT_APPLICABLE, nav = route)
}

/** Builds and speaks/prints the briefing. Personal data (calendar, reminders) stays on-device. */
class BriefingService(
    private val context: Context,
    private val db: MaxDatabase,
    private val settings: SettingsRepository,
    private val weather: WeatherTool,
    private val news: NewsRepository,
    private val calendar: CalendarReader,
    private val clock: Clock,
) {
    suspend fun build(mode: BriefingMode?, only: String?, excluded: Set<String>): com.max.assistant.briefing.Briefing {
        val s = settings.current()
        val now = ZonedDateTime.now(clock)
        val m = mode ?: s.briefingMode

        val (w, wNote) = if (s.weatherPlace.isBlank() && !s.offlineOnly) weather.fetchReport(null) else weather.fetchReport(null)
        val calLines = if (calendar.hasPermission()) calendar.upcoming(now) else null
        val calNote = if (calendar.hasPermission()) null else "Calendar skipped: calendar permission not granted."
        val reminders = db.reminders().all().filter { !it.done && it.triggerAtMs < now.plusHours(24).toInstant().toEpochMilli() }
            .map { "${ZonedDateTime.ofInstant(Instant.ofEpochMilli(it.triggerAtMs), now.zone).format(DateTimeFormatter.ofPattern("h:mm a"))} — ${it.text}" }

        val cats = (if (only != null) setOf(only) else s.briefingCategories).filter { it !in excluded }
        val (newsRes, newsNote) = if (s.offlineOnly) null to "News skipped: offline-only mode." else try {
            news.fetch(cats, perCategory = BriefingComposer.itemsPerCategory(m) + 1) to null
        } catch (e: Exception) { null to "News unavailable: ${e.message}" }

        return BriefingComposer.compose(
            BriefingInputs(now, w, wNote, calLines, calNote, reminders, newsRes, newsNote),
            m, s.briefingCategories, excluded, only,
        )
    }
}
