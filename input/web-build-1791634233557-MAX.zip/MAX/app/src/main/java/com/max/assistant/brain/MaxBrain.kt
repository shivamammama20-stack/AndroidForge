package com.max.assistant.brain

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.max.assistant.ai.AIProvider
import com.max.assistant.ai.AiResult
import com.max.assistant.ai.ChatMessage
import com.max.assistant.briefing.BriefingComposer
import com.max.assistant.context.ConversationContext
import com.max.assistant.context.PendingClarification
import com.max.assistant.context.PendingConfirmation
import com.max.assistant.core.ErrorCategory
import com.max.assistant.core.RiskLevel
import com.max.assistant.core.Status
import com.max.assistant.core.Tool
import com.max.assistant.core.ToolResult
import com.max.assistant.apps.AppRepository
import com.max.assistant.contacts.ContactRepository
import com.max.assistant.contacts.ContactResolution
import com.max.assistant.contacts.ContactResolver
import com.max.assistant.intent.IntentDetector
import com.max.assistant.intent.IntentType
import com.max.assistant.intent.ParsedIntent
import com.max.assistant.settings.BriefingMode
import com.max.assistant.settings.SettingsRepository
import com.max.assistant.tools.BriefingService
import com.max.assistant.tools.ToolRegistry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException

enum class AssistantState(val label: String) {
    IDLE("AWAITING COMMAND"), LISTENING("LISTENING"), ANALYZING("ANALYZING"),
    EXECUTING("EXECUTING"), SPEAKING("SPEAKING"), ERROR("SYSTEM ERROR"),
}

/** What the UI must do after a brain turn. */
data class BrainReply(
    val text: String,
    val speech: String? = text,
    val navigateTo: String? = null,
    val requestPermission: String? = null,
    val needsAuthentication: Boolean = false,
    val openUrl: String? = null,
    val isError: Boolean = false,
)

class PermissionChecker(private val context: Context) {
    fun has(permission: String) = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

/**
 * Pipeline: input -> context -> intent -> (AI) -> tool selection -> permission -> risk -> confirmation
 *           -> execution -> validation -> response. The AI never decides whether an action succeeded:
 *           only [ToolResult] produced by a tool does.
 */
class MaxBrain(
    private val registry: ToolRegistry,
    private val detector: IntentDetector,
    val ctx: ConversationContext,
    private val risk: RiskEngine,
    private val settings: SettingsRepository,
    private val permissions: PermissionChecker,
    private val apps: AppRepository,
    private val contacts: ContactRepository,
    private val ai: AIProvider,
    private val briefing: BriefingService,
    private val log: suspend (String, String) -> Unit,
    private val securityLog: suspend (RiskLevel, String) -> Unit,
    private val now: () -> Long = { System.currentTimeMillis() },
) {
    private val _state = MutableStateFlow(AssistantState.IDLE)
    val state: StateFlow<AssistantState> = _state.asStateFlow()
    fun setState(s: AssistantState) { _state.value = s }

    suspend fun process(input: String): BrainReply = handle(input, unattended = false)

    /** For scheduled automations: runs only actions that need no confirmation. Returns plain text. */
    suspend fun runUnattended(command: String): String = handle(command, unattended = true).text

    private suspend fun handle(input: String, unattended: Boolean): BrainReply {
        if (!unattended) _state.value = AssistantState.ANALYZING
        val intent = detector.detect(input)
        log("INTENT", "${intent.type}${if (intent.entities.isNotEmpty()) " " + intent.entities.keys else ""}")
        val reply = try {
            route(intent, unattended)
        } catch (e: Exception) {
            log("ERROR", "Unexpected: ${e.javaClass.simpleName}")
            BrainReply("Something went wrong while handling that (${e.javaClass.simpleName}).", isError = true)
        }
        if (!unattended) _state.value = if (reply.isError) AssistantState.ERROR else AssistantState.IDLE
        ctx.lastSpoken = reply.speech ?: reply.text
        return reply
    }

    private suspend fun route(intent: ParsedIntent, unattended: Boolean): BrainReply {
        // 1. A pending clarification gets first claim on short free-text answers.
        ctx.pendingClarification?.let { pc ->
            if (intent.type == IntentType.CONFIRM_NO) { ctx.pendingClarification = null; return BrainReply("Okay, cancelled.") }
            if (intent.type in setOf(IntentType.CONVERSATION, IntentType.CONFIRM_YES, IntentType.UNSUPPORTED)) {
                ctx.pendingClarification = null
                return resumeClarification(pc, intent.raw, unattended)
            }
            ctx.pendingClarification = null
        }

        return when (intent.type) {
            IntentType.CONFIRM_YES -> confirm(true)
            IntentType.CONFIRM_NO -> confirm(false)
            IntentType.STOP_SPEAKING -> BrainReply("Stopped.", speech = null)
            IntentType.REPEAT -> if (ctx.lastSpoken.isBlank()) BrainReply("There is nothing to repeat yet.") else BrainReply(ctx.lastSpoken)
            IntentType.BRIEFING_FOLLOWUP -> followUp(intent)
            IntentType.CONVERSATION -> converse(intent)
            IntentType.UNSUPPORTED -> BrainReply("I can't do that yet.", isError = false)
            else -> runTool(intent, unattended)
        }
    }

    // ---- tool planning ----------------------------------------------------------------------

    private fun toolFor(t: IntentType): String? = when (t) {
        IntentType.OPEN_APP -> "open_app"
        IntentType.SEARCH_APPS -> "search_apps"
        IntentType.CALL -> "call_contact"
        IntentType.MESSAGE -> "message_contact"
        IntentType.SEARCH_CONTACT -> "search_contact"
        IntentType.READ_NOTIFICATIONS -> "read_notifications"
        IntentType.NAVIGATE -> "navigate"
        IntentType.MAP_SEARCH -> "map_search"
        IntentType.MEDIA_PLAY -> "play_media"
        IntentType.MEDIA_PAUSE -> "pause_media"
        IntentType.MEDIA_NEXT -> "next_media"
        IntentType.MEDIA_PREVIOUS -> "previous_media"
        IntentType.VOLUME -> "volume"
        IntentType.REMINDER -> "reminder"
        IntentType.ALARM -> "alarm"
        IntentType.TIMER -> "timer"
        IntentType.LIST_REMINDERS -> "list_reminders"
        IntentType.CALENDAR -> "calendar"
        IntentType.WEATHER -> "weather"
        IntentType.CURRENT_AFFAIRS -> "current_affairs"
        IntentType.DAILY_BRIEFING -> "daily_briefing"
        IntentType.WEB_SEARCH -> "web_search"
        IntentType.CAMERA_OCR -> "camera_ocr"
        IntentType.DEVICE_INFO -> "device_info"
        IntentType.SETTINGS -> "device_settings"
        IntentType.MEMORY -> "memory"
        IntentType.SECURITY -> "security"
        IntentType.AUTOMATION -> "automation"
        else -> null
    }

    private suspend fun runTool(intent: ParsedIntent, unattended: Boolean): BrainReply {
        val toolId = toolFor(intent.type) ?: return BrainReply("I can't do that yet.")
        val tool = registry.get(toolId) ?: return BrainReply("That capability is not available in this build.", isError = true)
        var args = intent.entities.filterValues { it.isNotEmpty() }
        ctx.lastIntentToolId = toolId

        // Resolve apps / contacts before risk assessment so risk can use real package names.
        when (toolId) {
            "open_app" -> {
                val query = args["app"].orEmpty()
                val found = apps.search(query)
                when {
                    found.isEmpty() -> return BrainReply("I couldn't find an app called \"$query\". Android only shows apps MAX is allowed to see.", isError = true)
                    found.size > 1 && found.none { it.label.equals(query, true) } -> {
                        ctx.pendingClarification = PendingClarification(toolId, args, "app", found.take(4).map { it.label })
                        return BrainReply("Which one: ${found.take(4).joinToString(" or ") { it.label }}?")
                    }
                    else -> { val a = found.first(); args = args + mapOf("package" to a.packageName, "label" to a.label) }
                }
            }
            "call_contact", "message_contact" -> {
                val r = resolveContact(args["contact"].orEmpty(), toolId)
                if (r.first != null) return r.first!!
                args = args + (r.second ?: emptyMap())
            }
        }
        return execute(tool, args, unattended)
    }

    /** @return Pair(reply-to-return-or-null, extra args) */
    private suspend fun resolveContact(query: String, toolId: String): Pair<BrainReply?, Map<String, String>?> {
        if (query == "__last__" || query.isBlank()) {
            val n = ctx.lastContactNumber
            val name = ctx.lastContactName
            if (n == null || name == null) return BrainReply("Who do you mean? I don't have a recent contact.") to null
            return null to mapOf("name" to name, "number" to n)
        }
        if (!permissions.has(android.Manifest.permission.READ_CONTACTS))
            return BrainReply("I need contacts permission to find \"$query\".", requestPermission = android.Manifest.permission.READ_CONTACTS, isError = true) to null
        return when (val res = ContactResolver.resolve(kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { contacts.search(query) })) {
            ContactResolution.None -> BrainReply("I couldn't find a contact named \"$query\".", isError = true) to null
            is ContactResolution.Single -> {
                ctx.lastContactName = res.match.name; ctx.lastContactNumber = res.match.number
                null to mapOf("name" to res.match.name, "number" to res.match.number)
            }
            is ContactResolution.Multiple -> {
                ctx.pendingClarification = PendingClarification(toolId, mapOf("contact" to query), "contact", res.options.map { it.name })
                BrainReply("I found ${res.options.size} matches: ${res.options.take(4).joinToString(", ") { it.name }}. Which one?") to null
            }
        }
    }

    private suspend fun resumeClarification(pc: PendingClarification, answer: String, unattended: Boolean): BrainReply {
        val tool = registry.get(pc.toolId) ?: return BrainReply("I lost track of that request.")
        val key = if (pc.missingKey == "when") "when" else pc.missingKey
        val merged = if (key == "when") pc.args + ("when" to (pc.args["when"].orEmpty() + " " + answer))
        else pc.args + (key to answer.trim())
        val synthetic = ParsedIntent(
            when (pc.toolId) { "open_app" -> IntentType.OPEN_APP; "call_contact" -> IntentType.CALL; "message_contact" -> IntentType.MESSAGE
                "reminder" -> IntentType.REMINDER; "alarm" -> IntentType.ALARM; else -> IntentType.CONVERSATION },
            merged, answer,
        )
        return if (synthetic.type == IntentType.CONVERSATION) execute(tool, merged, unattended) else runTool(synthetic, unattended)
    }

    // ---- execution pipeline -----------------------------------------------------------------

    private suspend fun execute(tool: Tool, args: Map<String, String>, unattended: Boolean): BrainReply {
        val s = settings.current()

        val avail = tool.availability()
        if (!avail.available) return BrainReply("${tool.description} isn't available: ${avail.reason}.", isError = true, navigateTo = "permissions")

        for (p in tool.requiredPermissions) if (!permissions.has(p))
            return BrainReply("I need permission for that (${p.substringAfterLast('.')}).", requestPermission = p, isError = true)

        val decision = risk.assess(tool.id, tool.baseRisk, args, s.confirmationPolicy)
        if (s.privacyMode && decision.level >= RiskLevel.MEDIUM && !decision.needsAuthentication) {
            // Privacy mode: everything MEDIUM+ needs explicit confirmation.
        }
        if (decision.needsConfirmation || (s.privacyMode && decision.level >= RiskLevel.MEDIUM)) {
            if (unattended) {
                securityLog(decision.level, "Automation skipped ${tool.id}: needs confirmation")
                return BrainReply("Skipped \"${tool.id}\": it needs your confirmation, which scheduled runs can't give.", isError = true)
            }
            val prompt = "${describe(tool, args)}. Say yes to continue or no to cancel."
            ctx.pendingConfirmation = PendingConfirmation(tool.id, args, prompt, now(), decision.needsAuthentication)
            securityLog(decision.level, "Confirmation requested for ${tool.id} (${decision.reason})")
            return BrainReply(if (decision.needsAuthentication) "$prompt You'll also need to verify with your fingerprint/PIN." else prompt,
                needsAuthentication = decision.needsAuthentication)
        }
        return run(tool, args, decision.level)
    }

    private suspend fun run(tool: Tool, args: Map<String, String>, level: RiskLevel): BrainReply {
        _state.value = AssistantState.EXECUTING
        log("TOOL", "Executing ${tool.id}")
        val result: ToolResult = try {
            withTimeout(25_000) { tool.execute(args) }
        } catch (e: TimeoutCancellationException) {
            ToolResult.fail("That took too long and was cancelled.", ErrorCategory.TIMEOUT)
        } catch (e: Exception) {
            ToolResult.fail("The action failed (${e.javaClass.simpleName}).", ErrorCategory.UNKNOWN)
        }
        log(if (result.status == Status.FAILURE) "ERROR" else "RESULT", "${tool.id}: ${result.status} / ${result.verification}")
        if (level >= RiskLevel.HIGH) securityLog(level, "${tool.id} ran: ${result.status}")
        if (tool.id == "daily_briefing") return BrainReply(result.message, speech = result.data["speech"])
        return BrainReply(
            text = result.message,
            speech = result.message.lines().take(6).joinToString(". ").take(500),
            navigateTo = result.navigateTo,
            isError = result.status == Status.FAILURE,
        ).let { r ->
            if (result.status == Status.FAILURE && result.error == ErrorCategory.AMBIGUOUS) {
                ctx.pendingClarification = PendingClarification(tool.id, args, "when", emptyList())
            }
            r
        }
    }

    private fun describe(tool: Tool, args: Map<String, String>) = when (tool.id) {
        "call_contact" -> "Open the dialer for ${args["name"] ?: "this contact"}"
        "message_contact" -> "Open the message composer for ${args["name"] ?: "this contact"}" + (args["body"]?.let { " with \"$it\"" } ?: "")
        "open_app" -> "Open ${args["label"] ?: "this app"}"
        "read_notifications" -> "Read your current notifications"
        "memory" -> "Change your stored memory"
        else -> tool.description
    }

    // ---- confirmation -----------------------------------------------------------------------

    private suspend fun confirm(yes: Boolean): BrainReply {
        val p = ctx.pendingConfirmation ?: return BrainReply(if (yes) "There's nothing waiting for confirmation." else "Okay.")
        if (!yes) { ctx.pendingConfirmation = null; return BrainReply("Cancelled.") }
        if (p.isExpired(now())) { ctx.pendingConfirmation = null; return BrainReply("That confirmation expired. Please ask again.") }
        if (p.requiresBiometric) return BrainReply("Please verify it's you first.", needsAuthentication = true)
        ctx.pendingConfirmation = null
        val tool = registry.get(p.toolId) ?: return BrainReply("That action is no longer available.", isError = true)
        return run(tool, p.args, RiskLevel.HIGH)
    }

    /** Called by the UI after BiometricPrompt succeeds. A sensitive action is only run here. */
    suspend fun onAuthenticated(): BrainReply {
        val p = ctx.pendingConfirmation ?: return BrainReply("Nothing was waiting for verification.")
        ctx.pendingConfirmation = null
        if (p.isExpired(now())) return BrainReply("That request expired. Please ask again.")
        val tool = registry.get(p.toolId) ?: return BrainReply("That action is no longer available.", isError = true)
        securityLog(RiskLevel.SENSITIVE, "User authenticated for ${p.toolId}")
        return run(tool, p.args, RiskLevel.SENSITIVE)
    }

    suspend fun onAuthenticationFailed(): BrainReply {
        ctx.pendingConfirmation = null
        securityLog(RiskLevel.SENSITIVE, "Authentication failed or cancelled; action not run")
        return BrainReply("Verification failed, so I didn't do it.", isError = true)
    }

    // ---- briefing follow-ups ----------------------------------------------------------------

    private suspend fun followUp(intent: ParsedIntent): BrainReply {
        val action = intent.entities["action"].orEmpty()
        when (action) {
            "skip", "only", "continue" -> {
                when (action) {
                    "skip" -> intent.entities["category"]?.let { ctx.briefingExcludedCategories.add(canon(it)) }
                    "only" -> ctx.briefingOnlyCategory = canon(intent.entities["category"].orEmpty())
                }
                val b = briefing.build(null, ctx.briefingOnlyCategory, ctx.briefingExcludedCategories)
                ctx.lastHeadlines = b.headlines
                return BrainReply(BriefingComposer.toDisplayText(b), speech = BriefingComposer.toSpeech(b))
            }
        }
        val idx = intent.entities["index"]?.toIntOrNull()
        val item = if (idx != null) ctx.lastHeadlines.getOrNull(idx - 1) else (ctx.selectedHeadline ?: ctx.lastHeadlines.firstOrNull())
        if (item == null) return BrainReply(if (idx != null) "I don't have headline number $idx." else "Ask for a briefing or current affairs first so I have headlines to talk about.")
        ctx.selectedHeadline = item
        if (action == "source") return BrainReply("${item.title}\nSource: ${item.source}\n${item.url}", speech = "Opening the original source from ${item.source}.", openUrl = item.url)

        val base = "${item.title}\nSource: ${item.source}, published ${BriefingComposer.ageText(item.publishedAt)}.\n" +
            (item.summary.takeIf { it.isNotBlank() }?.let { "Summary from the source: $it\n" } ?: "")
        if (action == "explain" && !ai.isConfigured()) return BrainReply(base + "\nFor a deeper explanation, configure an AI provider in Settings.")
        if (action in setOf("both_sides", "india_impact") && !ai.isConfigured())
            return BrainReply(base + "\nThat kind of analysis needs an AI provider (Settings → AI provider). I won't invent it.")
        if (!ai.isConfigured() || settings.current().offlineOnly) return BrainReply(base)

        val task = when (action) {
            "both_sides" -> "Give the main perspectives on this story, clearly labelled as perspectives, not facts."
            "india_impact" -> "Explain what this could mean for India, labelling anything speculative as analysis."
            else -> "Explain this story in more detail."
        }
        // Only the public headline and summary leave the device. No personal data.
        val res = ai.complete(listOf(
            ChatMessage("system", "You explain news. Use ONLY the provided headline and summary. Separate facts from analysis and say when information is missing. Never invent quotes, numbers or sources."),
            ChatMessage("user", "$task\n\nHeadline: ${item.title}\nSource: ${item.source}\nSummary: ${item.summary}"),
        ))
        return when (res) {
            is AiResult.Ok -> BrainReply(base + "\nAI analysis (not from the source):\n" + res.text, speech = res.text)
            is AiResult.Err -> BrainReply(base + "\nAI provider problem: ${res.message}", isError = true)
        }
    }

    private fun canon(c: String) = when (c.lowercase()) {
        "tech", "technology", "ai" -> "technology"; "sports", "sport", "cricket" -> "sports"
        "business", "market", "markets", "economy" -> "business"; else -> c.lowercase()
    }

    private suspend fun converse(intent: ParsedIntent): BrainReply {
        val s = settings.current()
        if (s.offlineOnly) return BrainReply("Offline-only mode is on, so I can't use an AI provider. I can still open apps, set reminders and use device features.")
        if (!ai.isConfigured()) return BrainReply(
            "I don't have an AI provider configured, so I can't hold open conversations yet. " +
                "I can open apps, call/message contacts, set reminders, show weather and news. Add a provider in Settings → AI provider."
        )
        // Only the user's own sentence is sent. No memory, contacts, calendar or notifications.
        val res = ai.complete(listOf(
            ChatMessage("system", "You are MAX, a concise personal assistant. Never claim to have performed phone actions; those are done by separate tools."),
            ChatMessage("user", intent.raw),
        ))
        return when (res) {
            is AiResult.Ok -> BrainReply(res.text)
            is AiResult.Err -> BrainReply("AI provider problem: ${res.message}", isError = true)
        }
    }
}
