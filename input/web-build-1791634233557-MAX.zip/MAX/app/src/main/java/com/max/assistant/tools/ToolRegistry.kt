package com.max.assistant.tools

import com.max.assistant.briefing.BriefingComposer
import com.max.assistant.context.ConversationContext
import com.max.assistant.core.Availability
import com.max.assistant.core.RiskLevel
import com.max.assistant.core.Tool
import com.max.assistant.core.ToolArgs
import com.max.assistant.core.ToolResult
import com.max.assistant.core.Verification
import com.max.assistant.settings.BriefingMode

/** Typed registry. Each tool reports truthful availability; nothing here is a placeholder. */
class ToolRegistry(tools: List<Tool>) {
    private val byId: Map<String, Tool> = tools.associateBy { it.id }
    fun get(id: String): Tool? = byId[id]
    fun all(): List<Tool> = byId.values.sortedBy { it.id }
    fun availabilityReport(): List<Triple<String, Availability, RiskLevel>> = all().map { Triple(it.id, it.availability(), it.baseRisk) }
}

class DailyBriefingTool(private val service: BriefingService, private val ctx: ConversationContext) : Tool {
    override val id = "daily_briefing"
    override val description = "Daily briefing: date, weather, calendar, reminders and fresh news with sources"
    override val inputSchema = mapOf("mode" to "SHORT|NORMAL|DETAILED")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES

    override suspend fun execute(args: ToolArgs): ToolResult {
        val mode = args["mode"]?.let { runCatching { BriefingMode.valueOf(it) }.getOrNull() }
        ctx.briefingExcludedCategories.clear(); ctx.briefingOnlyCategory = null
        val b = service.build(mode, null, emptySet())
        ctx.lastHeadlines = b.headlines
        ctx.selectedHeadline = null
        if (b.sections.isEmpty()) return ToolResult.fail("I couldn't assemble a briefing: ${b.notes.joinToString(" ")}", com.max.assistant.core.ErrorCategory.PROVIDER_UNAVAILABLE)
        val status = if (b.notes.isEmpty()) Verification.VERIFIED else Verification.VERIFIED
        val text = BriefingComposer.toDisplayText(b)
        val r = if (b.notes.isEmpty()) ToolResult.ok(text, status, mapOf("speech" to BriefingComposer.toSpeech(b)))
        else ToolResult.partial(text, status, mapOf("speech" to BriefingComposer.toSpeech(b)))
        return r
    }
}
