package com.max.assistant.notifications

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NotificationInfo(val key: String, val packageName: String, val appLabel: String, val title: String, val text: String, val postedAtMs: Long)

/**
 * In-memory only. Notification text is NEVER written to disk or sent anywhere by this class;
 * it disappears when the service disconnects or the process dies.
 */
object NotificationStore {
    private val _items = MutableStateFlow<List<NotificationInfo>>(emptyList())
    val items: StateFlow<List<NotificationInfo>> = _items.asStateFlow()
    @Volatile var connected: Boolean = false

    fun put(n: NotificationInfo) { _items.value = (listOf(n) + _items.value.filter { it.key != n.key }).take(50) }
    fun remove(key: String) { _items.value = _items.value.filter { it.key != key } }
    fun clear() { _items.value = emptyList() }
}

class MaxNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationStore.connected = true
        runCatching { activeNotifications?.forEach { handle(it) } }
    }

    override fun onListenerDisconnected() {
        NotificationStore.connected = false
        NotificationStore.clear()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) = handle(sbn)

    override fun onNotificationRemoved(sbn: StatusBarNotification) = NotificationStore.remove(sbn.key)

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return
        val label = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        NotificationStore.put(NotificationInfo(sbn.key, sbn.packageName, label, title, text, sbn.postTime))
    }

    companion object {
        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
            val me = ComponentName(context, MaxNotificationListener::class.java).flattenToString()
            return flat.split(":").any { it == me }
        }
    }
}
