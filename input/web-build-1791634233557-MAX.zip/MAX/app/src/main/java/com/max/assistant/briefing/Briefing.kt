package com.max.assistant.briefing

import com.max.assistant.news.NewsItem
import com.max.assistant.news.NewsResult
import com.max.assistant.settings.BriefingMode
import com.max.assistant.weather.WeatherReport
import java.time.Duration
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class BriefingSection(val title: String, val lines: List<String> = emptyList(), val items: List<NewsItem> = emptyList())

data class Briefing(
    val generatedAt: ZonedDateTime,
    val mode: BriefingMode,
    val sections: List<BriefingSection>,
    /** Honest notes: what was unavailable and why. Never filled with invented content. */
    val notes: List<String>,
) {
    /** Flat list of headlines in the order they are presented (for "explain the second headline"). */
    val headlines: List<NewsItem> get() = sections.flatMap { it.items }
}

data class BriefingInputs(
    val now: ZonedDateTime,
    val weather: WeatherReport?,
    val weatherNote: String?,
    val calendarLines: List<String>?,
    val calendarNote: String?,
    val reminderLines: List<String>,
    val news: NewsResult?,
    val newsNote: String?,
)

/** Pure composition logic (unit-tested): section selection, mode sizing, only/skip filters. */
object BriefingComposer {

    private val categoryTitles = linkedMapOf(
        "world" to "World", "india" to "India", "business" to "Business & economy", "technology" to "Technology & AI",
        "science" to "Science & space", "health" to "Health", "sports" to "Sports", "entertainment" to "Entertainment",
    )

    fun itemsPerCategory(mode: BriefingMode) = when (mode) { BriefingMode.SHORT -> 1; BriefingMode.NORMAL -> 2; BriefingMode.DETAILED -> 4 }
    fun maxCategories(mode: BriefingMode) = when (mode) { BriefingMode.SHORT -> 4; BriefingMode.NORMAL -> 8; BriefingMode.DETAILED -> 8 }

    fun compose(
        inputs: BriefingInputs,
        mode: BriefingMode,
        preferredCategories: Set<String>,
        excluded: Set<String> = emptySet(),
        only: String? = null,
    ): Briefing {
        val sections = ArrayList<BriefingSection>()
        val notes = ArrayList<String>()
        val date = inputs.now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy, h:mm a", Locale.getDefault()))

        if (only == null) {
            sections += BriefingSection("Date & time", listOf("$date (${inputs.now.zone.id})"))
            if (inputs.weather != null) {
                val w = inputs.weather
                val parts = mutableListOf("${w.placeLabel}: ${w.temperature}${w.temperatureUnit}, ${w.conditionText} (observed ${w.observedAtLocal})")
                if (w.todayMax != null && w.todayMin != null) parts += "Today's forecast: ${w.todayMin}–${w.todayMax}${w.temperatureUnit}"
                w.rainProbabilityPercent?.let { parts += "Chance of rain today: $it%" }
                sections += BriefingSection("Weather", parts)
            } else inputs.weatherNote?.let { notes += it }

            if (!inputs.calendarLines.isNullOrEmpty()) sections += BriefingSection("Calendar", inputs.calendarLines)
            else inputs.calendarNote?.let { notes += it }

            if (inputs.reminderLines.isNotEmpty()) sections += BriefingSection("Reminders & tasks", inputs.reminderLines)
        }

        val wantedCats = (if (only != null) setOf(only) else preferredCategories).filter { it !in excluded }
        val news = inputs.news
        if (news != null) {
            var count = 0
            for ((cat, title) in categoryTitles) {
                if (cat !in wantedCats) continue
                val items = news.items.filter { it.category == cat }.take(itemsPerCategory(mode))
                if (items.isEmpty()) continue // skip empty categories; never pad
                if (++count > maxCategories(mode)) break
                sections += BriefingSection(title, items = items)
            }
            news.failures.forEach { (cat, why) -> if (cat in wantedCats) notes += "Could not load $cat news: $why" }
            if (news.skippedUndatedOrStale > 0) notes += "${news.skippedUndatedOrStale} story(ies) skipped because they were older than 48h or had no publication date."
        } else inputs.newsNote?.let { notes += it }

        return Briefing(inputs.now, mode, sections, notes)
    }

    fun ageText(published: Instant?, now: Instant = Instant.now()): String {
        if (published == null) return "date unknown"
        val d = Duration.between(published, now)
        return when {
            d.isNegative -> "just now"
            d.toMinutes() < 60 -> "${d.toMinutes()} min ago"
            d.toHours() < 24 -> "${d.toHours()} h ago"
            else -> "${d.toDays()} d ago"
        }
    }

    /** Text for the screen/notification (includes sources). */
    fun toDisplayText(b: Briefing, now: Instant = Instant.now()): String {
        val sb = StringBuilder()
        var n = 0
        for (s in b.sections) {
            sb.appendLine(s.title.uppercase())
            s.lines.forEach { sb.appendLine("• $it") }
            s.items.forEach {
                n++
                sb.appendLine("$n. ${it.title} — ${it.source}, ${ageText(it.publishedAt, now)}")
                if (b.mode != BriefingMode.SHORT && it.summary.isNotBlank()) sb.appendLine("   ${it.summary.take(if (b.mode == BriefingMode.DETAILED) 400 else 160)}")
            }
            sb.appendLine()
        }
        b.notes.forEach { sb.appendLine("Note: $it") }
        return sb.toString().trim()
    }

    /** Text for TTS: no URLs, concise. */
    fun toSpeech(b: Briefing, now: Instant = Instant.now()): String {
        val sb = StringBuilder()
        var n = 0
        for (s in b.sections) {
            sb.append(s.title).append(". ")
            s.lines.forEach { sb.append(it).append(". ") }
            s.items.forEach {
                n++
                sb.append("Headline $n: ${it.title}. Source: ${it.source}. ")
                if (b.mode == BriefingMode.DETAILED && it.summary.isNotBlank()) sb.append(it.summary.take(300)).append(". ")
            }
        }
        if (b.notes.isNotEmpty()) sb.append("Some information was unavailable. See the screen for details.")
        return sb.toString()
    }
}
