package com.max.assistant.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.max.assistant.brain.AssistantState
import com.max.assistant.data.ActivityEntity
import com.max.assistant.notifications.MaxNotificationListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

@Composable
fun HomeScreen(vm: MainViewModel, onNavigate: (String) -> Unit) {
    val ctx = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val chat by vm.chat.collectAsStateWithLifecycle()
    val partial by vm.partial.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val logsFlow = remember { vm.container.db.activity().observeRecent() }
    val logs by logsFlow.collectAsStateWithLifecycle(emptyList())
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(chat.size) { if (chat.isNotEmpty()) listState.animateScrollToItem(chat.size - 1) }

    // "CORE ACTIVE" is only shown when the core really is working: the brain is not in the error state.
    val coreActive = state != AssistantState.ERROR

    Column(Modifier.fillMaxSize().background(MaxColors.Bg).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MAX", color = MaxColors.Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
                Text(if (coreActive) "CORE ACTIVE" else "CORE FAULT", color = if (coreActive) MaxColors.Ok else MaxColors.Error, fontSize = 11.sp, letterSpacing = 2.sp)
            }
            Chip("Settings") { onNavigate("settings") }
        }

        Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) {
            MaxOrb(state, settings.reduceAnimations)
        }
        Text(state.label, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = stateColor(state), fontSize = 14.sp, letterSpacing = 3.sp, fontWeight = FontWeight.SemiBold)
        Waveform(active = state == AssistantState.LISTENING || speaking, color = stateColor(state), modifier = Modifier.padding(vertical = 4.dp))
        if (partial.isNotEmpty()) Text("“$partial”", color = MaxColors.Dim, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)

        // Connection & permission status (real checks).
        val mic = granted(ctx, Manifest.permission.RECORD_AUDIO)
        val listener = MaxNotificationListener.isEnabled(ctx)
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusDot("Mic", mic); StatusDot("Notif access", listener)
            StatusDot("AI", vm.container.aiProvider.isConfigured()); StatusDot("Offline mode", settings.offlineOnly)
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 4.dp)) {
            val shortcuts = listOf("Briefing" to "briefing", "Affairs" to "affairs", "Reminders" to "reminders", "Automation" to "automation",
                "Memory" to "memory", "Security" to "security", "Apps" to "apps", "Scan text" to "ocr", "History" to "history", "Permissions" to "permissions", "Diagnostics" to "diagnostics")
            items(shortcuts) { (label, route) -> Chip(label) { onNavigate(route) } }
        }

        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(chat) { line ->
                val bg = if (line.fromUser) MaxColors.PanelHi else MaxColors.Panel
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                    Text(
                        line.text,
                        color = if (line.isError) MaxColors.Error else MaxColors.Text, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth(0.88f).clip(RoundedCornerShape(12.dp)).background(bg)
                            .border(1.dp, if (line.fromUser) MaxColors.Blue.copy(alpha = .5f) else MaxColors.Cyan.copy(alpha = .25f), RoundedCornerShape(12.dp)).padding(10.dp),
                    )
                }
            }
        }

        ActivityTicker(logs.take(3))

        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type a command", color = MaxColors.Dim) }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { vm.submit(input); input = "" }),
            )
            IconButton(onClick = { vm.submit(input); input = "" }, modifier = Modifier.semantics { contentDescription = "Send command" }) {
                Icon(Icons.Filled.Send, null, tint = MaxColors.Cyan)
            }
            val listening = state == AssistantState.LISTENING
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(if (listening) MaxColors.Ok else MaxColors.Cyan)
                    .clickable {
                        when {
                            speaking -> vm.stopSpeaking()
                            listening -> vm.stopListening()
                            else -> vm.startListening()
                        }
                    }
                    .semantics { contentDescription = if (listening) "Stop listening" else if (speaking) "Stop speaking" else "Start voice input" },
                contentAlignment = Alignment.Center,
            ) {
                Icon(if (speaking) Icons.Filled.Stop else if (listening) Icons.Filled.MicOff else Icons.Filled.Mic, null, tint = androidx.compose.ui.graphics.Color.Black)
            }
        }
    }
}

@Composable
fun Chip(label: String, onClick: () -> Unit) {
    Text(
        label, color = MaxColors.Cyan, fontSize = 12.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, MaxColors.Cyan.copy(alpha = .6f), RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

@Composable
fun StatusDot(label: String, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(if (on) MaxColors.Ok else MaxColors.Dim))
        Spacer(Modifier.size(4.dp))
        Text(label, color = MaxColors.Dim, fontSize = 11.sp)
    }
}

@Composable
fun ActivityTicker(items: List<ActivityEntity>) {
    if (items.isEmpty()) return
    val f = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaxColors.Panel).padding(8.dp)) {
        items.forEach { Text("${f.format(Date(it.timestampMs))}  ${it.level}  ${it.text}", color = MaxColors.Dim, fontSize = 10.sp, maxLines = 1) }
    }
}
