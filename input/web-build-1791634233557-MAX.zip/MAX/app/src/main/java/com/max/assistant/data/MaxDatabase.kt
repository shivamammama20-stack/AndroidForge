package com.max.assistant.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerAtMs: Long,
    /** "NONE" or "DAILY" */
    val repeat: String = "NONE",
    val done: Boolean = false,
    /** What the scheduler actually reported: "EXACT", "INEXACT" or "FAILED". */
    val scheduleMode: String = "FAILED",
)

@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAtMs: Long,
)

@Entity(tableName = "conversation")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    /** "USER" or "MAX" */
    val role: String,
    val text: String,
)

@Entity(tableName = "activity_log")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val level: String,
    val text: String,
)

@Entity(tableName = "security_events")
data class SecurityEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val risk: String,
    val text: String,
)

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val hour: Int,
    val minute: Int,
    /** A natural-language command run through MaxBrain (LOW-risk tools only when unattended). */
    val command: String,
    val enabled: Boolean = true,
    val lastRunMs: Long = 0,
    val lastResult: String = "Never run",
)

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY triggerAtMs ASC") fun observeAll(): Flow<List<ReminderEntity>>
    @Query("SELECT * FROM reminders ORDER BY triggerAtMs ASC") suspend fun all(): List<ReminderEntity>
    @Query("SELECT * FROM reminders WHERE id = :id") suspend fun get(id: Long): ReminderEntity?
    @Insert suspend fun insert(r: ReminderEntity): Long
    @Update suspend fun update(r: ReminderEntity)
    @Delete suspend fun delete(r: ReminderEntity)
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memory ORDER BY createdAtMs DESC") fun observeAll(): Flow<List<MemoryEntity>>
    @Query("SELECT * FROM memory ORDER BY createdAtMs DESC") suspend fun all(): List<MemoryEntity>
    @Insert suspend fun insert(m: MemoryEntity): Long
    @Update suspend fun update(m: MemoryEntity)
    @Query("DELETE FROM memory WHERE id = :id") suspend fun deleteById(id: Long)
    @Query("DELETE FROM memory") suspend fun deleteAll()
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversation ORDER BY timestampMs DESC LIMIT 300") fun observeRecent(): Flow<List<ConversationEntity>>
    @Insert suspend fun insert(c: ConversationEntity)
    @Query("DELETE FROM conversation") suspend fun deleteAll()
}

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activity_log ORDER BY timestampMs DESC LIMIT 200") fun observeRecent(): Flow<List<ActivityEntity>>
    @Insert suspend fun insert(a: ActivityEntity)
    @Query("DELETE FROM activity_log WHERE id NOT IN (SELECT id FROM activity_log ORDER BY timestampMs DESC LIMIT 500)") suspend fun trim()
    @Query("DELETE FROM activity_log") suspend fun deleteAll()
}

@Dao
interface SecurityEventDao {
    @Query("SELECT * FROM security_events ORDER BY timestampMs DESC LIMIT 200") fun observeRecent(): Flow<List<SecurityEventEntity>>
    @Insert suspend fun insert(e: SecurityEventEntity)
    @Query("DELETE FROM security_events") suspend fun deleteAll()
}

@Dao
interface AutomationDao {
    @Query("SELECT * FROM automations ORDER BY hour, minute") fun observeAll(): Flow<List<AutomationEntity>>
    @Query("SELECT * FROM automations") suspend fun all(): List<AutomationEntity>
    @Query("SELECT * FROM automations WHERE id = :id") suspend fun get(id: Long): AutomationEntity?
    @Insert suspend fun insert(a: AutomationEntity): Long
    @Update suspend fun update(a: AutomationEntity)
    @Delete suspend fun delete(a: AutomationEntity)
}

@Database(
    entities = [
        ReminderEntity::class, MemoryEntity::class, ConversationEntity::class, ActivityEntity::class,
        SecurityEventEntity::class, AutomationEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class MaxDatabase : RoomDatabase() {
    abstract fun reminders(): ReminderDao
    abstract fun memory(): MemoryDao
    abstract fun conversation(): ConversationDao
    abstract fun activity(): ActivityDao
    abstract fun securityEvents(): SecurityEventDao
    abstract fun automations(): AutomationDao

    companion object {
        fun build(context: Context): MaxDatabase =
            Room.databaseBuilder(context.applicationContext, MaxDatabase::class.java, "max.db").build()
    }
}
