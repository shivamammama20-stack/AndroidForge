package com.max.assistant

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.max.assistant.ui.AffairsScreen
import com.max.assistant.ui.AppSearchScreen
import com.max.assistant.ui.AutomationScreen
import com.max.assistant.ui.BriefingScreen
import com.max.assistant.ui.DiagnosticsScreen
import com.max.assistant.ui.HistoryScreen
import com.max.assistant.ui.HomeScreen
import com.max.assistant.ui.LocalPermissionRequester
import com.max.assistant.ui.MainViewModel
import com.max.assistant.ui.MaxTheme
import com.max.assistant.ui.MemoryScreen
import com.max.assistant.ui.OcrScreen
import com.max.assistant.ui.PermissionScreen
import com.max.assistant.ui.RemindersScreen
import com.max.assistant.ui.SecurityScreen
import com.max.assistant.ui.SettingsScreen
import com.max.assistant.ui.UiEvent

class MainActivity : FragmentActivity() {
    private val vm: MainViewModel by viewModels()
    private var lastRequested: String = ""
    private val startListeningFlag = mutableStateOf(false)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            vm.onPermissionResult(granted, lastRequested)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startListeningFlag.value = intent?.getBooleanExtra(EXTRA_START_LISTENING, false) == true
        setContent {
            MaxTheme {
                val nav = rememberNavController()
                val requester: (String) -> Unit = { p ->
                    lastRequested = p
                    if (p == android.Manifest.permission.POST_NOTIFICATIONS && Build.VERSION.SDK_INT < 33) { /* not needed below API 33 */ }
                    else permissionLauncher.launch(p)
                }
                LaunchedEffect(Unit) {
                    vm.events.collect { e ->
                        when (e) {
                            is UiEvent.Navigate -> navigateRoute(nav, e.route)
                            is UiEvent.RequestPermission -> requester(e.permission)
                            UiEvent.Authenticate -> authenticate()
                            is UiEvent.OpenUrl -> runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(e.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }
                    }
                }
                LaunchedEffect(startListeningFlag.value) {
                    if (startListeningFlag.value) {
                        startListeningFlag.value = false
                        if (!vm.container.voice.hasPermission()) requester(android.Manifest.permission.RECORD_AUDIO) else vm.startListening()
                    }
                }
                CompositionLocalProvider(LocalPermissionRequester provides requester) {
                    NavHost(nav, startDestination = "home") {
                        composable("home") {
                            HomeScreen(vm) { route ->
                                if (route == "mic_permission") requester(android.Manifest.permission.RECORD_AUDIO) else navigateRoute(nav, route)
                            }
                        }
                        val back = { nav.popBackStack(); Unit }
                        composable("history") { HistoryScreen(vm, back) }
                        composable("apps") { AppSearchScreen(vm, back) }
                        composable("briefing") { BriefingScreen(vm, back) }
                        composable("affairs") { AffairsScreen(vm, back) }
                        composable("reminders") { RemindersScreen(vm, back) }
                        composable("automation") { AutomationScreen(vm, back) }
                        composable("memory") { MemoryScreen(vm, back) }
                        composable("security") { SecurityScreen(vm, back) }
                        composable("permissions") { PermissionScreen(back) }
                        composable("settings") { SettingsScreen(vm, back) }
                        composable("diagnostics") { DiagnosticsScreen(vm, back) }
                        composable("ocr") { OcrScreen(back) }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_START_LISTENING, false)) startListeningFlag.value = true
    }

    private fun navigateRoute(nav: androidx.navigation.NavController, route: String) {
        when (route) {
            "notification_listener" -> runCatching { startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            else -> nav.navigate(route) { launchSingleTop = true }
        }
    }

    /** Sensitive actions only run after the system biometric / device-credential prompt succeeds. */
    private fun authenticate() {
        val allowed = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(allowed) != BiometricManager.BIOMETRIC_SUCCESS) {
            vm.onAuthResult(false) // no screen lock configured: refuse rather than skip verification
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = vm.onAuthResult(true)
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) = vm.onAuthResult(false)
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder().setTitle("Verify it's you").setSubtitle("MAX needs confirmation for this action")
                .setAllowedAuthenticators(allowed).build()
        )
    }

    companion object { const val EXTRA_START_LISTENING = "max_start_listening" }
}
