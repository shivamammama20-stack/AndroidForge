package com.max.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Optional. Does nothing unless the user enables it in system settings AND a command calls it.
 * It never records events, never reads password fields, and never runs in the background on its own.
 */
class MaxAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally ignored: no passive monitoring */ }
    override fun onInterrupt() {}

    /** Visible text of the current window (password fields are skipped). */
    fun readVisibleText(limit: Int = 4000): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length >= limit) return
            if (!n.isPassword) {
                n.text?.toString()?.takeIf { it.isNotBlank() }?.let { sb.append(it).append('\n') }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().take(limit)
    }

    /** Clicks the first visible clickable element whose text contains [label]. Returns true only if the click was dispatched. */
    fun clickByText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label)
        for (n in nodes) {
            if (n.isPassword) continue
            var cur: AccessibilityNodeInfo? = n
            while (cur != null) {
                if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur = cur.parent
            }
        }
        return false
    }

    fun scrollForward(): Boolean {
        val root = rootInActiveWindow ?: return false
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        return find(root)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    }

    companion object {
        @Volatile var instance: MaxAccessibilityService? = null

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            val me = ComponentName(context, MaxAccessibilityService::class.java).flattenToString()
            return flat.split(":").any { it.equals(me, ignoreCase = true) }
        }
    }
}
