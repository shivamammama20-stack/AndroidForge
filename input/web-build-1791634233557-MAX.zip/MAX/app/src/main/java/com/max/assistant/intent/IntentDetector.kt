package com.max.assistant.intent

enum class IntentType {
    OPEN_APP, SEARCH_APPS, CALL, MESSAGE, SEARCH_CONTACT, READ_NOTIFICATIONS, NAVIGATE, MAP_SEARCH,
    MEDIA_PLAY, MEDIA_PAUSE, MEDIA_NEXT, MEDIA_PREVIOUS, VOLUME,
    REMINDER, ALARM, TIMER, LIST_REMINDERS, CALENDAR, WEATHER, CURRENT_AFFAIRS, DAILY_BRIEFING,
    BRIEFING_FOLLOWUP, WEB_SEARCH, CAMERA_OCR, DEVICE_INFO, SETTINGS, MEMORY, SECURITY, AUTOMATION,
    CONFIRM_YES, CONFIRM_NO, STOP_SPEAKING, REPEAT, CONVERSATION, UNSUPPORTED,
}

data class ParsedIntent(
    val type: IntentType,
    val entities: Map<String, String> = emptyMap(),
    val raw: String,
)

/**
 * Deterministic, offline intent detection for English / Hindi (romanised) / Hinglish.
 * An online AIProvider may refine this later, but tool execution never depends on AI text.
 */
class IntentDetector {

    private val wake = Regex("""^\s*(hey\s+|ok\s+)?(max|jarvis)[,:\s]+""", RegexOption.IGNORE_CASE)

    fun detect(input: String): ParsedIntent {
        val raw = input.trim()
        val t = wake.replace(raw, "").trim().lowercase().trimEnd('.', '!', '?')
        fun i(type: IntentType, vararg e: Pair<String, String>) = ParsedIntent(type, e.toMap(), raw)

        if (t.isEmpty()) return i(IntentType.CONVERSATION)

        // Confirmation / control words first (short utterances).
        if (t in setOf("yes", "yeah", "yep", "confirm", "haan", "han", "ha", "haan karo", "ok do it")) return i(IntentType.CONFIRM_YES)
        if (t in setOf("no", "nope", "cancel", "nahi", "nahin", "mat karo", "stop it", "never mind")) return i(IntentType.CONFIRM_NO)
        if (Regex("""^(stop( speaking| talking)?|chup|ruko|be quiet)$""").matches(t)) return i(IntentType.STOP_SPEAKING)
        if (Regex("""^(repeat( that)?|dobara( bolo)?|phir se bolo|say that again)$""").matches(t)) return i(IntentType.REPEAT)

        // Briefing follow-ups (need prior context).
        Regex("""(explain|tell me more about|detail|samjhao|batao)\s.*\b(first|second|third|fourth|fifth|1st|2nd|3rd|4th|5th|pehli|doosri|teesri)\b.*(headline|news|story|khabar)?""")
            .find(t)?.let { m -> return i(IntentType.BRIEFING_FOLLOWUP, "action" to "explain", "index" to ordinal(m.groupValues[2]).toString()) }
        if (Regex("""explain this( news)?( in detail)?|more about this|give me both sides|both sides|show me the original source|original source|what does this mean for india""")
                .containsMatchIn(t)) {
            val action = when {
                "both sides" in t -> "both_sides"
                "source" in t -> "source"
                "india" in t -> "india_impact"
                else -> "explain"
            }
            return i(IntentType.BRIEFING_FOLLOWUP, "action" to action)
        }
        Regex("""^skip (\w+)""").find(t)?.let { return i(IntentType.BRIEFING_FOLLOWUP, "action" to "skip", "category" to it.groupValues[1]) }
        Regex("""^only (\w+)( news)?$""").find(t)?.let { return i(IntentType.BRIEFING_FOLLOWUP, "action" to "only", "category" to it.groupValues[1]) }
        if (t == "continue the briefing" || t == "continue briefing" || t == "continue") return i(IntentType.BRIEFING_FOLLOWUP, "action" to "continue")

        // Daily briefing
        if (Regex("""start (my |the |a )?(daily |morning |evening )?briefing|begin (my |the )?briefing|briefing (start|shuru)|briefing shuru karo|^briefing$|daily briefing|morning briefing|evening briefing|briefing do|aaj ki briefing|what'?s happening in the world|tell me only the important news""")
                .containsMatchIn(t)) {
            val mode = when {
                "only the important" in t || "short" in t || "quick" in t -> "SHORT"
                "detail" in t || "full" in t -> "DETAILED"
                else -> "NORMAL"
            }
            val part = if ("evening" in t) "evening" else if ("morning" in t) "morning" else "now"
            return i(IntentType.DAILY_BRIEFING, "mode" to mode, "part" to part)
        }

        if (Regex("""current affairs|world news|news batao|aaj ki khabar|headlines|latest news""").containsMatchIn(t)) {
            val cat = categoryOf(t)
            return i(IntentType.CURRENT_AFFAIRS, *listOfNotNull(cat?.let { "category" to it }).toTypedArray())
        }

        if (Regex("""weather|mausam|temperature|barish|rain forecast""").containsMatchIn(t)) {
            val place = Regex("""(?:in|at|for)\s+([a-z ]{2,30})$""").find(t)?.groupValues?.get(1)?.trim()
            return i(IntentType.WEATHER, *listOfNotNull(place?.let { "place" to it }).toTypedArray())
        }

        // Reminders / alarms / timers (before generic "set")
        if (Regex("""\btimer\b""").containsMatchIn(t)) return i(IntentType.TIMER, "when" to t)
        if (Regex("""\balarm\b""").containsMatchIn(t) && !t.contains("remind")) return i(IntentType.ALARM, "when" to t)
        if (Regex("""(show|list|meri|my)\s.*reminders?""").containsMatchIn(t)) return i(IntentType.LIST_REMINDERS)
        if (Regex("""remind me|yaad dila|yaad dilana|reminder""").containsMatchIn(t)) {
            val about = Regex("""(?:to|about|ki|ke liye)\s+(.+?)(?:\s+(?:at|on|in|kal|aaj|tomorrow|today)\b.*)?$""").find(t)?.groupValues?.get(1)
            return i(IntentType.REMINDER, "when" to t, "text" to (about ?: "Reminder"))
        }
        if (Regex("""calendar|my events|schedule today|meri meetings|appointments""").containsMatchIn(t)) return i(IntentType.CALENDAR)

        // Calls & messages
        Regex("""^(?:usko|isko|unko|use)\s+(?:message|msg|sms|text)\s*(?:bhejo|karo|send)?(?:\s+(.+))?$""").find(t)?.let {
            return i(IntentType.MESSAGE, "contact" to "__last__", "body" to it.groupValues[1])
        }
        Regex("""^(?:message|text|msg)\s+(?:him|her|them)(?:\s+(?:saying|that)\s+(.+))?$""").find(t)?.let {
            return i(IntentType.MESSAGE, "contact" to "__last__", "body" to it.groupValues[1])
        }
        if (Regex("""^(?:usko|isko|unko|use)\s+(?:call|phone)\s*(?:karo|kar do)?$|^call\s+(?:him|her|them|back)$""").containsMatchIn(t))
            return i(IntentType.CALL, "contact" to "__last__")
        Regex("""^(?:call|dial|phone)\s+(.+)$""").find(t)?.let { return i(IntentType.CALL, "contact" to cleanName(it.groupValues[1])) }
        Regex("""^(.+?)\s+ko\s+(?:call|phone|fone)\s*(?:karo|kar do|lagao)?$""").find(t)?.let { return i(IntentType.CALL, "contact" to cleanName(it.groupValues[1])) }
        Regex("""^(?:message|text|sms|whatsapp)\s+(.+?)(?:\s+(?:saying|that|ki)\s+(.+))?$""").find(t)?.let {
            return i(IntentType.MESSAGE, "contact" to cleanName(it.groupValues[1]), "body" to it.groupValues[2])
        }
        Regex("""^(.+?)\s+ko\s+(?:message|msg|sms|text)\s*(?:bhejo|karo|send)?(?:\s+(.+))?$""").find(t)?.let {
            return i(IntentType.MESSAGE, "contact" to cleanName(it.groupValues[1]), "body" to it.groupValues[2])
        }
        Regex("""^(?:find|search)\s+contact\s+(.+)$""").find(t)?.let { return i(IntentType.SEARCH_CONTACT, "contact" to it.groupValues[1]) }

        // Navigation / maps
        Regex("""^(?:navigate|take me|directions?)\s+(?:to\s+)?(.+)$""").find(t)?.let { return i(IntentType.NAVIGATE, "destination" to it.groupValues[1]) }
        Regex("""^(.+?)\s+(?:ka|ke liye)\s+(?:route|rasta|navigate)\s*(?:batao|karo)?$""").find(t)?.let { return i(IntentType.NAVIGATE, "destination" to it.groupValues[1]) }
        Regex("""^(?:find|show|search)\s+(.+?)\s+(?:on map|on maps|nearby|near me)$""").find(t)?.let { return i(IntentType.MAP_SEARCH, "query" to it.groupValues[1]) }

        // Media
        if (Regex("""^(pause|pause (music|song|video)|ruk ja)""").containsMatchIn(t)) return i(IntentType.MEDIA_PAUSE)
        if (Regex("""^(next( song| track)?|agla gaana)$""").matches(t)) return i(IntentType.MEDIA_NEXT)
        if (Regex("""^(previous( song| track)?|pichla gaana)$""").matches(t)) return i(IntentType.MEDIA_PREVIOUS)
        if (Regex("""^(play|resume)( music| song| media)?$""").matches(t)) return i(IntentType.MEDIA_PLAY)
        Regex("""volume\s+(up|down|badhao|kam karo|mute)""").find(t)?.let { return i(IntentType.VOLUME, "direction" to it.groupValues[1]) }

        // Device
        if (Regex("""battery|device info|phone info|which android""").containsMatchIn(t)) return i(IntentType.DEVICE_INFO)
        Regex("""(?:open )?(wifi|bluetooth|notification|battery|display|sound|app|permission|accessibility|assistant)s? settings?""").find(t)
            ?.let { return i(IntentType.SETTINGS, "page" to it.groupValues[1]) }
        if (Regex("""read (my )?notifications?|notifications? (summary|batao)|koi notification""").containsMatchIn(t)) return i(IntentType.READ_NOTIFICATIONS)
        if (Regex("""scan text|read text|ocr|camera""").containsMatchIn(t)) return i(IntentType.CAMERA_OCR)

        // Memory / security / automation
        Regex("""^(?:remember|yaad rakho)\s+(?:that\s+)?(.+)$""").find(t)?.let { return i(IntentType.MEMORY, "action" to "save", "text" to it.groupValues[1]) }
        if (Regex("""what do you remember|memory center|show memory""").containsMatchIn(t)) return i(IntentType.MEMORY, "action" to "show")
        if (Regex("""security (log|dashboard|status)""").containsMatchIn(t)) return i(IntentType.SECURITY)
        if (Regex("""automation""").containsMatchIn(t)) return i(IntentType.AUTOMATION)

        // Apps
        Regex("""^(?:open|launch|start)\s+(.+)$""").find(t)?.let { return i(IntentType.OPEN_APP, "app" to cleanName(it.groupValues[1])) }
        Regex("""^(.+?)\s+(?:kholo|chalu karo|open karo|khol do)$""").find(t)?.let { return i(IntentType.OPEN_APP, "app" to cleanName(it.groupValues[1])) }
        Regex("""^(?:search|find)\s+app\s+(.+)$""").find(t)?.let { return i(IntentType.SEARCH_APPS, "query" to it.groupValues[1]) }

        Regex("""^(?:search|google|look up|search for)\s+(.+)$""").find(t)?.let { return i(IntentType.WEB_SEARCH, "query" to it.groupValues[1]) }

        // Anything unknown is general conversation (answered by an AI provider if configured; otherwise honestly declined).
        return i(IntentType.CONVERSATION, "text" to t)
    }

    private fun cleanName(s: String) = s.replace(Regex("""\b(the|app|please|ko|karo)\b"""), "").replace(Regex("\\s+"), " ").trim()

    fun ordinal(w: String): Int = when (w) {
        "first", "1st", "pehli" -> 1
        "second", "2nd", "doosri" -> 2
        "third", "3rd", "teesri" -> 3
        "fourth", "4th" -> 4
        "fifth", "5th" -> 5
        else -> 1
    }

    fun categoryOf(t: String): String? = when {
        Regex("""\b(tech|technology|ai)\b""").containsMatchIn(t) -> "technology"
        Regex("""\b(sports?|cricket|football)\b""").containsMatchIn(t) -> "sports"
        Regex("""\b(business|economy|market|stocks?)\b""").containsMatchIn(t) -> "business"
        Regex("""\b(science|space)\b""").containsMatchIn(t) -> "science"
        Regex("""\b(health)\b""").containsMatchIn(t) -> "health"
        Regex("""\b(entertainment|movies?|bollywood)\b""").containsMatchIn(t) -> "entertainment"
        Regex("""\b(india|national|bharat)\b""").containsMatchIn(t) -> "india"
        Regex("""\b(world|international|duniya)\b""").containsMatchIn(t) -> "world"
        else -> null
    }
}
