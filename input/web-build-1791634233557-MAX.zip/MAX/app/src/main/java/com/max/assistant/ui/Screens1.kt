package com.max.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.max.assistant.data.AutomationEntity
import com.max.assistant.reminders.AutomationScheduler
import com.max.assistant.reminders.ReminderScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lets any screen ask the Activity to request a runtime permission. */
val LocalPermissionRequester = compositionLocalOf<(String) -> Unit> { {} }

@Composable
fun ScreenScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaxColors.Bg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("‹ Back", color = MaxColors.Cyan) }
            Text(title, color = MaxColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaxColors.Panel).padding(12.dp)) { content() }
}

@Composable
fun Dim(text: String) = Text(text, color = MaxColors.Dim, fontSize = 12.sp)

@Composable
fun HistoryScreen(vm: MainViewModel, onBack: () -> Unit) {
    val flow = remember { vm.container.db.conversation().observeRecent() }
    val items by flow.collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    val f = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }
    ScreenScaffold("Conversation history", onBack) {
        Row { OutlinedButton(onClick = { scope.launch { vm.container.db.conversation().deleteAll() } }) { Text("Delete history") } }
        if (items.isEmpty()) Dim("Nothing stored. History is skipped in privacy mode or when turned off in Settings.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(items) { Card { Dim("${f.format(Date(it.timestampMs))} · ${it.role}"); Text(it.text, color = MaxColors.Text, fontSize = 13.sp) } }
        }
    }
}

@Composable
fun AppSearchScreen(vm: MainViewModel, onBack: () -> Unit) {
    var q by remember { mutableStateOf("") }
    var refresh by remember { mutableStateOf(0) }
    val apps = remember(q, refresh) { if (q.isBlank()) vm.container.apps.launchableApps(refresh > 0) else vm.container.apps.search(q) }
    ScreenScaffold("App search", onBack) {
        OutlinedTextField(q, { q = it }, label = { Text("App name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { refresh++ }) { Text("Refresh list") }
        }
        Dim("${apps.size} visible apps. Android hides some packages from MAX (package visibility).")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(apps) { a ->
                Card(Modifier.padding(top = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(a.label, color = MaxColors.Text); Dim(a.packageName) }
                        TextButton(onClick = { vm.submit("open ${a.label}"); onBack() }) { Text("Open") }
                    }
                }
            }
        }
    }
}

@Composable
fun BriefingScreen(vm: MainViewModel, onBack: () -> Unit) {
    val result by vm.screenResult.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    ScreenScaffold("Daily Briefing", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.submit("give me a short daily briefing", true) }) { Text("Short") }
            Button(onClick = { vm.submit("give me my daily briefing", true) }) { Text("Normal") }
            Button(onClick = { vm.submit("give me a detailed daily briefing", true) }) { Text("Detailed") }
        }
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.stopSpeaking() }, enabled = speaking) { Text("Stop speaking") }
            OutlinedButton(onClick = { vm.submit("repeat that", true) }) { Text("Repeat") }
            OutlinedButton(onClick = { vm.submit("explain the first headline", true) }) { Text("Explain #1") }
        }
        Dim(if (busy) "Working…" else "Short ≈1–2 min, Normal ≈3–5 min, Detailed ≈8–15 min when enough news exists (targets, not guarantees). Schedule it in Automation Center.")
        Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
            Text(result.ifBlank { "Choose a mode. Sections with no available data are skipped, never filled in." }, color = MaxColors.Text, fontSize = 13.sp)
        }
    }
}

@Composable
fun AffairsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val result by vm.screenResult.collectAsStateWithLifecycle()
    val cats = remember { vm.container.news.supportedCategories() }
    ScreenScaffold("Current Affairs", onBack) {
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { c -> Chip(c.replaceFirstChar { it.uppercase() }) { vm.submit("$c current affairs", true) } }
        }
        Dim("Sources: public RSS feeds (BBC, The Hindu). Stories older than 48h or without a date are dropped. Politics, defence and auto categories have no feed configured yet.")
        Column(Modifier.verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
            Text(result.ifBlank { "Pick a category." }, color = MaxColors.Text, fontSize = 13.sp)
        }
    }
}

@Composable
fun RemindersScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val flow = remember { vm.container.db.reminders().observeAll() }
    val list by flow.collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    val f = remember { SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()) }
    val events = remember { mutableStateOf(emptyList<String>()) }
    ScreenScaffold("Reminders & calendar", onBack) {
        OutlinedTextField(text, { text = it }, label = { Text("e.g. remind me tomorrow 6 pm to call mom") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.submit(if (text.contains("remind", true) || text.contains("yaad", true)) text else "remind me $text"); text = "" }) { Text("Add") }
            OutlinedButton(onClick = { vm.submit("show my calendar") }) { Text("Calendar today") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(list) { r ->
                Card {
                    Text(r.text, color = if (r.done) MaxColors.Dim else MaxColors.Text)
                    Dim("${f.format(Date(r.triggerAtMs))} · ${r.repeat} · scheduled: ${r.scheduleMode}${if (r.done) " · done" else ""}")
                    Row {
                        if (!r.done) TextButton(onClick = {
                            scope.launch { ReminderScheduler.cancel(context, r.id); vm.container.db.reminders().update(r.copy(done = true)) }
                        }) { Text("Complete") }
                        TextButton(onClick = { scope.launch { ReminderScheduler.cancel(context, r.id); vm.container.db.reminders().delete(r) } }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun AutomationScreen(vm: MainViewModel, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val flow = remember { vm.container.db.automations().observeAll() }
    val list by flow.collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var hh by remember { mutableStateOf("7") }
    var mm by remember { mutableStateOf("0") }
    var cmd by remember { mutableStateOf("daily briefing") }
    val f = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }

    fun add(n: String, h: Int, m: Int, c: String) = scope.launch {
        val e = AutomationEntity(name = n, hour = h, minute = m, command = c)
        val id = vm.container.db.automations().insert(e)
        AutomationScheduler.schedule(context, e.copy(id = id))
    }

    ScreenScaffold("Automation Center", onBack) {
        Dim("Time-based automations run a command through MAX once a day using WorkManager. Android may delay them in battery saver / Doze. Risky actions (calls, messages, notifications) are never run unattended.")
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { add("Morning briefing", 7, 0, "daily briefing") }) { Text("+ Morning 07:00") }
            OutlinedButton(onClick = { add("Evening briefing", 19, 0, "evening briefing") }) { Text("+ Evening 19:00") }
        }
        Card {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(hh, { hh = it.filter(Char::isDigit).take(2) }, label = { Text("Hour") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(mm, { mm = it.filter(Char::isDigit).take(2) }, label = { Text("Min") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            OutlinedTextField(cmd, { cmd = it }, label = { Text("Command (e.g. weather in Delhi)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                val h = hh.toIntOrNull(); val m = mm.toIntOrNull()
                if (name.isNotBlank() && h != null && m != null && h in 0..23 && m in 0..59) { add(name, h, m, cmd); name = "" }
            }) { Text("Create") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(list) { a ->
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(a.name, color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                            Dim("Trigger: daily at %02d:%02d · Action: \"%s\"".format(a.hour, a.minute, a.command))
                            Dim("Permissions: whatever the command's tool needs · Last: ${if (a.lastRunMs > 0) f.format(Date(a.lastRunMs)) else "—"} — ${a.lastResult}")
                        }
                        Switch(checked = a.enabled, onCheckedChange = { on ->
                            scope.launch {
                                vm.container.db.automations().update(a.copy(enabled = on))
                                if (on) AutomationScheduler.schedule(context, a.copy(enabled = true)) else AutomationScheduler.cancel(context, a.id)
                            }
                        })
                    }
                    TextButton(onClick = { scope.launch { AutomationScheduler.cancel(context, a.id); vm.container.db.automations().delete(a) } }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
fun MemoryScreen(vm: MainViewModel, onBack: () -> Unit) {
    val flow = remember { vm.container.db.memory().observeAll() }
    val list by flow.collectAsStateWithLifecycle(emptyList())
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var editingId by remember { mutableStateOf<Long?>(null) }
    ScreenScaffold("Memory Center", onBack) {
        Dim("Stored only on this device. MAX never uploads memory to an AI provider. Short-term chat context is kept in RAM and cleared on 'Clear context'.")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Memory enabled", color = MaxColors.Text, modifier = Modifier.weight(1f))
            Switch(settings.memoryEnabled, { on -> scope.launch { vm.container.settings.update { it.copy(memoryEnabled = on) } } })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Save conversation history", color = MaxColors.Text, modifier = Modifier.weight(1f))
            Switch(settings.storeConversationHistory, { on -> scope.launch { vm.container.settings.update { it.copy(storeConversationHistory = on) } } })
        }
        OutlinedTextField(text, { text = it }, label = { Text(if (editingId == null) "Add a memory" else "Edit memory") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                scope.launch {
                    val id = editingId
                    if (text.isNotBlank()) {
                        if (id == null) vm.container.db.memory().insert(com.max.assistant.data.MemoryEntity(text = text, createdAtMs = System.currentTimeMillis()))
                        else list.firstOrNull { it.id == id }?.let { vm.container.db.memory().update(it.copy(text = text)) }
                    }
                    text = ""; editingId = null
                }
            }) { Text(if (editingId == null) "Save" else "Update") }
            OutlinedButton(onClick = { vm.clearChat() }) { Text("Clear context") }
            OutlinedButton(onClick = { scope.launch { vm.container.db.memory().deleteAll() } }) { Text("Delete all") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(list) { m ->
                Card {
                    Text(m.text, color = MaxColors.Text)
                    Row {
                        TextButton(onClick = { editingId = m.id; text = m.text }) { Text("Edit") }
                        TextButton(onClick = { scope.launch { vm.container.db.memory().deleteById(m.id) } }) { Text("Delete") }
                    }
                }
            }
        }
    }
}
