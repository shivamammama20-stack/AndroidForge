package com.max.assistant.brain

import com.max.assistant.core.RiskLevel

enum class ConfirmationPolicy { NEVER_FOR_LOW, ASK_MEDIUM_AND_UP, ASK_HIGH_AND_UP }

data class RiskDecision(val level: RiskLevel, val needsConfirmation: Boolean, val needsAuthentication: Boolean, val reason: String)

/**
 * Risk is based on the actual operation + arguments, not the user's wording.
 */
class RiskEngine(private val protectedPackages: () -> Set<String> = { emptySet() }) {

    fun assess(toolId: String, base: RiskLevel, args: Map<String, String>, policy: ConfirmationPolicy = ConfirmationPolicy.ASK_MEDIUM_AND_UP): RiskDecision {
        var level = base
        var reason = "Base risk of $toolId"

        when (toolId) {
            "open_app" -> {
                val pkg = args["package"].orEmpty()
                if (pkg in protectedPackages()) { level = RiskLevel.SENSITIVE; reason = "App is on your protected list" }
            }
            "message_contact" -> if (args["body"].isNullOrBlank().not()) { level = maxOf(level, RiskLevel.HIGH); reason = "Message with content" }
            "call_contact" -> { level = maxOf(level, RiskLevel.HIGH); reason = "Starting a call" }
            "read_notifications" -> { level = maxOf(level, RiskLevel.SENSITIVE); reason = "Private notification content" }
            "memory" -> if (args["action"] == "delete_all") { level = RiskLevel.HIGH; reason = "Deletes all memory" }
        }

        val needsAuth = level == RiskLevel.SENSITIVE
        val needsConfirm = needsAuth || when (policy) {
            ConfirmationPolicy.NEVER_FOR_LOW -> level >= RiskLevel.HIGH
            ConfirmationPolicy.ASK_MEDIUM_AND_UP -> level >= RiskLevel.MEDIUM
            ConfirmationPolicy.ASK_HIGH_AND_UP -> level >= RiskLevel.HIGH
        }
        return RiskDecision(level, needsConfirm, needsAuth, reason)
    }

    private fun maxOf(a: RiskLevel, b: RiskLevel) = if (a.ordinal >= b.ordinal) a else b
}
