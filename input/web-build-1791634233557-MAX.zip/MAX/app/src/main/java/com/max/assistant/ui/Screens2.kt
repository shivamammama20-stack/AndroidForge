package com.max.assistant.ui

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.max.assistant.accessibility.MaxAccessibilityService
import com.max.assistant.assistant.DefaultAssistant
import com.max.assistant.brain.ConfirmationPolicy
import com.max.assistant.notifications.MaxNotificationListener
import com.max.assistant.security.SecretStore
import com.max.assistant.settings.BriefingMode
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun has(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

private data class PermRow(
    val name: String, val granted: Boolean, val why: String, val ifDenied: String,
    val actionLabel: String, val action: () -> Unit,
)

@Composable
fun PermissionScreen(onBack: () -> Unit) {
    val c = LocalContext.current
    val request = LocalPermissionRequester.current
    var tick by remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }
    fun open(i: Intent) { runCatching { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }

    val rows = remember(tick) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val am = c.getSystemService(AlarmManager::class.java)
        listOf(
            PermRow("Microphone", has(c, Manifest.permission.RECORD_AUDIO), "Voice commands via Android's speech recognizer.", "Voice input is off; typing still works.", "Allow") { request(Manifest.permission.RECORD_AUDIO) },
            PermRow("Notifications", nm.areNotificationsEnabled(), "Delivers reminders, briefings and automation results.", "Reminders are saved and rung internally but you will not see them.", "Allow") {
                if (Build.VERSION.SDK_INT >= 33) request(Manifest.permission.POST_NOTIFICATIONS)
                else open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName))
            },
            PermRow("Contacts", has(c, Manifest.permission.READ_CONTACTS), "Find who to call or message.", "Calling/messaging by name is unavailable.", "Allow") { request(Manifest.permission.READ_CONTACTS) },
            PermRow("Camera", has(c, Manifest.permission.CAMERA), "Text scanner (only when you open it and tap the shutter).", "Scanner is unavailable.", "Allow") { request(Manifest.permission.CAMERA) },
            PermRow("Location (approximate)", has(c, Manifest.permission.ACCESS_COARSE_LOCATION), "Optional: weather for where you are. You can set a city instead.", "Weather needs a city set in Settings.", "Allow") { request(Manifest.permission.ACCESS_COARSE_LOCATION) },
            PermRow("Calendar (read)", has(c, Manifest.permission.READ_CALENDAR), "Show events in your briefing. Stays on device.", "Briefing skips the calendar section.", "Allow") { request(Manifest.permission.READ_CALENDAR) },
            PermRow("Exact alarms", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms(), "Lets reminders fire at the exact minute.", "Reminders may fire a few minutes late.", "Open") {
                if (Build.VERSION.SDK_INT >= 31) open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${c.packageName}")))
            },
            PermRow("Notification access", MaxNotificationListener.isEnabled(c), "Lets you ask MAX to summarise current notifications. Content is kept in memory only.", "Notification summaries are unavailable.", "Open settings") { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            PermRow("Accessibility (optional)", MaxAccessibilityService.isEnabled(c), "Optional screen reading/tapping on request. Never runs hidden.", "Screen-reading features are unavailable.", "Open settings") { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            PermRow("Default assistant", false, "Lets the assist gesture open MAX. Android does not let apps check this reliably, so it shows as 'not confirmed'.", "MAX opens from its icon only.", "Open settings") { open(DefaultAssistant.settingsIntent()) },
            PermRow("Phone / SMS", true, "Not requested. MAX opens your dialer or SMS composer; you press call/send.", "n/a", "") {},
        )
    }
    ScreenScaffold("Permission Center", onBack) {
        Dim("Permissions are requested only when needed. To revoke any of them: Android Settings → Apps → MAX → Permissions.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(rows) { r ->
                Card {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(r.name, color = MaxColors.Text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text(if (r.granted) "ON" else "OFF", color = if (r.granted) MaxColors.Ok else MaxColors.Warn)
                    }
                    Dim("Why: ${r.why}")
                    Dim("If denied: ${r.ifDenied}")
                    if (r.actionLabel.isNotEmpty() && !r.granted) OutlinedButton(onClick = r.action) { Text(r.actionLabel) }
                }
            }
            item {
                Card {
                    Text("Default assistant & lock screen", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                    Dim("1) Open the settings screen below and choose MAX as the digital assistant app (on OxygenOS: Settings → Apps → Default apps → Digital assistant app). 2) Then use your assist gesture. MAX never listens when the phone is off, never wakes on a hotword, and cannot bypass the lock screen: sensitive actions need you to unlock/verify.")
                    OutlinedButton(onClick = { open(DefaultAssistant.settingsIntent()) }) { Text("Open assistant settings") }
                    OutlinedButton(onClick = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery optimisation settings") }
                }
            }
        }
    }
}

@Composable
fun SecurityScreen(vm: MainViewModel, onBack: () -> Unit) {
    val flow = remember { vm.container.db.securityEvents().observeRecent() }
    val events by flow.collectAsStateWithLifecycle(emptyList())
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var trustName by remember { mutableStateOf("") }
    var trustCat by remember { mutableStateOf("TRUSTED") }
    val f = remember { SimpleDateFormat("d MMM HH:mm:ss", Locale.getDefault()) }
    val apps = remember(q) { if (q.isBlank()) emptyList() else vm.container.apps.search(q).take(5) }
    ScreenScaffold("Security Guardian", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("Privacy mode", color = MaxColors.Text); Dim("No history saved; every MEDIUM+ action asks first.") }
                    Switch(settings.privacyMode, { on -> scope.launch { vm.container.settings.update { it.copy(privacyMode = on) } } })
                }
            }
            Card {
                Text("Protected apps (need fingerprint/PIN to open via MAX)", color = MaxColors.Text)
                OutlinedTextField(q, { q = it }, label = { Text("Search apps to protect") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                apps.forEach { a ->
                    val on = a.packageName in settings.protectedPackages
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(a.label, color = MaxColors.Text, modifier = Modifier.weight(1f))
                        Switch(on, { v -> scope.launch { vm.container.settings.update { s -> s.copy(protectedPackages = if (v) s.protectedPackages + a.packageName else s.protectedPackages - a.packageName) } } })
                    }
                }
                settings.protectedPackages.forEach { Dim("• $it") }
                Dim("This protects opening apps *through MAX only*. It does not lock the app itself.")
            }
            Card {
                Text("Trust categories", color = MaxColors.Text)
                Dim("OWNER · PARENTS · SIBLINGS · TRUSTED · RESTRICTED · UNKNOWN. A name or a spoken claim is NOT proof of identity: sensitive actions always use your device biometric/PIN.")
                OutlinedTextField(trustName, { trustName = it }, label = { Text("Contact name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("PARENTS", "SIBLINGS", "TRUSTED", "RESTRICTED").forEach { cat ->
                        TextButton(onClick = { trustCat = cat }) { Text(cat, color = if (trustCat == cat) MaxColors.Cyan else MaxColors.Dim, fontSize = 11.sp) }
                    }
                }
                Button(onClick = {
                    if (trustName.isNotBlank()) scope.launch { vm.container.settings.update { it.copy(trustedUsers = it.trustedUsers + "${trustName.trim()}|$trustCat") }; trustName = "" }
                }) { Text("Save as $trustCat") }
                settings.trustedUsers.forEach { e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(e.replace("|", " — "), color = MaxColors.Text, modifier = Modifier.weight(1f))
                        TextButton(onClick = { scope.launch { vm.container.settings.update { it.copy(trustedUsers = it.trustedUsers - e) } } }) { Text("Remove") }
                    }
                }
            }
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Security event log", color = MaxColors.Text, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { vm.container.db.securityEvents().deleteAll() } }) { Text("Clear") }
                }
                if (events.isEmpty()) Dim("No events yet.")
                events.take(30).forEach { Dim("${f.format(Date(it.timestampMs))} [${it.risk}] ${it.text}") }
            }
            Card {
                Text("What an ordinary Android app cannot protect", color = MaxColors.Text)
                Dim("MAX cannot lock other apps, block the system, stop someone who has your unlocked phone, or defend against a compromised OS. It never records covertly, never uses the camera or mic in secret, and cannot bypass your lock screen or biometrics.")
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val c = LocalContext.current
    val secrets = vm.container.secrets
    var aiKey by remember { mutableStateOf("") }
    var searchKey by remember { mutableStateOf("") }
    var aiUrl by remember(s.aiBaseUrl) { mutableStateOf(s.aiBaseUrl) }
    var aiModel by remember(s.aiModel) { mutableStateOf(s.aiModel) }
    var place by remember(s.weatherPlace) { mutableStateOf(s.weatherPlace) }
    var keySaved by remember { mutableStateOf(secrets.has(SecretStore.AI_KEY) to secrets.has(SecretStore.SEARCH_KEY)) }

    fun upd(t: (com.max.assistant.settings.AppSettings) -> com.max.assistant.settings.AppSettings) { scope.launch { vm.container.settings.update(t) } }

    ScreenScaffold("Settings", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card {
                Text("AI provider (optional)", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                Dim("Any OpenAI-compatible endpoint with your own key. Without it MAX still runs every device feature; only open conversation and AI explanations are off. Keys are encrypted with the Android Keystore. Free-tier limits depend entirely on the provider you pick.")
                OutlinedTextField(aiUrl, { aiUrl = it }, label = { Text("Base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(aiModel, { aiModel = it }, label = { Text("Model name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(aiKey, { aiKey = it }, label = { Text(if (keySaved.first) "API key (saved — enter to replace)" else "API key") },
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        upd { it.copy(aiBaseUrl = aiUrl.trim(), aiModel = aiModel.trim()) }
                        if (aiKey.isNotBlank()) secrets.put(SecretStore.AI_KEY, aiKey.trim())
                        aiKey = ""; keySaved = secrets.has(SecretStore.AI_KEY) to keySaved.second
                    }) { Text("Save") }
                    OutlinedButton(onClick = { secrets.remove(SecretStore.AI_KEY); keySaved = false to keySaved.second }) { Text("Remove key") }
                }
            }
            Card {
                Text("Web search (Brave Search API key)", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                Dim("Needed only for \"search …\". News and weather work without any key.")
                OutlinedTextField(searchKey, { searchKey = it }, label = { Text(if (keySaved.second) "Key saved — enter to replace" else "Search API key") },
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (searchKey.isNotBlank()) { secrets.put(SecretStore.SEARCH_KEY, searchKey.trim()); searchKey = ""; keySaved = keySaved.first to true } }) { Text("Save") }
                    OutlinedButton(onClick = { secrets.remove(SecretStore.SEARCH_KEY); keySaved = keySaved.first to false }) { Text("Remove key") }
                }
            }
            Card {
                Text("Voice", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                Dim("Recognition language (device must support it): ${s.speechLanguage}")
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("en-IN" to "English (IN)", "hi-IN" to "Hindi", "en-US" to "English (US)").forEach { (tag, label) ->
                        TextButton(onClick = { upd { it.copy(speechLanguage = tag) } }) { Text(label, color = if (s.speechLanguage == tag) MaxColors.Cyan else MaxColors.Dim, fontSize = 12.sp) }
                    }
                }
                Dim("Hinglish: pick Hindi or English (IN) — your device's recogniser decides how well mixed speech is understood. Spoken replies are in English text; the TTS voice follows the language above.")
                Dim("Speech rate: %.1fx".format(s.ttsRate))
                Slider(value = s.ttsRate, onValueChange = { v -> upd { it.copy(ttsRate = v) } }, valueRange = 0.5f..2f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Speak responses", color = MaxColors.Text, modifier = Modifier.weight(1f))
                    Switch(s.speakResponses, { v -> upd { it.copy(speakResponses = v) } })
                }
            }
            Card {
                Text("General", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(place, { place = it }, label = { Text("Weather city (blank = use location)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(onClick = { upd { it.copy(weatherPlace = place.trim()) } }) { Text("Save city") }
                Dim("Confirmation policy")
                Row {
                    listOf(ConfirmationPolicy.NEVER_FOR_LOW to "High only", ConfirmationPolicy.ASK_MEDIUM_AND_UP to "Medium+", ConfirmationPolicy.ASK_HIGH_AND_UP to "High+").forEach { (p, l) ->
                        TextButton(onClick = { upd { it.copy(confirmationPolicy = p) } }) { Text(l, color = if (s.confirmationPolicy == p) MaxColors.Cyan else MaxColors.Dim, fontSize = 12.sp) }
                    }
                }
                Dim("Sensitive actions always require your biometric/PIN regardless of this setting.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Offline-only (no network calls)", color = MaxColors.Text, modifier = Modifier.weight(1f))
                    Switch(s.offlineOnly, { v -> upd { it.copy(offlineOnly = v) } })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reduce animations", color = MaxColors.Text, modifier = Modifier.weight(1f))
                    Switch(s.reduceAnimations, { v -> upd { it.copy(reduceAnimations = v) } })
                }
            }
            Card {
                Text("Briefing", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                Row {
                    BriefingMode.values().forEach { m ->
                        TextButton(onClick = { upd { it.copy(briefingMode = m) } }) { Text(m.name, color = if (s.briefingMode == m) MaxColors.Cyan else MaxColors.Dim, fontSize = 12.sp) }
                    }
                }
                Dim("Categories (tap to toggle)")
                val all = vm.container.news.supportedCategories()
                androidx.compose.foundation.lazy.LazyRow {
                    items(all) { cat ->
                        val on = cat in s.briefingCategories
                        TextButton(onClick = { upd { it.copy(briefingCategories = if (on) it.briefingCategories - cat else it.briefingCategories + cat) } }) {
                            Text(cat, color = if (on) MaxColors.Cyan else MaxColors.Dim, fontSize = 12.sp)
                        }
                    }
                }
                Dim("Quiet hours (no scheduled notifications): ${s.quietStartHour}:00 → ${s.quietEndHour}:00")
                Row {
                    TextButton(onClick = { upd { it.copy(quietStartHour = (it.quietStartHour + 23) % 24) } }) { Text("Start −") }
                    TextButton(onClick = { upd { it.copy(quietStartHour = (it.quietStartHour + 1) % 24) } }) { Text("Start +") }
                    TextButton(onClick = { upd { it.copy(quietEndHour = (it.quietEndHour + 23) % 24) } }) { Text("End −") }
                    TextButton(onClick = { upd { it.copy(quietEndHour = (it.quietEndHour + 1) % 24) } }) { Text("End +") }
                }
                Dim("Schedule briefings in Automation Center.")
            }
            Card {
                Text("Default assistant", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                OutlinedButton(onClick = { runCatching { c.startActivity(DefaultAssistant.settingsIntent()) } }) { Text("Choose MAX as assistant") }
            }
        }
    }
}

@Composable
fun DiagnosticsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val c = vm.container
    val ttsStatus by vm.ttsStatus.collectAsStateWithLifecycle()
    val flow = remember { c.db.activity().observeRecent() }
    val logs by flow.collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()
    val f = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    ScreenScaffold("Diagnostics", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Card {
                Text("Services", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                Dim("Speech recognition available: ${c.voice.isAvailable()}")
                Dim("Text-to-speech: $ttsStatus")
                Dim("AI provider configured: ${c.aiProvider.isConfigured()}")
                Dim("Search provider configured: ${c.searchProvider.isConfigured()}")
                Dim("Notification listener connected: ${com.max.assistant.notifications.NotificationStore.connected}")
                Dim("Visible launchable apps: ${c.apps.launchableApps().size}")
            }
            Card {
                Text("Tools (${c.registry.all().size})", color = MaxColors.Text, fontWeight = FontWeight.SemiBold)
                c.registry.availabilityReport().forEach { (id, av, risk) ->
                    Dim("$id · $risk · ${if (av.available) "available" else "unavailable: ${av.reason}"}")
                }
            }
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Activity & errors", color = MaxColors.Text, modifier = Modifier.weight(1f))
                    TextButton(onClick = { scope.launch { c.db.activity().deleteAll() } }) { Text("Clear") }
                }
                logs.take(60).forEach { Dim("${f.format(Date(it.timestampMs))} ${it.level} ${it.text}") }
            }
        }
    }
}
