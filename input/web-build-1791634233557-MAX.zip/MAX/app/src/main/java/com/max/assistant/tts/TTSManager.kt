package com.max.assistant.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

/** Wraps Android TextToSpeech. Never assumes a given engine/language exists. */
class TTSManager(private val context: Context) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()
    private val _status = MutableStateFlow("TTS not started")
    val status: StateFlow<String> = _status.asStateFlow()
    private var pendingText: Pair<String, String>? = null
    private var rate = 1.0f

    fun init() {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { code ->
            if (code == TextToSpeech.SUCCESS) {
                ready = true
                _status.value = "TTS ready"
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _speaking.value = true }
                    override fun onDone(utteranceId: String?) { _speaking.value = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { _speaking.value = false }
                })
                pendingText?.let { (text, lang) -> pendingText = null; speak(text, lang) }
            } else {
                ready = false
                _status.value = "No text-to-speech engine is available (code $code). Responses will be shown as text."
            }
        }
    }

    fun setRate(r: Float) { rate = r.coerceIn(0.5f, 2.0f); tts?.setSpeechRate(rate) }

    /** True if the language can actually be spoken on this device. */
    fun isLanguageAvailable(tag: String): Boolean {
        val t = tts ?: return false
        if (!ready) return false
        val r = t.isLanguageAvailable(Locale.forLanguageTag(tag))
        return r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
    }

    /**
     * @return true if speech was queued. False means the caller must rely on on-screen text.
     */
    fun speak(text: String, languageTag: String): Boolean {
        if (text.isBlank()) return false
        val t = tts
        if (t == null) { init(); pendingText = text to languageTag; return false }
        if (!ready) { pendingText = text to languageTag; return false }
        val locale = Locale.forLanguageTag(languageTag)
        val avail = t.isLanguageAvailable(locale)
        if (avail == TextToSpeech.LANG_MISSING_DATA || avail == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fall back to the device default language rather than failing silently.
            t.language = Locale.getDefault()
            _status.value = "Voice for $languageTag is not installed; using the device default."
        } else t.language = locale
        t.setSpeechRate(rate)
        val clean = text.replace(Regex("https?://\\S+"), "link")
        return t.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString()) == TextToSpeech.SUCCESS
    }

    fun stop() { tts?.stop(); _speaking.value = false }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null; ready = false; _speaking.value = false
    }
}
