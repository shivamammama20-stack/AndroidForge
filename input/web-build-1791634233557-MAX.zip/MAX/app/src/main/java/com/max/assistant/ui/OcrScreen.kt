package com.max.assistant.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * User-initiated capture only: the camera is bound while this screen is visible and released on exit.
 * OCR runs on-device (ML Kit bundled Latin model). Hindi/Devanagari text is not recognised by this model.
 */
@androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
@Composable
fun OcrScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val request = LocalPermissionRequester.current
    var hasCamera by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var result by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    val capture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
    val executor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    val recognizer = remember { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    val providerHolder = remember { arrayOfNulls<ProcessCameraProvider>(1) }

    DisposableEffect(Unit) {
        onDispose {
            providerHolder[0]?.unbindAll()
            executor.shutdown()
            recognizer.close()
        }
    }

    ScreenScaffold("Scan text (OCR)", onBack) {
        if (!hasCamera) {
            Dim("Camera permission is needed. MAX only uses the camera on this screen, when you tap the shutter.")
            Button(onClick = { request(Manifest.permission.CAMERA) }) { Text("Allow camera") }
            OutlinedButton(onClick = {
                hasCamera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            }) { Text("I allowed it — refresh") }
            return@ScreenScaffold
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().height(300.dp),
            factory = { ctx ->
                val view = PreviewView(ctx)
                val future = ProcessCameraProvider.getInstance(ctx)
                future.addListener({
                    try {
                        val provider = future.get()
                        providerHolder[0] = provider
                        val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                        provider.unbindAll()
                        provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                    } catch (e: Exception) {
                        status = "Camera could not start: ${e.javaClass.simpleName}"
                    }
                }, ContextCompat.getMainExecutor(ctx))
                view
            },
        )
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                status = "Capturing…"
                capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        val media = image.image
                        if (media == null) { image.close(); status = "No image data."; return }
                        val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
                        recognizer.process(input)
                            .addOnSuccessListener { r ->
                                result = r.text
                                status = if (r.text.isBlank()) "No text found. Try better light or move closer." else "Recognised ${r.text.length} characters."
                            }
                            .addOnFailureListener { e -> status = "OCR failed: ${e.javaClass.simpleName}" }
                            .addOnCompleteListener { image.close() }
                    }
                    override fun onError(exception: ImageCaptureException) { status = "Capture failed: ${exception.message}" }
                })
            }) { Text("Capture") }
            OutlinedButton(enabled = result.isNotBlank(), onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("MAX OCR", result)); status = "Copied to clipboard."
            }) { Text("Copy") }
            OutlinedButton(enabled = result.isNotBlank(), onClick = {
                context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, result), "Share text").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("Share") }
        }
        if (status.isNotEmpty()) Dim(status)
        Column(Modifier.verticalScroll(rememberScrollState())) { Text(result, color = MaxColors.Text) }
    }
}
