package com.max.assistant.core

/** Risk classification of an *operation* (not of the user's wording). */
enum class RiskLevel { LOW, MEDIUM, HIGH, SENSITIVE }

enum class Status { SUCCESS, PARTIAL, FAILURE }

/**
 * How well the outcome was verified.
 * HANDED_OFF  = another app/system screen was opened; the final outcome is unknown to MAX.
 * UNVERIFIED  = the API call returned but Android gives no confirmation of the effect.
 * VERIFIED    = MAX read back / observed the real result (e.g. DB row exists, alarm scheduled).
 */
enum class Verification { VERIFIED, HANDED_OFF, UNVERIFIED, NOT_APPLICABLE }

enum class ErrorCategory {
    NONE, PERMISSION_DENIED, NETWORK, PROVIDER_UNAVAILABLE, MISSING_CREDENTIALS, APP_NOT_FOUND,
    CONTACT_NOT_FOUND, AMBIGUOUS, UNSUPPORTED, SERVICE_UNAVAILABLE, TIMEOUT, API_FAILURE,
    DATABASE, SCHEDULING, INVALID_INPUT, RESTRICTED_BY_ANDROID, UNKNOWN
}

/** Structured outcome of every tool execution (spec section 31). */
data class ToolResult(
    val status: Status,
    val message: String,
    val data: Map<String, String> = emptyMap(),
    val error: ErrorCategory = ErrorCategory.NONE,
    val verification: Verification = Verification.NOT_APPLICABLE,
    /** Optional UI navigation request, e.g. "ocr" or "permissions". */
    val navigateTo: String? = null,
) {
    companion object {
        fun ok(msg: String, v: Verification = Verification.NOT_APPLICABLE, data: Map<String, String> = emptyMap(), nav: String? = null) =
            ToolResult(Status.SUCCESS, msg, data, ErrorCategory.NONE, v, nav)

        fun partial(msg: String, v: Verification, data: Map<String, String> = emptyMap()) =
            ToolResult(Status.PARTIAL, msg, data, ErrorCategory.NONE, v)

        fun fail(msg: String, e: ErrorCategory, data: Map<String, String> = emptyMap()) =
            ToolResult(Status.FAILURE, msg, data, e, Verification.NOT_APPLICABLE)
    }
}

data class Availability(val available: Boolean, val reason: String? = null) {
    companion object {
        val YES = Availability(true)
        fun no(reason: String) = Availability(false, reason)
    }
}

/** Typed argument bag; tools declare the keys they read in [Tool.inputSchema]. */
typealias ToolArgs = Map<String, String>

interface Tool {
    val id: String
    val description: String
    /** key -> human description (required keys end with '*'). */
    val inputSchema: Map<String, String>
    val requiredPermissions: List<String>
    /** Base risk; [com.max.assistant.brain.RiskEngine] can raise it based on arguments. */
    val baseRisk: RiskLevel
    /** True only if the tool does real work on a device. Never true for placeholders. */
    fun availability(): Availability
    suspend fun execute(args: ToolArgs): ToolResult
}
