package com.max.assistant.context

import com.max.assistant.news.NewsItem

/** A pending action waiting for the user's yes/no. Expires so stale "yes" never authorises anything. */
data class PendingConfirmation(
    val toolId: String,
    val args: Map<String, String>,
    val prompt: String,
    val createdAtMs: Long,
    val requiresBiometric: Boolean,
    val ttlMs: Long = 30_000,
) {
    fun isExpired(nowMs: Long) = nowMs - createdAtMs > ttlMs
}

/** A question MAX asked ("Which Rahul?") and how to resume once answered. */
data class PendingClarification(val toolId: String, val args: Map<String, String>, val missingKey: String, val options: List<String>)

/** Short-term conversation context. Persistent preferences live in Settings/Room, not here. */
class ConversationContext {
    var lastContactName: String? = null
    var lastContactNumber: String? = null
    var lastIntentToolId: String? = null
    var lastHeadlines: List<NewsItem> = emptyList()
    var selectedHeadline: NewsItem? = null
    var lastSpoken: String = ""
    var pendingConfirmation: PendingConfirmation? = null
    var pendingClarification: PendingClarification? = null
    var briefingExcludedCategories: MutableSet<String> = mutableSetOf()
    var briefingOnlyCategory: String? = null

    fun clear() {
        lastContactName = null; lastContactNumber = null; lastIntentToolId = null
        lastHeadlines = emptyList(); selectedHeadline = null; lastSpoken = ""
        pendingConfirmation = null; pendingClarification = null
        briefingExcludedCategories.clear(); briefingOnlyCategory = null
    }
}
