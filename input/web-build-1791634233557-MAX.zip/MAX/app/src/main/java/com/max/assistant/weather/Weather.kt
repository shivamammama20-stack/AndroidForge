package com.max.assistant.weather

import com.max.assistant.net.Http
import org.json.JSONObject
import java.net.URLEncoder

data class GeoPlace(val name: String, val country: String, val latitude: Double, val longitude: Double)

data class WeatherReport(
    val placeLabel: String,
    val observedAtLocal: String,
    val temperature: Double,
    val temperatureUnit: String,
    val conditionText: String,
    val todayMax: Double?,
    val todayMin: Double?,
    val rainProbabilityPercent: Int?,
    val timezone: String,
)

interface WeatherProvider {
    suspend fun geocode(place: String): GeoPlace?
    suspend fun report(lat: Double, lon: Double, label: String): WeatherReport
}

/** Open-Meteo: no API key; free for non-commercial use (see README for terms and limits). */
class OpenMeteoProvider : WeatherProvider {
    override suspend fun geocode(place: String): GeoPlace? {
        val q = URLEncoder.encode(place, "UTF-8")
        val json = JSONObject(Http.get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=en&format=json"))
        val r = json.optJSONArray("results")?.optJSONObject(0) ?: return null
        return GeoPlace(r.optString("name"), r.optString("country"), r.getDouble("latitude"), r.getDouble("longitude"))
    }

    override suspend fun report(lat: Double, lon: Double, label: String): WeatherReport {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=1"
        val j = JSONObject(Http.get(url))
        val cur = j.getJSONObject("current")
        val units = j.optJSONObject("current_units")
        val daily = j.optJSONObject("daily")
        fun dailyD(key: String) = daily?.optJSONArray(key)?.takeIf { it.length() > 0 && !it.isNull(0) }?.getDouble(0)
        return WeatherReport(
            placeLabel = label,
            observedAtLocal = cur.optString("time"),
            temperature = cur.getDouble("temperature_2m"),
            temperatureUnit = units?.optString("temperature_2m") ?: "°C",
            conditionText = describe(cur.optInt("weather_code", -1)),
            todayMax = dailyD("temperature_2m_max"),
            todayMin = dailyD("temperature_2m_min"),
            rainProbabilityPercent = dailyD("precipitation_probability_max")?.toInt(),
            timezone = j.optString("timezone"),
        )
    }

    /** WMO weather interpretation codes. */
    fun describe(code: Int): String = when (code) {
        0 -> "clear sky"
        1, 2, 3 -> "partly cloudy to overcast"
        45, 48 -> "fog"
        51, 53, 55, 56, 57 -> "drizzle"
        61, 63, 65, 66, 67 -> "rain"
        71, 73, 75, 77 -> "snow"
        80, 81, 82 -> "rain showers"
        85, 86 -> "snow showers"
        95, 96, 99 -> "thunderstorm"
        else -> "conditions unavailable"
    }
}
