package com.max.assistant.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class VoiceEvent {
    object Idle : VoiceEvent()
    object Listening : VoiceEvent()
    data class Partial(val text: String) : VoiceEvent()
    data class Final(val text: String, val id: Long) : VoiceEvent()
    data class Error(val message: String, val retryable: Boolean) : VoiceEvent()
}

/** Wraps SpeechRecognizer. All methods must be called on the main thread. */
class VoiceManager(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private val _events = MutableStateFlow<VoiceEvent>(VoiceEvent.Idle)
    val events: StateFlow<VoiceEvent> = _events.asStateFlow()
    private var lastLanguage: String = "en-IN"
    private var finalCounter = 0L

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** Returns false (and publishes an Error) if listening could not start; never listens without permission. */
    fun start(languageTag: String): Boolean {
        lastLanguage = languageTag
        if (!hasPermission()) { _events.value = VoiceEvent.Error("Microphone permission is not granted.", false); return false }
        if (!isAvailable()) { _events.value = VoiceEvent.Error("No speech recognition service is available on this device. You can type instead.", false); return false }
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _events.value = VoiceEvent.Listening }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    ?.let { _events.value = VoiceEvent.Partial(it) }
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                _events.value = if (text.isNullOrBlank()) VoiceEvent.Error("I didn't catch that.", true) else VoiceEvent.Final(text, ++finalCounter)
                release()
            }
            override fun onError(error: Int) {
                _events.value = VoiceEvent.Error(describe(error), error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                release()
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        r.startListening(i)
        return true
    }

    fun retry() { start(lastLanguage) }

    /** Stops listening and discards any partial result (cancel). */
    fun stop() {
        recognizer?.let { runCatching { it.cancel() } }
        release()
        if (_events.value is VoiceEvent.Listening || _events.value is VoiceEvent.Partial) _events.value = VoiceEvent.Idle
    }

    fun acknowledge() { _events.value = VoiceEvent.Idle }

    private fun release() {
        recognizer?.let { runCatching { it.destroy() } }
        recognizer = null
    }

    /** Lifecycle-safe cleanup. */
    fun shutdown() { stop() }

    private fun describe(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs a network connection on this device."
        SpeechRecognizer.ERROR_NO_MATCH -> "I didn't understand that."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything."
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again."
        SpeechRecognizer.ERROR_SERVER -> "The speech service reported an error."
        else -> "Speech recognition failed (code $code)."
    }
}
