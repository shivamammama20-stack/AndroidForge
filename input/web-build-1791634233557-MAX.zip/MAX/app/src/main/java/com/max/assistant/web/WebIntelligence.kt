package com.max.assistant.web

import com.max.assistant.core.ErrorCategory
import com.max.assistant.net.Http
import com.max.assistant.net.NetException
import org.json.JSONObject
import java.net.URLEncoder

data class WebSource(val title: String, val url: String, val snippet: String, val age: String?)

sealed class SearchOutcome {
    data class Found(val sources: List<WebSource>) : SearchOutcome()
    data class Unavailable(val category: ErrorCategory, val reason: String) : SearchOutcome()
}

interface SearchProvider {
    val name: String
    fun isConfigured(): Boolean
    suspend fun search(query: String, count: Int = 5): SearchOutcome
}

/**
 * Brave Search API (requires the user's own key; see README for registration and free-tier note).
 * Results keep real titles/URLs/ages. MAX never fabricates citations: no key -> Unavailable.
 */
class BraveSearchProvider(private val apiKey: () -> String?) : SearchProvider {
    override val name = "Brave Search"
    override fun isConfigured() = !apiKey().isNullOrBlank()

    override suspend fun search(query: String, count: Int): SearchOutcome {
        val key = apiKey()
        if (key.isNullOrBlank()) return SearchOutcome.Unavailable(ErrorCategory.MISSING_CREDENTIALS, "No search API key is configured.")
        return try {
            val q = URLEncoder.encode(query, "UTF-8")
            val body = Http.get("https://api.search.brave.com/res/v1/web/search?q=$q&count=$count",
                mapOf("X-Subscription-Token" to key, "Accept" to "application/json"))
            val arr = JSONObject(body).optJSONObject("web")?.optJSONArray("results")
            val out = ArrayList<WebSource>()
            if (arr != null) for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                out += WebSource(
                    title = r.optString("title"),
                    url = r.optString("url"),
                    snippet = r.optString("description").replace(Regex("<[^>]*>"), ""),
                    age = r.optString("age").ifEmpty { null },
                )
            }
            SearchOutcome.Found(out)
        } catch (e: NetException) {
            SearchOutcome.Unavailable(e.category, e.message ?: "Search failed")
        } catch (e: Exception) {
            SearchOutcome.Unavailable(ErrorCategory.API_FAILURE, "Could not read the search response.")
        }
    }
}
