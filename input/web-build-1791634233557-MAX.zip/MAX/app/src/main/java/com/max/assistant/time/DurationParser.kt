package com.max.assistant.time

/** Parses "set a timer for 5 minutes", "10 minute ka timer", "1 hour 30 minutes" into seconds. */
object DurationParser {
    fun parseSeconds(text: String): Int? {
        val t = text.lowercase()
        var total = 0
        var found = false
        Regex("""(\d{1,3})\s*(hours?|hrs?|hr|ghante|ghanta)""").findAll(t).forEach { total += it.groupValues[1].toInt() * 3600; found = true }
        Regex("""(\d{1,4})\s*(minutes?|mins?|min|minute|minat)""").findAll(t).forEach { total += it.groupValues[1].toInt() * 60; found = true }
        Regex("""(\d{1,5})\s*(seconds?|secs?|sec|second)""").findAll(t).forEach { total += it.groupValues[1].toInt(); found = true }
        return if (found && total > 0) total else null
    }
}
