package com.max.assistant.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.max.assistant.brain.AssistantState
import kotlin.math.abs
import kotlin.math.sin

object MaxColors {
    val Bg = Color(0xFF050A14)
    val Panel = Color(0xFF0B1426)
    val PanelHi = Color(0xFF12203A)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val Text = Color(0xFFE6F1FF)
    val Dim = Color(0xFF8FA6C4)
    val Warn = Color(0xFFFFB300)
    val Error = Color(0xFFFF5252)
    val Ok = Color(0xFF00E676)
}

@Composable
fun MaxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = MaxColors.Cyan, onPrimary = Color.Black, secondary = MaxColors.Blue,
            background = MaxColors.Bg, surface = MaxColors.Panel, onBackground = MaxColors.Text,
            onSurface = MaxColors.Text, error = MaxColors.Error,
        ),
        content = content,
    )
}

fun stateColor(s: AssistantState): Color = when (s) {
    AssistantState.ERROR -> MaxColors.Error
    AssistantState.LISTENING -> MaxColors.Ok
    AssistantState.EXECUTING -> MaxColors.Warn
    else -> MaxColors.Cyan
}

/** Animated core: pulsing orb + 3 counter-rotating ring arcs. Cheap: one Canvas, 2 transitions. */
@Composable
fun MaxOrb(state: AssistantState, reduceMotion: Boolean, modifier: Modifier = Modifier) {
    val color = stateColor(state)
    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (state == AssistantState.ANALYZING) 2500 else 9000, easing = LinearEasing)), label = "spin")
    val pulse by t.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(if (state == AssistantState.IDLE) 2400 else 900), RepeatMode.Reverse), label = "pulse")
    val s = if (reduceMotion) 0f else spin
    val p = if (reduceMotion) 1f else pulse
    Canvas(modifier.size(220.dp)) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), c, r), r, c)
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), color, MaxColors.Blue.copy(alpha = 0.7f)), c, r * 0.42f * p), r * 0.42f * p, c)
        listOf(0.62f to 1f, 0.78f to -1.4f, 0.94f to 0.7f).forEachIndexed { idx, (frac, speed) ->
            val rr = r * frac
            rotate(s * speed + idx * 40f, c) {
                drawArc(color.copy(alpha = 0.85f - idx * 0.2f), 0f, 250f - idx * 50f, false,
                    Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), style = Stroke(3f + (2 - idx), cap = StrokeCap.Round))
            }
        }
    }
}

/** Equalizer bars, animated only while [active]. */
@Composable
fun Waveform(active: Boolean, color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, 6.28f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "phase")
    Canvas(modifier.fillMaxWidth().height(40.dp)) {
        val bars = 28
        val gap = size.width / bars
        for (i in 0 until bars) {
            val amp = if (active) 0.25f + 0.75f * abs(sin(phase + i * 0.45f)) else 0.08f
            val h = size.height * amp
            drawLine(color, Offset(gap * i + gap / 2, (size.height - h) / 2), Offset(gap * i + gap / 2, (size.height + h) / 2), strokeWidth = gap * 0.45f, cap = StrokeCap.Round)
        }
    }
}

@Composable
fun CenterRow(content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { content() }
}

@Composable
fun GlowBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier) { content() }
}
