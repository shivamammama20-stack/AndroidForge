package com.max.assistant

import android.app.Application
import android.content.Context
import com.max.assistant.ai.OpenAiCompatibleProvider
import com.max.assistant.apps.AppRepository
import com.max.assistant.brain.MaxBrain
import com.max.assistant.brain.PermissionChecker
import com.max.assistant.brain.RiskEngine
import com.max.assistant.context.ConversationContext
import com.max.assistant.contacts.ContactRepository
import com.max.assistant.core.RiskLevel
import com.max.assistant.data.ActivityEntity
import com.max.assistant.data.MaxDatabase
import com.max.assistant.data.SecurityEventEntity
import com.max.assistant.intent.IntentDetector
import com.max.assistant.news.NewsRepository
import com.max.assistant.reminders.Notifier
import com.max.assistant.security.SecretStore
import com.max.assistant.settings.AppSettings
import com.max.assistant.settings.SettingsRepository
import com.max.assistant.time.TimeParser
import com.max.assistant.tools.AlarmTool
import com.max.assistant.tools.BriefingService
import com.max.assistant.tools.CalendarReader
import com.max.assistant.tools.CalendarTool
import com.max.assistant.tools.CallContactTool
import com.max.assistant.tools.CameraOcrTool
import com.max.assistant.tools.CurrentAffairsTool
import com.max.assistant.tools.DailyBriefingTool
import com.max.assistant.tools.DeviceInfoTool
import com.max.assistant.tools.DeviceSettingsTool
import com.max.assistant.tools.IntentMapProvider
import com.max.assistant.tools.ListRemindersTool
import com.max.assistant.tools.MapSearchTool
import com.max.assistant.tools.MediaKeyTool
import com.max.assistant.tools.MemoryTool
import com.max.assistant.tools.MessageContactTool
import com.max.assistant.tools.NavigateTool
import com.max.assistant.tools.OpenAppTool
import com.max.assistant.tools.ReadNotificationsTool
import com.max.assistant.tools.ReminderTool
import com.max.assistant.tools.SearchAppsTool
import com.max.assistant.tools.SearchContactTool
import com.max.assistant.tools.SimpleNavTool
import com.max.assistant.tools.TimerTool
import com.max.assistant.tools.ToolRegistry
import com.max.assistant.tools.VolumeTool
import com.max.assistant.tools.WeatherTool
import com.max.assistant.tools.WebSearchTool
import com.max.assistant.tts.TTSManager
import com.max.assistant.voice.VoiceManager
import com.max.assistant.weather.OpenMeteoProvider
import com.max.assistant.web.BraveSearchProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.Clock

class MaxApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifier.ensureChannels(this)
    }
}

/** Manual dependency graph (small enough that a DI framework would only add build risk). */
class AppContainer(context: Context) {
    private val app = context.applicationContext
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val clock: Clock = Clock.systemDefaultZone()
    val db = MaxDatabase.build(app)
    val settings = SettingsRepository(app)
    val secrets = SecretStore(app)

    @Volatile var currentSettings: AppSettings = AppSettings()
        private set

    init {
        scope.launch { settings.settings.collect { currentSettings = it } }
    }

    val apps = AppRepository(app)
    val contacts = ContactRepository(app)
    val news = NewsRepository()
    val weatherProvider = OpenMeteoProvider()
    val searchProvider = BraveSearchProvider { secrets.get(SecretStore.SEARCH_KEY) }
    val aiProvider = OpenAiCompatibleProvider(
        baseUrl = { currentSettings.aiBaseUrl },
        model = { currentSettings.aiModel },
        apiKey = { secrets.get(SecretStore.AI_KEY) },
    )
    val ctx = ConversationContext()
    val timeParser = TimeParser(clock)
    val calendarReader = CalendarReader(app)
    val voice = VoiceManager(app)
    val tts = TTSManager(app)

    suspend fun log(level: String, text: String) {
        db.activity().insert(ActivityEntity(timestampMs = System.currentTimeMillis(), level = level, text = text))
        db.activity().trim()
    }

    private suspend fun securityLog(level: RiskLevel, text: String) {
        db.securityEvents().insert(SecurityEventEntity(timestampMs = System.currentTimeMillis(), risk = level.name, text = text))
    }

    private val mapProvider = IntentMapProvider()
    private val weatherTool = WeatherTool(app, weatherProvider, settings)
    val briefingService = BriefingService(app, db, settings, weatherTool, news, calendarReader, clock)

    val registry = ToolRegistry(
        listOf(
            OpenAppTool(app, apps), SearchAppsTool(apps), SearchContactTool(contacts),
            CallContactTool(app), MessageContactTool(app),
            MapSearchTool(app, mapProvider), NavigateTool(app, mapProvider),
            MediaKeyTool(app, "play_media", "Send a play command", android.view.KeyEvent.KEYCODE_MEDIA_PLAY, "play"),
            MediaKeyTool(app, "pause_media", "Send a pause command", android.view.KeyEvent.KEYCODE_MEDIA_PAUSE, "pause"),
            MediaKeyTool(app, "next_media", "Send a next-track command", android.view.KeyEvent.KEYCODE_MEDIA_NEXT, "next track"),
            MediaKeyTool(app, "previous_media", "Send a previous-track command", android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS, "previous track"),
            VolumeTool(app),
            ReminderTool(app, db, timeParser, clock), ListRemindersTool(db), AlarmTool(app, timeParser), TimerTool(app),
            CalendarTool(calendarReader, clock),
            DeviceInfoTool(app), DeviceSettingsTool(app),
            MemoryTool(db, settings), ReadNotificationsTool(app),
            weatherTool, CurrentAffairsTool(news, ctx, settings), DailyBriefingTool(briefingService, ctx),
            WebSearchTool(searchProvider, settings), CameraOcrTool(),
            SimpleNavTool("security", "Open the Security Guardian", "security", "Opening Security Guardian."),
            SimpleNavTool("automation", "Open the Automation Center", "automation", "Opening Automation Center."),
        )
    )

    val brain = MaxBrain(
        registry = registry,
        detector = IntentDetector(),
        ctx = ctx,
        risk = RiskEngine { currentSettings.protectedPackages },
        settings = settings,
        permissions = PermissionChecker(app),
        apps = apps,
        contacts = contacts,
        ai = aiProvider,
        briefing = briefingService,
        log = { l, t -> log(l, t) },
        securityLog = { l, t -> securityLog(l, t) },
    )
}
