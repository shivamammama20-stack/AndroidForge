package com.max.assistant.ai

import com.max.assistant.core.ErrorCategory
import com.max.assistant.net.Http
import com.max.assistant.net.NetException
import org.json.JSONArray
import org.json.JSONObject

data class ChatMessage(val role: String, val content: String)

sealed class AiResult {
    data class Ok(val text: String) : AiResult()
    data class Err(val category: ErrorCategory, val message: String) : AiResult()
}

/** Replaceable AI backend. Used for conversation/explanations only, never to decide that an action succeeded. */
interface AIProvider {
    val name: String
    fun isConfigured(): Boolean
    suspend fun complete(messages: List<ChatMessage>): AiResult
}

/**
 * Any OpenAI-compatible /chat/completions endpoint (OpenAI, OpenRouter, Groq, Together, local servers ...).
 * Base URL, model and key are user-supplied; nothing is bundled in the APK.
 */
class OpenAiCompatibleProvider(
    private val baseUrl: () -> String,
    private val model: () -> String,
    private val apiKey: () -> String?,
) : AIProvider {
    override val name = "OpenAI-compatible"

    override fun isConfigured() = !apiKey().isNullOrBlank() && model().isNotBlank() && baseUrl().isNotBlank()

    override suspend fun complete(messages: List<ChatMessage>): AiResult {
        if (apiKey().isNullOrBlank()) return AiResult.Err(ErrorCategory.MISSING_CREDENTIALS, "No AI API key is configured.")
        if (model().isBlank()) return AiResult.Err(ErrorCategory.MISSING_CREDENTIALS, "No AI model name is configured.")
        val body = JSONObject()
            .put("model", model())
            .put("messages", JSONArray().also { arr ->
                messages.forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
            })
            .toString()
        return try {
            val resp = Http.postJson(baseUrl().trimEnd('/') + "/chat/completions", body, mapOf("Authorization" to "Bearer ${apiKey()}"))
            val text = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            AiResult.Ok(text.trim())
        } catch (e: NetException) {
            AiResult.Err(e.category, e.message ?: "AI request failed")
        } catch (e: Exception) {
            AiResult.Err(ErrorCategory.API_FAILURE, "Could not read the AI response.")
        }
    }
}
