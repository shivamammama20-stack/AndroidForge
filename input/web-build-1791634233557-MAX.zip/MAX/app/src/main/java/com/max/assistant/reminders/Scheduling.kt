package com.max.assistant.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.max.assistant.MainActivity
import com.max.assistant.MaxApp
import com.max.assistant.data.AutomationEntity
import com.max.assistant.data.ReminderEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Clock
import java.time.Duration
import java.time.LocalTime
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    const val CH_REMINDERS = "max_reminders"
    const val CH_BRIEFING = "max_briefing"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_BRIEFING, "Briefings & automations", NotificationManager.IMPORTANCE_DEFAULT))
    }

    /** Returns false if notifications are blocked (permission or channel) so callers never claim delivery. */
    fun post(context: Context, channel: String, id: Int, title: String, text: String): Boolean {
        ensureChannels(context)
        val nm = context.getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) return false
        val open = PendingIntent.getActivity(
            context, id, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
        return true
    }
}

object ReminderScheduler {
    const val EXTRA_ID = "reminder_id"

    private fun pending(context: Context, id: Long, create: Boolean): PendingIntent? {
        val i = Intent(context, ReminderReceiver::class.java).putExtra(EXTRA_ID, id)
        val flags = PendingIntent.FLAG_IMMUTABLE or (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(context, id.toInt(), i, flags)
    }

    /** @return "EXACT", "INEXACT" or "FAILED" -- verified by checking the PendingIntent now exists. */
    fun schedule(context: Context, r: ReminderEntity): String {
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = pending(context, r.id, true) ?: return "FAILED"
        val exactAllowed = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        var mode = "FAILED"
        try {
            if (exactAllowed) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAtMs, pi); mode = "EXACT"
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAtMs, pi); mode = "INEXACT"
            }
        } catch (e: SecurityException) {
            runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAtMs, pi); mode = "INEXACT" }
        }
        // Verification: the alarm's PendingIntent must now be retrievable.
        return if (mode != "FAILED" && pending(context, r.id, false) != null) mode else "FAILED"
    }

    fun cancel(context: Context, id: Long) {
        val am = context.getSystemService(AlarmManager::class.java)
        pending(context, id, false)?.let { am.cancel(it); it.cancel() }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(ReminderScheduler.EXTRA_ID, -1)
        if (id < 0) return
        val pending = goAsync()
        val container = (context.applicationContext as MaxApp).container
        runAsync(pending) {
            val dao = container.db.reminders()
            val r = dao.get(id) ?: return@runAsync
            if (r.done) return@runAsync
            val delivered = Notifier.post(context, Notifier.CH_REMINDERS, id.toInt(), "MAX reminder", r.text)
            container.log("REMINDER", if (delivered) "Reminder fired: ${r.text}" else "Reminder fired but notifications are blocked: ${r.text}")
            if (r.repeat == "DAILY") {
                val next = r.copy(triggerAtMs = r.triggerAtMs + TimeUnit.DAYS.toMillis(1))
                dao.update(next.copy(scheduleMode = ReminderScheduler.schedule(context, next)))
            } else {
                dao.update(r.copy(done = true))
            }
        }
    }
}

private fun runAsync(pending: BroadcastReceiver.PendingResult, block: suspend () -> Unit) {
    CoroutineScope(Dispatchers.IO).launch {
        try { block() } finally { pending.finish() }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val container = (context.applicationContext as MaxApp).container
        runAsync(pending) {
            val now = System.currentTimeMillis()
            container.db.reminders().all().filter { !it.done && it.triggerAtMs > now }.forEach { r ->
                container.db.reminders().update(r.copy(scheduleMode = ReminderScheduler.schedule(context, r)))
            }
            container.db.automations().all().filter { it.enabled }.forEach { AutomationScheduler.schedule(context, it) }
            container.log("SYSTEM", "Rescheduled reminders and automations after reboot")
        }
    }
}

object AutomationScheduler {
    const val KEY_ID = "automation_id"
    fun uniqueName(id: Long) = "max_automation_$id"

    fun delayUntilNext(hour: Int, minute: Int, clock: Clock = Clock.systemDefaultZone()): Duration {
        val now = ZonedDateTime.now(clock)
        var next = now.with(LocalTime.of(hour, minute)).withSecond(0).withNano(0)
        if (!next.isAfter(now)) next = next.plusDays(1)
        return Duration.between(now, next)
    }

    /** WorkManager is deferrable: Doze/battery optimisation can delay runs by minutes or more. */
    fun schedule(context: Context, a: AutomationEntity) {
        val req = OneTimeWorkRequestBuilder<ScheduledCommandWorker>()
            .setInitialDelay(delayUntilNext(a.hour, a.minute).toMillis(), TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(KEY_ID to a.id))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(uniqueName(a.id), ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(context: Context, id: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(uniqueName(id))
    }
}

class ScheduledCommandWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getLong(AutomationScheduler.KEY_ID, -1)
        val container = (applicationContext as MaxApp).container
        val dao = container.db.automations()
        val a = dao.get(id) ?: return Result.success()
        if (!a.enabled) return Result.success()

        val settings = container.settings.current()
        val hour = ZonedDateTime.now().hour
        val quiet = if (settings.quietStartHour > settings.quietEndHour) hour >= settings.quietStartHour || hour < settings.quietEndHour
        else hour >= settings.quietStartHour && hour < settings.quietEndHour

        val outcome: String = if (quiet) {
            "Skipped: quiet hours"
        } else {
            val r = container.brain.runUnattended(a.command)
            val delivered = Notifier.post(applicationContext, Notifier.CH_BRIEFING, (10_000 + id).toInt(), a.name, r.take(900))
            if (delivered) "Ran; notification posted" else "Ran; notifications are blocked so nothing was shown"
        }
        dao.update(a.copy(lastRunMs = System.currentTimeMillis(), lastResult = outcome))
        container.log("AUTOMATION", "${a.name}: $outcome")
        AutomationScheduler.schedule(applicationContext, a) // next day
        return Result.success()
    }
}
