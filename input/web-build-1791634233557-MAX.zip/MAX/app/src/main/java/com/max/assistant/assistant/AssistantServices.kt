package com.max.assistant.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.provider.Settings
import com.max.assistant.MainActivity

/** Lets Android list MAX as a selectable "digital assistant app". Does NOT listen in the background. */
class MaxVoiceInteractionService : VoiceInteractionService()

class MaxVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = MaxSession(this)
}

/** When the user triggers the assistant gesture, open MAX ready to listen. Never bypasses the lock screen. */
class MaxSession(private val ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_START_LISTENING, true)
        startAssistantActivity(i)
        hide()
    }
}

object DefaultAssistant {
    /** Opens the system screen where the user picks the default digital assistant (path varies by OEM/OxygenOS). */
    fun settingsIntent(): Intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    fun fallbackIntent(): Intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
