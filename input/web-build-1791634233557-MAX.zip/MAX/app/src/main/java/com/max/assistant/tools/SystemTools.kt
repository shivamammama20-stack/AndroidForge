package com.max.assistant.tools

import android.Manifest
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import com.max.assistant.apps.AppRepository
import com.max.assistant.assistant.DefaultAssistant
import com.max.assistant.contacts.ContactRepository
import com.max.assistant.core.Availability
import com.max.assistant.core.ErrorCategory
import com.max.assistant.core.RiskLevel
import com.max.assistant.core.Tool
import com.max.assistant.core.ToolArgs
import com.max.assistant.core.ToolResult
import com.max.assistant.core.Verification
import com.max.assistant.time.DurationParser
import com.max.assistant.time.TimeParseResult
import com.max.assistant.time.TimeParser
import java.util.Locale
import java.util.TimeZone

/** Starts an activity and reports honestly: success here means "the system accepted the intent", nothing more. */
internal fun startSafely(context: Context, intent: Intent): Boolean = try {
    context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
} catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }

class OpenAppTool(private val context: Context, private val apps: AppRepository) : Tool {
    override val id = "open_app"
    override val description = "Open an installed app"
    override val inputSchema = mapOf("package*" to "Package name of the app to open")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val pkg = args["package"] ?: return ToolResult.fail("Which app?", ErrorCategory.INVALID_INPUT)
        val intent = apps.launchIntent(pkg) ?: return ToolResult.fail("That app has no launchable screen or is not visible to MAX.", ErrorCategory.APP_NOT_FOUND)
        return if (startSafely(context, intent)) ToolResult.ok("Opened ${args["label"] ?: pkg}.", Verification.HANDED_OFF)
        else ToolResult.fail("Android refused to open ${args["label"] ?: pkg}. Background launches can be blocked; try again with MAX on screen.", ErrorCategory.RESTRICTED_BY_ANDROID)
    }
}

class SearchAppsTool(private val apps: AppRepository) : Tool {
    override val id = "search_apps"
    override val description = "Search installed apps by name"
    override val inputSchema = mapOf("query*" to "App name fragment")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val found = apps.search(args["query"].orEmpty())
        if (found.isEmpty()) return ToolResult.fail("No visible app matches \"${args["query"]}\". Android only shows apps MAX is allowed to see.", ErrorCategory.APP_NOT_FOUND)
        return ToolResult.ok(found.take(8).joinToString("\n") { "• ${it.label}" }, Verification.VERIFIED)
    }
}

class SearchContactTool(private val contacts: ContactRepository) : Tool {
    override val id = "search_contact"
    override val description = "Search contacts by name"
    override val inputSchema = mapOf("contact*" to "Name fragment")
    override val requiredPermissions = listOf(Manifest.permission.READ_CONTACTS)
    override val baseRisk = RiskLevel.MEDIUM
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val m = contacts.search(args["contact"].orEmpty())
        if (m.isEmpty()) return ToolResult.fail("No contact found for \"${args["contact"]}\".", ErrorCategory.CONTACT_NOT_FOUND)
        return ToolResult.ok(m.joinToString("\n") { "• ${it.name}" }, Verification.VERIFIED)
    }
}

/** Opens the dialer with the number filled in. MAX never places the call itself (no CALL_PHONE permission). */
class CallContactTool(private val context: Context) : Tool {
    override val id = "call_contact"
    override val description = "Open the dialer for a contact"
    override val inputSchema = mapOf("number*" to "Phone number", "name" to "Display name")
    override val requiredPermissions = listOf(Manifest.permission.READ_CONTACTS)
    override val baseRisk = RiskLevel.HIGH
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val n = args["number"] ?: return ToolResult.fail("No number to dial.", ErrorCategory.INVALID_INPUT)
        val ok = startSafely(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
        return if (ok) ToolResult.ok("Opened the dialer for ${args["name"] ?: n}. Press call to connect; I can't tell if the call happens.", Verification.HANDED_OFF)
        else ToolResult.fail("No dialer app could be opened.", ErrorCategory.SERVICE_UNAVAILABLE)
    }
}

/** Opens the SMS composer prefilled. It is never sent automatically. */
class MessageContactTool(private val context: Context) : Tool {
    override val id = "message_contact"
    override val description = "Open the SMS composer for a contact"
    override val inputSchema = mapOf("number*" to "Phone number", "name" to "Display name", "body" to "Message text")
    override val requiredPermissions = listOf(Manifest.permission.READ_CONTACTS)
    override val baseRisk = RiskLevel.MEDIUM
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val n = args["number"] ?: return ToolResult.fail("No number to message.", ErrorCategory.INVALID_INPUT)
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", args["body"].orEmpty())
        return if (startSafely(context, i)) ToolResult.ok("Opened the message composer for ${args["name"] ?: n}. The message has NOT been sent; review and press send.", Verification.HANDED_OFF)
        else ToolResult.fail("No messaging app could be opened.", ErrorCategory.SERVICE_UNAVAILABLE)
    }
}

/** Map abstraction so another provider (e.g. an in-app map) can replace intent hand-off. */
interface MapProvider {
    fun searchIntent(query: String): Intent
    fun navigateIntent(destination: String): Intent
}

class IntentMapProvider : MapProvider {
    override fun searchIntent(query: String) = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(query)))
    override fun navigateIntent(destination: String) = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination)))
}

class MapSearchTool(private val context: Context, private val provider: MapProvider) : Tool {
    override val id = "map_search"
    override val description = "Search a place in an installed maps app"
    override val inputSchema = mapOf("query*" to "Place or category")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val q = args["query"] ?: return ToolResult.fail("What should I search for?", ErrorCategory.INVALID_INPUT)
        return if (startSafely(context, provider.searchIntent(q))) ToolResult.ok("Opened your maps app to search for \"$q\".", Verification.HANDED_OFF)
        else ToolResult.fail("No maps app is installed that can handle searches.", ErrorCategory.APP_NOT_FOUND)
    }
}

class NavigateTool(private val context: Context, private val provider: MapProvider) : Tool {
    override val id = "navigate"
    override val description = "Hand a destination to an installed navigation app"
    override val inputSchema = mapOf("destination*" to "Destination text")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val d = args["destination"] ?: return ToolResult.fail("Where to?", ErrorCategory.INVALID_INPUT)
        if (startSafely(context, provider.navigateIntent(d))) return ToolResult.ok("Opened navigation to \"$d\" in your maps app. I can't tell whether the trip started.", Verification.HANDED_OFF)
        // Fallback: plain geo search.
        return if (startSafely(context, provider.searchIntent(d))) ToolResult.partial("No navigation app handled it, so I opened a map search for \"$d\" instead.", Verification.HANDED_OFF)
        else ToolResult.fail("No maps or navigation app is installed.", ErrorCategory.APP_NOT_FOUND)
    }
}

/** Sends a media key event to whatever app currently owns media focus. Android gives no confirmation. */
class MediaKeyTool(
    private val context: Context,
    override val id: String,
    override val description: String,
    private val keyCode: Int,
    private val verbPast: String,
) : Tool {
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val am = context.getSystemService(AudioManager::class.java)
        return try {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
            ToolResult.ok("Sent a \"$verbPast\" media command. If nothing is playing or the app ignores media keys, nothing will change.", Verification.UNVERIFIED)
        } catch (e: Exception) {
            ToolResult.fail("Could not send the media command.", ErrorCategory.SERVICE_UNAVAILABLE)
        }
    }
}

class VolumeTool(private val context: Context) : Tool {
    override val id = "volume"
    override val description = "Change media volume"
    override val inputSchema = mapOf("direction*" to "up | down | mute")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val am = context.getSystemService(AudioManager::class.java)
        val before = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val dir = when (args["direction"]) {
            "up", "badhao" -> AudioManager.ADJUST_RAISE
            "down", "kam karo" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            else -> return ToolResult.fail("Say volume up, down or mute.", ErrorCategory.INVALID_INPUT)
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        val after = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (after != before || dir == AudioManager.ADJUST_MUTE && am.isStreamMute(AudioManager.STREAM_MUSIC))
            ToolResult.ok("Media volume is now $after of $max.", Verification.VERIFIED)
        else ToolResult.partial("Volume stayed at $after of $max (already at the limit, or the device blocked the change).", Verification.VERIFIED)
    }
}

class TimerTool(private val context: Context) : Tool {
    override val id = "timer"
    override val description = "Start a countdown timer in the clock app"
    override val inputSchema = mapOf("when*" to "Text containing a duration, e.g. 5 minutes")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val sec = DurationParser.parseSeconds(args["when"].orEmpty())
            ?: return ToolResult.fail("How long should the timer run? For example: 10 minutes.", ErrorCategory.AMBIGUOUS)
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_MESSAGE, "MAX timer").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (startSafely(context, i)) ToolResult.ok("Asked your clock app to start a ${sec / 60}m ${sec % 60}s timer. Check the clock app to confirm it is running.", Verification.HANDED_OFF)
        else ToolResult.fail("No clock app accepted the timer request.", ErrorCategory.SERVICE_UNAVAILABLE)
    }
}

class AlarmTool(private val context: Context, private val timeParser: TimeParser) : Tool {
    override val id = "alarm"
    override val description = "Create an alarm in the clock app"
    override val inputSchema = mapOf("when*" to "Time text, e.g. kal subah 6 baje")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val t = when (val r = timeParser.parse(args["when"].orEmpty())) {
            is TimeParseResult.At -> r.time
            is TimeParseResult.Ambiguous -> return ToolResult.fail(r.question, ErrorCategory.AMBIGUOUS)
            TimeParseResult.None -> return ToolResult.fail("What time should the alarm be for?", ErrorCategory.AMBIGUOUS)
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, t.hour).putExtra(AlarmClock.EXTRA_MINUTES, t.minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "MAX alarm").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (startSafely(context, i)) ToolResult.ok("Asked your clock app to set an alarm for %02d:%02d. Please confirm it in the clock app.".format(t.hour, t.minute), Verification.HANDED_OFF)
        else ToolResult.fail("No clock app accepted the alarm request.", ErrorCategory.SERVICE_UNAVAILABLE)
    }
}

class DeviceInfoTool(private val context: Context) : Tool {
    override val id = "device_info"
    override val description = "Battery, OS and locale information"
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val bi = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else null
        val lines = buildList {
            add(if (pct != null) "Battery: $pct%${if (charging) " (charging)" else ""}" else "Battery: unavailable")
            add("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
            add("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            add("Timezone: ${TimeZone.getDefault().id}, locale ${Locale.getDefault().toLanguageTag()}")
        }
        return ToolResult.ok(lines.joinToString("\n"), Verification.VERIFIED)
    }
}

class DeviceSettingsTool(private val context: Context) : Tool {
    override val id = "device_settings"
    override val description = "Open a system settings page (MAX cannot change these itself)"
    override val inputSchema = mapOf("page*" to "wifi|bluetooth|notification|battery|display|sound|app|permission|accessibility|assistant")
    override val requiredPermissions = emptyList<String>()
    override val baseRisk = RiskLevel.LOW
    override fun availability() = Availability.YES
    override suspend fun execute(args: ToolArgs): ToolResult {
        val page = args["page"].orEmpty()
        val pkgUri = Uri.parse("package:${context.packageName}")
        val i: Intent = when (page) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "notification" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "app", "permission" -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "assistant" -> DefaultAssistant.settingsIntent()
            else -> return ToolResult.fail("I can open wifi, bluetooth, notification, battery, display, sound, app, accessibility or assistant settings.", ErrorCategory.INVALID_INPUT)
        }
        if (startSafely(context, i)) return ToolResult.ok("Opened $page settings. I can't change settings myself; please toggle them there.", Verification.HANDED_OFF)
        if (page == "assistant" && startSafely(context, DefaultAssistant.fallbackIntent()))
            return ToolResult.partial("Opened default apps settings; look for 'Digital assistant app'.", Verification.HANDED_OFF)
        return ToolResult.fail("This device has no screen for $page settings.", ErrorCategory.RESTRICTED_BY_ANDROID)
    }
}
