package com.max.assistant.contacts

import android.content.Context
import android.provider.ContactsContract

data class ContactMatch(val name: String, val number: String)

sealed class ContactResolution {
    object None : ContactResolution()
    data class Single(val match: ContactMatch) : ContactResolution()
    data class Multiple(val options: List<ContactMatch>) : ContactResolution()
}

object ContactResolver {
    /** Same name + same normalised number = duplicate row; anything else needs the user to choose. */
    fun resolve(matches: List<ContactMatch>): ContactResolution {
        val unique = matches.distinctBy { it.name.lowercase() to it.number.filter { c -> c.isDigit() }.takeLast(10) }
        return when (unique.size) {
            0 -> ContactResolution.None
            1 -> ContactResolution.Single(unique[0])
            else -> ContactResolution.Multiple(unique)
        }
    }
}

class ContactRepository(private val context: Context) {
    /** Caller must hold READ_CONTACTS. */
    fun search(name: String, limit: Int = 10): List<ContactMatch> {
        val out = ArrayList<ContactMatch>()
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC",
        ) ?: return emptyList()
        cursor.use {
            while (it.moveToNext() && out.size < limit) out += ContactMatch(it.getString(0).orEmpty(), it.getString(1).orEmpty())
        }
        return out
    }
}
