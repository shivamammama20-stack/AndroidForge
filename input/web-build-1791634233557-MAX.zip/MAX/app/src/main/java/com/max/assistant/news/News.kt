package com.max.assistant.news

import com.max.assistant.net.Http
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.w3c.dom.Element
import org.xml.sax.InputSource
import java.io.StringReader
import java.time.Duration
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import javax.xml.parsers.DocumentBuilderFactory

data class NewsItem(
    val title: String,
    val url: String,
    val source: String,
    val category: String,
    val publishedAt: Instant?,
    val summary: String,
)

/** Pure RSS 2.0 parsing (no Android dependencies -> unit-testable). */
object RssParser {
    fun parse(xml: String, source: String, category: String): List<NewsItem> {
        val factory = DocumentBuilderFactory.newInstance().apply {
            // Harden against XXE.
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            isNamespaceAware = false
        }
        val doc = factory.newDocumentBuilder().parse(InputSource(StringReader(xml)))
        val items = doc.getElementsByTagName("item")
        val out = ArrayList<NewsItem>()
        for (i in 0 until items.length) {
            val e = items.item(i) as? Element ?: continue
            fun text(tag: String) = e.getElementsByTagName(tag).item(0)?.textContent?.trim().orEmpty()
            val title = text("title")
            val link = text("link")
            if (title.isEmpty() || link.isEmpty()) continue
            out += NewsItem(
                title = title,
                url = link,
                source = source,
                category = category,
                publishedAt = parseDate(text("pubDate")),
                summary = text("description").replace(Regex("<[^>]*>"), "").trim(),
            )
        }
        return out
    }

    fun parseDate(s: String): Instant? {
        if (s.isBlank()) return null
        return runCatching { ZonedDateTime.parse(s, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant() }.getOrNull()
    }
}

data class NewsFeed(val category: String, val sourceName: String, val url: String)

data class NewsResult(
    val items: List<NewsItem>,
    /** Categories whose feed failed, with the reason. */
    val failures: Map<String, String>,
    /** Items dropped because their publication date was missing or too old. */
    val skippedUndatedOrStale: Int,
)

/**
 * Keyless news via public RSS feeds. Feeds are plain URLs the user can change in code/settings later.
 * Categories with no feed configured (politics, defence, autos, ...) are simply not offered:
 * MAX never invents stories for them.
 */
class NewsRepository(
    private val feeds: List<NewsFeed> = DEFAULT_FEEDS,
    private val maxAge: Duration = Duration.ofHours(48),
    private val nowProvider: () -> Instant = { Instant.now() },
    private val fetcher: suspend (String) -> String = { Http.get(it) },
) {
    fun supportedCategories(): List<String> = feeds.map { it.category }.distinct()

    suspend fun fetch(categories: Collection<String>, perCategory: Int = 5): NewsResult = coroutineScope {
        val wanted = feeds.filter { it.category in categories }
        val jobs = wanted.map { f ->
            f to async { runCatching { RssParser.parse(fetcher(f.url), f.sourceName, f.category) } }
        }
        val items = ArrayList<NewsItem>()
        val failures = LinkedHashMap<String, String>()
        var skipped = 0
        val now = nowProvider()
        for ((feed, job) in jobs) {
            val r = job.await()
            r.onFailure { failures[feed.category] = it.message ?: it.javaClass.simpleName }
            r.onSuccess { list ->
                val fresh = list.filter { it.publishedAt != null && Duration.between(it.publishedAt, now) <= maxAge }
                skipped += list.size - fresh.size
                items += fresh.sortedByDescending { it.publishedAt }.take(perCategory)
            }
        }
        NewsResult(dedupe(items), failures, skipped)
    }

    companion object {
        fun dedupe(items: List<NewsItem>): List<NewsItem> {
            val seen = HashSet<String>()
            return items.filter { seen.add(normalize(it.title)) }
        }

        private fun normalize(t: String) = t.lowercase().replace(Regex("[^a-z0-9 ]"), "").replace(Regex("\\s+"), " ").trim()

        val DEFAULT_FEEDS = listOf(
            NewsFeed("world", "BBC News", "https://feeds.bbci.co.uk/news/world/rss.xml"),
            NewsFeed("india", "The Hindu", "https://www.thehindu.com/news/national/feeder/default.rss"),
            NewsFeed("business", "BBC News", "https://feeds.bbci.co.uk/news/business/rss.xml"),
            NewsFeed("technology", "BBC News", "https://feeds.bbci.co.uk/news/technology/rss.xml"),
            NewsFeed("science", "BBC News", "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml"),
            NewsFeed("health", "BBC News", "https://feeds.bbci.co.uk/news/health/rss.xml"),
            NewsFeed("sports", "BBC Sport", "https://feeds.bbci.co.uk/sport/rss.xml"),
            NewsFeed("entertainment", "BBC News", "https://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml"),
        )
    }
}
