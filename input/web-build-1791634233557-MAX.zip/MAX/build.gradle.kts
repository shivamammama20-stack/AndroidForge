// Toolchain pinned per the MAX master prompt:
//   AGP 8.1.4, Kotlin 1.9.24, Gradle 8.0 (see gradle/wrapper/gradle-wrapper.properties)
plugins {
    id("com.android.application") version "8.1.4" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    // KSP version must match the Kotlin version prefix (1.9.24-1.0.20).
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}
