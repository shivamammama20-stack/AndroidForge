# MAX — personal Android AI assistant

Native Android (Kotlin + Jetpack Compose). Package `com.max.assistant`. Repository target: `shivamammama20-stack/Max`.

> **BUILD STATUS — READ FIRST**
> This source tree was written in a sandbox with **no Android SDK, no Maven/Google repository access and no Kotlin compiler**.
> **It has never been compiled, no tests have been run, and no APK exists.** Expect a few compile errors on the first build
> (typos, a missing import, an API nuance). Fix them from the Gradle output, or paste the log back to Claude.
> Nothing in this README claims otherwise.

## Required toolchain (pinned as requested)

| Item | Version |
|---|---|
| Android Gradle Plugin | 8.1.4 |
| Kotlin | 1.9.24 (Compose compiler 1.5.14, KSP 1.9.24-1.0.20) |
| Gradle | **8.0** (`gradle/wrapper/gradle-wrapper.properties`) |
| compileSdk / targetSdk / minSdk | 34 / 34 / 26 |
| JDK | 17 (AGP 8.1 needs 11+, 17 recommended) |

The earlier failure (AGP 8.6.1 needing Gradle 8.7) cannot recur here: AGP is 8.1.4 and the wrapper is 8.0.
**If your build service ignores the wrapper** (e.g. AndroidForge), set its Gradle version to 8.0 manually.

## Build

```
./gradlew :app:testDebugUnitTest      # run unit tests
./gradlew :app:assembleDebug          # APK -> app/build/outputs/apk/debug/app-debug.apk
```
Needs the Android SDK (platform 34, build-tools 34). GitHub Actions workflow `.github/workflows/build-apk.yml` does both steps,
fails if the APK is not produced, and uploads it as an artifact. In Codespaces install the SDK first (`ANDROID_HOME`).

## Install

Copy `app-debug.apk` to the phone, open it, allow "Install unknown apps" for your file manager/browser. Debug builds are signed with the debug key (fine for personal use).
Or: `adb install app-debug.apk`.

## Structure

```
core/        ToolResult, Tool interface, risk/verification enums
intent/      IntentDetector (offline EN / Hindi / Hinglish rules)
brain/       MaxBrain pipeline, RiskEngine
context/     short-term ConversationContext, pending confirmations
tools/       ToolRegistry + system tools (apps, calls, SMS, maps, media, timers, device) + data tools (reminders, calendar, memory, weather, news, search, briefing)
apps/ contacts/ notifications/ accessibility/ assistant/   Android integrations
voice/ tts/  SpeechRecognizer and TextToSpeech wrappers
reminders/   AlarmManager reminders, boot rescheduling, WorkManager automations
briefing/ news/ weather/ web/ ai/ net/   data providers (replaceable)
data/ settings/ security/   Room, DataStore, Keystore-backed SecretStore
ui/          HUD, screens, ViewModel
time/        TimeParser, DurationParser (device timezone via injected Clock)
```

Pipeline: input → intent → context/entity resolution (apps, contacts) → tool → permission check → risk → confirmation / biometric → execution → structured `ToolResult` → response → TTS. The AI provider is only used for conversation and news explanations; it never decides whether an action succeeded.

## Optional providers

* **AI** (Settings → AI provider): any OpenAI-compatible `/chat/completions` endpoint — you supply base URL, model and key. Key is AES-GCM encrypted with an Android Keystore key. Free-tier limits depend on the provider you choose; none are promised here.
* **Web search**: Brave Search API key (you register; see Brave's current plans). Without it `search …` reports "unavailable".
* **Weather**: Open-Meteo (no key; free for non-commercial use under their terms — check them). Needs a city in Settings or location permission.
* **News**: public RSS (BBC, The Hindu), no key. Feed URLs are in `NewsRepository.DEFAULT_FEEDS`; they can change or block at any time. Feeds were **not** reachable from the build sandbox, so they are untested.

## Permissions (requested when needed, see Permission Center)

Microphone, notifications (API 33+), contacts (read), camera (OCR screen only), approximate/fine location (optional), calendar (read), exact alarms, notification-listener access and accessibility (both enabled by you in system settings). **Not requested:** `CALL_PHONE`, `SEND_SMS`, `QUERY_ALL_PACKAGES`.

## Honest behavior notes

* Calls: MAX opens the **dialer**; you press call. SMS: opens the **composer**; you press send. Results say "opened", never "sent/connected".
* Navigation/maps: hands off to an installed maps app; "opened", not "trip started".
* Media: sends media key events; Android gives no confirmation, so result is marked unverified.
* Alarms/timers: delegated to the clock app (`AlarmClock` intents); marked "handed off".
* Reminders: saved in Room and scheduled via AlarmManager; saved only if scheduling succeeds; reports INEXACT if exact-alarm permission is missing, and warns if notifications are blocked.
* Settings (Wi-Fi, Bluetooth, brightness…): MAX opens the settings screen; it does not change them.
* Default assistant: `VoiceInteractionService` is declared and you pick MAX in system settings (OxygenOS: Settings → Apps → Default apps → Digital assistant app; wording varies). It handles the assist gesture by opening MAX. **No always-on wake word, no listening when the phone is off, no lock-screen bypass.** Sensitive actions need your biometric/PIN. OxygenOS battery optimisation can delay/kill background work — exempt MAX in battery settings if scheduled briefings are late.
* Scheduled automations use WorkManager (deferrable; may run late in Doze). Unattended runs skip anything needing confirmation. Quiet hours suppress them.
* OCR uses ML Kit's bundled Latin model (offline). It does not read Devanagari/Hindi text.
* Hindi/Hinglish: recognition language is selectable; quality depends on the device recogniser and installed TTS voices. Intent rules cover common romanised Hindi phrases only. Replies are English text.
* Security Guardian: a name or spoken claim is never proof of identity. Trust categories are stored and shown; only protected-app and sensitive-action checks currently enforce anything (biometric/device credential). An ordinary app cannot lock other apps or defend a compromised phone.

## Implementation status

**Implemented, untested (never compiled or run):**
HUD (orb, rings, waveform, states), MaxBrain pipeline, intent detection, context/follow-ups, ToolRegistry (30 tools), RiskEngine + confirmation expiry + biometric gate, app discovery/launch, contact search/disambiguation, call/SMS hand-off, notification listener + summary, accessibility service (read/click/scroll primitives), maps/navigation intents, media keys, volume, reminders/timers/alarms, calendar read, Automation Center, Memory Center, Security Guardian screen, Permission Center, settings, diagnostics, VoiceManager, TTSManager, CameraX + ML Kit OCR, weather, news, daily briefing (modes, sections, filters, follow-ups), boot rescheduling.

**Unit tests written, not run:** `app/src/test/.../CoreLogicTest.kt` covers intent detection, time/timezone parsing, durations, risk, app/contact matching, RSS parsing (incl. XXE rejection), staleness filtering, briefing modes/sections/skip/only/notes. No instrumentation tests exist.

**Requires provider configuration:** AI conversation and explanations, web search/research, weather location, live news.

**Partially implemented:**
* Accessibility: service primitives exist but no voice command calls them yet (no "read my screen" intent).
* Research / FactCheck tools: only raw `web_search`; no multi-source research or fact-checking pipeline.
* Automation: daily time triggers only; no notification/device-state triggers or conditions.
* Briefing: no scheduled TTS playback (scheduled runs post a notification only); calendar and reminders included, important notifications are not.
* Current affairs categories: world, India, business, tech, science, health, sports, entertainment. No politics/defence/auto/stocks feeds.
* Reminders: no edit UI (delete/complete only); recurring = daily only.
* Trusted users/protected apps: stored; trust categories do not yet change risk decisions.
* Language: no Hindi UI strings; no localisation resources.

**Restricted by Android:** exact alarms need user grant; background mic/wake word; setting system toggles; default-assistant status can't be verified; hidden-package visibility; call/SMS completion can't be observed.

**Not implemented:** wake-word, in-app map, calendar write, brightness/Bluetooth/Wi-Fi control, notification open/reply, composed multi-step workflows, instrumented tests, release signing, ProGuard rules, app icon beyond a simple vector.

## Security & privacy decisions

No keys in source. Secrets are Keystore-encrypted. `allowBackup=false`. Notification text is memory-only. Memory/history can be turned off, edited and deleted; memory, contacts, calendar and notifications are never sent to an AI provider (only your typed/spoken sentence, or a public headline + summary for explanations). No hidden recording, covert camera/mic, keylogging or lock-screen bypass exists in the code. Logs record tool outcomes, not message contents or keys.

## Next steps

1. Build; fix any compile errors; run unit tests.
2. Device-test on OxygenOS (assistant gesture, battery restrictions, exact alarms).
3. Add instrumentation tests, accessibility voice commands, research/fact-check, more feeds.
