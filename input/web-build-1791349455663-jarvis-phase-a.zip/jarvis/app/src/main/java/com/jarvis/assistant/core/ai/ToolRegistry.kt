package com.jarvis.assistant.core.ai
class ToolRegistry {
    private val tools = linkedMapOf<String, Tool>()
    fun register(tool: Tool) { tools[tool.name] = tool }
    fun get(name: String) = tools[name]
    fun all(): List<Tool> = tools.values.toList()
    suspend fun run(name: String, args: Map<String, String>, confirmed: Boolean = false): ToolResult {
        val t = tools[name] ?: return ToolResult(false, failureReason = "Unknown tool: $name")
        if (t.securityLevel.needsConfirmation && !confirmed) return ToolResult(false, requiresConfirmation = true, failureReason = "Confirmation required")
        return runCatching { t.execute(args) }.getOrElse { ToolResult(false, failureReason = it.message) }
    }
}
