package com.jarvis.assistant.feature.dashboard
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.core.common.JarvisState
@Composable
fun JarvisOrb(state: JarvisState, modifier: Modifier = Modifier) {
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.9f, 1.1f,
        infiniteRepeatable(tween(if (state == JarvisState.IDLE) 2400 else 900), RepeatMode.Reverse), label = "s")
    val color = when (state) { JarvisState.ERROR -> Color(0xFFFF5252); JarvisState.SECURITY -> Color(0xFFFFB300); else -> Color(0xFF29D3FF) }
    Canvas(modifier.size(220.dp)) {
        drawCircle(color.copy(alpha = 0.15f), radius = size.minDimension / 2 * pulse)
        drawCircle(color.copy(alpha = 0.45f), radius = size.minDimension / 3 * pulse)
        drawCircle(color, radius = size.minDimension / 6)
    }
}
