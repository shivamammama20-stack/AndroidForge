package com.jarvis.assistant.core.ai
import com.jarvis.assistant.core.security.SecurityLevel
data class ToolResult(val success: Boolean, val actionPerformed: String = "", val verification: String = "",
    val failureReason: String? = null, val requiresPermission: String? = null, val requiresConfirmation: Boolean = false)
interface Tool {
    val name: String
    val description: String
    val parameters: Map<String, String>
    val securityLevel: SecurityLevel
    val requiredPermissions: List<String> get() = emptyList()
    suspend fun execute(args: Map<String, String>): ToolResult
}
