package com.jarvis.assistant
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.jarvis.assistant.core.common.JarvisState
import com.jarvis.assistant.feature.dashboard.JarvisOrb
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF05080F))) {
                Column(Modifier.fillMaxSize().background(Color(0xFF05080F)), Arrangement.Center, Alignment.CenterHorizontally) {
                    JarvisOrb(JarvisState.IDLE)
                    Text("JARVIS — idle", color = Color(0xFF29D3FF))
                }
            }
        }
    }
}
