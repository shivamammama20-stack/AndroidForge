package com.starkorbit.jarvis

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var speakButton: Button
    private var tts: TextToSpeech? = null
    private var listening = false
    private val requestAudio = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 28)
        window.navigationBarColor = Color.rgb(8, 14, 28)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(8, 14, 28))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 30f
            setTextColor(Color.rgb(105, 220, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL ANDROID ASSISTANT"
            textSize = 12f
            letterSpacing = 0.15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready, sir."
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 14)
        }
        speakButton = Button(this).apply {
            text = "🎙  TAP TO SPEAK"
            textSize = 16f
            setOnClickListener { startListening() }
        }
        output = TextView(this).apply {
            text = "Try saying:\n• Open YouTube\n• Open Maps\n• Open camera\n• Search for space news\n• What time is it?\n• Help"
            textSize = 16f
            setTextColor(Color.rgb(225, 233, 245))
            setPadding(18, 18, 18, 18)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(speakButton, LinearLayout.LayoutParams(-1, -2))
        val gap = View(this)
        root.addView(gap, LinearLayout.LayoutParams(1, 18))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Speech recognition is not available on this device.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try {
            status.text = "Listening…"
            startActivityForResult(intent, 502)
        } catch (_: ActivityNotFoundException) {
            respond("No compatible speech recognition app was found.")
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 502 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handleCommand(spoken)
            else respond("Sorry, I didn't catch that.")
        } else if (requestCode == 502) {
            status.text = "Ready, sir."
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.getDefault()).trim()
        output.text = "You: $raw\n\n"
        when {
            "youtube" in command -> openWeb("https://www.youtube.com", "Opening YouTube.")
            "map" in command || "navigate" in command -> {
                val q = command.replace("open maps", "").replace("open map", "")
                    .replace("navigate to", "").replace("search maps for", "").trim()
                val uri = if (q.isBlank()) "https://maps.google.com" else "https://www.google.com/maps/search/?api=1&query=${android.net.Uri.encode(q)}"
                openWeb(uri, if (q.isBlank()) "Opening Maps." else "Searching Maps for $q.")
            }
            "camera" in command -> launchIntent(Intent("android.media.action.IMAGE_CAPTURE"), "Opening camera.")
            "settings" in command -> launchIntent(Intent(android.provider.Settings.ACTION_SETTINGS), "Opening Settings.")
            "browser" in command || "google" in command || "search for" in command || "search " in command -> {
                val q = command.replace("search for", "").replace("search", "").replace("on google", "").trim()
                openWeb("https://www.google.com/search?q=${android.net.Uri.encode(q.ifBlank { raw })}", "Searching the web.")
            }
            "time" in command -> respond("The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()))
            "date" in command || "day is it" in command -> respond("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
            "battery" in command -> {
                val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra("level", -1) ?: -1
                respond(if (level >= 0) "Battery is at $level percent." else "I couldn't read the battery level.")
            }
            "help" in command -> respond("You can ask me to open YouTube, Maps, camera, or Settings, search the web, or tell you the time, date, and battery level.")
            else -> respond("I heard: $raw. Try saying open YouTube, open Maps, search for space news, or what time is it.")
        }
    }

    private fun openWeb(url: String, message: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
            respond(message)
        } catch (_: Exception) { respond("I couldn't open that link.") }
    }

    private fun launchIntent(intent: Intent, message: String) {
        try {
            startActivity(intent)
            respond(message)
        } catch (_: Exception) { respond("That feature isn't available on this device.") }
    }

    private fun respond(message: String) {
        status.text = message
        output.append(message + "\n")
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
