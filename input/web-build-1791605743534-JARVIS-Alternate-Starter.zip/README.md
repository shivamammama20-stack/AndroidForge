# JARVIS Alternate Starter

A deliberately simplified native Android starter intended to reduce build complexity.

## Included
- Dark JARVIS-style screen
- Tap-to-speak using Android's installed speech recognition service
- Spoken replies using Android Text-to-Speech
- Opens YouTube, Maps, camera and Android Settings
- Web search, date/time and battery-level commands

## Important limits
- This is a starter build, not the full always-on JARVIS assistant.
- Speech recognition availability depends on the device and installed speech service.
- It listens only after the user taps the microphone button.
- It does not send messages, make calls, read notifications, or run a custom wake word in the background.
- The project has not been built or tested on your phone in this environment.
- Do not upload private API keys or passwords into the source ZIP.

## Build
Open this folder as a Gradle Android project in Android Studio, or use a compatible AndroidForge workflow that accepts a standard Android Gradle project ZIP.
