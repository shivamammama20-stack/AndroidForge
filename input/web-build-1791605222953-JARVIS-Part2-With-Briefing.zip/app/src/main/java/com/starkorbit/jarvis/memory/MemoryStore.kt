package com.starkorbit.jarvis.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)

    fun addConversation(role: String, text: String) {
        append("conversation", JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("role", role)
            put("text", text)
        })
    }

    fun addNotification(pkg: String, title: String, text: String) {
        append("notifications", JSONObject().apply {
            put("time", System.currentTimeMillis())
            put("package", pkg)
            put("title", title)
            put("text", text)
        })
    }

    fun get(key: String): JSONArray =
        JSONArray(prefs.getString(key, "[]"))

    private fun append(key: String, item: JSONObject) {
        val arr = get(key)
        arr.put(item)
        while (arr.length() > 200) arr.remove(0)
        prefs.edit().putString(key, arr.toString()).apply()
    }
}
