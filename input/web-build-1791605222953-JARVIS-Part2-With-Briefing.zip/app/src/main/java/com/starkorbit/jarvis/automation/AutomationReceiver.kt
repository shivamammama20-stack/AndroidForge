package com.starkorbit.jarvis.automation

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AutomationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Scheduled reminder"
        val command = intent.getStringExtra("command").orEmpty()
        val channelId = "jarvis_reminders"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "JARVIS reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("It's time, sir. ${command.take(100)}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("It's time, sir. $command"))
            .setAutoCancel(true).build()
        manager.notify(intent.getLongExtra("id", System.currentTimeMillis()).hashCode(), notification)
        context.getSharedPreferences("jarvis_events", Context.MODE_PRIVATE).edit()
            .putString("lastReminder", "$title|$command|${System.currentTimeMillis()}").apply()
    }
}
