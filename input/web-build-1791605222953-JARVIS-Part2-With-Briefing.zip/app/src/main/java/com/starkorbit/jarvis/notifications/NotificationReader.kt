package com.starkorbit.jarvis.notifications

import android.content.Context
import com.starkorbit.jarvis.memory.MemoryStore

class NotificationReader(context: Context) {
    private val memory = MemoryStore(context)
    fun recent(limit: Int = 10): List<String> {
        val all = memory.get("notifications")
        val start = maxOf(0, all.length() - limit)
        return (start until all.length()).mapNotNull { i ->
            val o = all.optJSONObject(i) ?: return@mapNotNull null
            "${o.optString("title")}: ${o.optString("text")}".trim()
        }.reversed()
    }
}
