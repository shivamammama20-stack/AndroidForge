package com.starkorbit.jarvis.briefing

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import com.starkorbit.jarvis.automation.AutomationEngine
import com.starkorbit.jarvis.notifications.NotificationReader
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Builds a fresh briefing when the user says "Jarvis, briefing".
 *
 * It fetches current headline candidates from GDELT's public news search API,
 * then combines them with local battery, reminders and recent notifications.
 * The results are cached only as a convenience; each explicit briefing request
 * attempts a fresh fetch.
 */
class BriefingService(private val context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_briefing", Context.MODE_PRIVATE)

    fun createBriefing(): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.getDefault()).format(Date())
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val battery = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        val sections = mutableListOf<String>()
        sections += "Good day, sir. Here is your briefing for $now."
        sections += "Device status: battery at $battery percent."

        val upcoming = AutomationEngine(context).list()
            .filter { it.triggerAt >= System.currentTimeMillis() }
            .sortedBy { it.triggerAt }
            .take(3)

        if (upcoming.isEmpty()) {
            sections += "Schedule: no upcoming JARVIS reminders are saved."
        } else {
            val formatter = SimpleDateFormat("h:mm a", Locale.getDefault())
            sections += "Upcoming reminders: " + upcoming.joinToString("; ") {
                "${it.title} at ${formatter.format(Date(it.triggerAt))}"
            } + "."
        }

        val notifications = NotificationReader(context).recent(3)
        if (notifications.isNotEmpty()) {
            sections += "Recent notifications: " + notifications.joinToString("; ") + "."
        }

        val news = fetchHeadlines()
        if (news.isNotEmpty()) {
            sections += "Current headlines: " + news.joinToString(" ") { "${it.first}. ${it.second}" }
        } else {
            sections += "Current headlines could not be refreshed right now. I have not substituted old headlines."
        }

        val output = sections.joinToString("\n\n")
        prefs.edit()
            .putString("lastBriefing", output)
            .putLong("lastBriefingAt", System.currentTimeMillis())
            .apply()
        return output
    }

    fun lastBriefing(): String = prefs.getString("lastBriefing", "No briefing has been generated yet.").orEmpty()

    private fun fetchHeadlines(): List<Pair<String, String>> {
        return try {
            // GDELT is a public news-index API. Its availability/coverage can vary.
            val query = URLEncoder.encode("world news OR technology OR India", "UTF-8")
            val endpoint = URL(
                "https://api.gdeltproject.org/api/v2/doc/doc?query=$query&mode=ArtList&format=json&maxrecords=5&sort=HybridRel"
            )
            val connection = endpoint.openConnection() as HttpURLConnection
            connection.connectTimeout = 6000
            connection.readTimeout = 8000
            connection.setRequestProperty("User-Agent", "JARVIS-Android/1.0")
            val code = connection.responseCode
            if (code !in 200..299) return emptyList()
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val articles = JSONObject(body).optJSONArray("articles") ?: return emptyList()
            (0 until minOf(articles.length(), 5)).mapNotNull { index ->
                val article = articles.optJSONObject(index) ?: return@mapNotNull null
                val title = article.optString("title").trim()
                val url = article.optString("url").trim()
                val source = article.optString("domain").trim()
                if (title.isBlank()) null else title to (if (source.isBlank()) url else "Source: $source. $url")
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun openHeadlineSearch() {
        val uri = Uri.parse("https://news.google.com/")
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
