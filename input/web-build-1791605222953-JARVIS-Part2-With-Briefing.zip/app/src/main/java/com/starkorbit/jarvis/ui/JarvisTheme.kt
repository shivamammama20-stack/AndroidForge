package com.starkorbit.jarvis.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF62D9FF),
    secondary = Color(0xFF8B9CFF),
    background = Color(0xFF080A10),
    surface = Color(0xFF10131B)
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Dark, content = content)
}
