package com.starkorbit.jarvis.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.starkorbit.jarvis.core.ToolResult
import org.json.JSONArray
import org.json.JSONObject

data class ScheduledJarvisTask(val id: Long, val title: String, val command: String, val triggerAt: Long)

class AutomationEngine(private val context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_automation", Context.MODE_PRIVATE)

    fun schedule(title: String, command: String, triggerAtMillis: Long): ToolResult {
        if (triggerAtMillis <= System.currentTimeMillis()) return ToolResult(false, "Choose a future time.")
        val id = System.currentTimeMillis()
        val item = JSONObject().put("id", id).put("title", title).put("command", command).put("triggerAt", triggerAtMillis)
        val all = JSONArray(prefs.getString("tasks", "[]")); all.put(item)
        prefs.edit().putString("tasks", all.toString()).apply()
        val intent = Intent(context, AutomationReceiver::class.java).putExtra("id", id).putExtra("title", title).putExtra("command", command)
        val pending = PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return try {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pending)
            ToolResult(true, "Scheduled $title.")
        } catch (_: SecurityException) {
            ToolResult(false, "Android blocked this alarm. Check alarm permissions or use a notification reminder.")
        }
    }

    fun list(): List<ScheduledJarvisTask> {
        val all = JSONArray(prefs.getString("tasks", "[]"))
        return (0 until all.length()).mapNotNull { i ->
            val o = all.optJSONObject(i) ?: return@mapNotNull null
            ScheduledJarvisTask(o.optLong("id"), o.optString("title"), o.optString("command"), o.optLong("triggerAt"))
        }
    }
}
