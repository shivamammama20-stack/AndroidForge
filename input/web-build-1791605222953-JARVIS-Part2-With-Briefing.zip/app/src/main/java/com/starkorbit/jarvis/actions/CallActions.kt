package com.starkorbit.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.starkorbit.jarvis.contacts.ContactResolver
import com.starkorbit.jarvis.core.ContactInfo
import com.starkorbit.jarvis.core.ToolResult

class CallActions(private val context: Context) {
    fun callContact(contact: ContactInfo?): ToolResult {
        if (contact?.number.isNullOrBlank()) return ToolResult(false, "I couldn't find a phone number for that contact.")
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(contact!!.number)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ToolResult(true, "Opening the dialer for ${contact.name}.")
    }
}
