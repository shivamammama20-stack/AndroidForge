package com.starkorbit.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.starkorbit.jarvis.contacts.ContactResolver
import com.starkorbit.jarvis.core.ToolResult

class MessageActions(private val context: Context) {
    fun handleMessageCommand(q: String, contacts: ContactResolver): ToolResult {
        val cleaned = q
            .replace(Regex("(?i)send a message to"), "")
            .replace(Regex("(?i)message"), "")
            .replace(Regex("(?i)to"), " ")
            .trim()

        val parts = cleaned.split(Regex("\\s+(saying|that|:|—|-)\\s+"), limit = 2)
        val name = parts.firstOrNull()?.trim().orEmpty()
        val body = parts.getOrNull(1)?.trim().orEmpty()

        val contact = contacts.resolveName(name)
            ?: return ToolResult(false, "I couldn't resolve the contact $name.")

        if (contact.number.isNullOrBlank()) return ToolResult(false, "That contact has no phone number.")

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:${Uri.encode(contact.number)}")
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ToolResult(true, "Opening the message composer for ${contact.name}.")
    }
}
