package com.starkorbit.jarvis.device

import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import com.starkorbit.jarvis.core.ToolResult

class MediaKeyController(context: Context) {
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    fun dispatch(keyCode: Int): ToolResult = runCatching {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        ToolResult(true, "Media control sent; the active player may ignore it.")
    }.getOrElse { ToolResult(false, "Media control failed.") }
    fun playPause() = dispatch(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    fun next() = dispatch(KeyEvent.KEYCODE_MEDIA_NEXT)
    fun previous() = dispatch(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
}
