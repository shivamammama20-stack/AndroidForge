package com.starkorbit.jarvis.camera

import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import com.starkorbit.jarvis.core.ToolResult

class CameraActions(private val context: Context) {
    fun openCamera(): ToolResult = runCatching {
        context.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ToolResult(true, "Opening the camera.")
    }.getOrElse { ToolResult(false, "No compatible camera app is available.") }
}
