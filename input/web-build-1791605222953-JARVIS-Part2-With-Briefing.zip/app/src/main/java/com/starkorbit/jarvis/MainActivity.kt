package com.starkorbit.jarvis

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.starkorbit.jarvis.core.JarvisBrain
import com.starkorbit.jarvis.core.JarvisMessage
import com.starkorbit.jarvis.ui.JarvisTheme
import com.starkorbit.jarvis.voice.SpeechController
import com.starkorbit.jarvis.voice.TtsController

class MainActivity : ComponentActivity() {
    private lateinit var speech: SpeechController
    private lateinit var tts: TtsController

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speech = SpeechController(this)
        tts = TtsController(this)

        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        )

        setContent {
            JarvisTheme {
                JarvisScreen(
                    onListen = {
                        speech.listen(
                            onResult = { text ->
                                JarvisBrain(this).handle(text) { reply ->
                                    tts.speak(reply)
                                }
                            },
                            onError = { tts.speak(it) }
                        )
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        speech.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(onListen: () -> Unit) {
    var listening by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(JarvisMessage("JARVIS", "Good day, sir. Systems are ready.")) }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("JARVIS", style = MaterialTheme.typography.headlineMedium)
            IconButton(onClick = {}) { Icon(Icons.Default.Settings, "Settings") }
        }

        Spacer(Modifier.height(24.dp))
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 8.dp,
            modifier = Modifier.size(190.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(if (listening) "LISTENING" else "JARVIS", style = MaterialTheme.typography.titleLarge)
            }
        }

        Spacer(Modifier.height(24.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(messages) { msg ->
                Text("${msg.role}: ${msg.text}", Modifier.padding(vertical = 8.dp))
            }
        }

        Button(
            onClick = {
                listening = true
                onListen()
                listening = false
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("TALK TO JARVIS") }
    }
}
