package com.starkorbit.jarvis.voice

import android.service.voice.VoiceInteractionService

class JarvisVoiceInteractionService : VoiceInteractionService()
