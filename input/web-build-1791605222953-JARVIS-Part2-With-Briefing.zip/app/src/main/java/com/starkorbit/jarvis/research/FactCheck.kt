package com.starkorbit.jarvis.research

import com.starkorbit.jarvis.core.ToolResult
import com.starkorbit.jarvis.web.WebResearch

class FactCheck(private val web: WebResearch) {
    fun searchEvidence(claim: String): ToolResult {
        if (claim.isBlank()) return ToolResult(false, "Tell me the claim you want checked.")
        val result = web.search(claim)
        return if (result.success) ToolResult(true, "Evidence search (not a final verdict): ${result.message}") else result
    }
}
