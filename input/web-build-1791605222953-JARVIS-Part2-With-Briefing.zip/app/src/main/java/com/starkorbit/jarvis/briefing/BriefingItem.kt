package com.starkorbit.jarvis.briefing

data class BriefingItem(
    val category: String,
    val headline: String,
    val summary: String,
    val sourceUrl: String = ""
)
