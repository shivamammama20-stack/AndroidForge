package com.starkorbit.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.starkorbit.jarvis.core.ToolResult

class MediaActions(private val context: Context) {
    fun handle(q: String): ToolResult {
        val query = q
            .replace(Regex("(?i)youtube"), "")
            .replace(Regex("(?i)play"), "")
            .trim()

        val uri = Uri.parse(
            if (query.isBlank()) "https://www.youtube.com"
            else "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        )
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ToolResult(true, if (query.isBlank()) "Opening YouTube." else "Searching YouTube for $query.")
    }
}
