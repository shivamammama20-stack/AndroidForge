package com.starkorbit.jarvis.device

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.starkorbit.jarvis.core.ToolResult

class DeviceActions(private val context: Context) {
    fun openWifiSettings() = open(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings")
    fun openBluetoothSettings() = open(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings")
    fun openAppSettings(packageName: String): ToolResult = runCatching {
        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ToolResult(true, "Opening app settings.")
    }.getOrElse { ToolResult(false, "Could not open app settings.") }
    private fun open(action: String, label: String): ToolResult = runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ToolResult(true, "Opening $label.")
    }.getOrElse { ToolResult(false, "Could not open $label.") }
}
