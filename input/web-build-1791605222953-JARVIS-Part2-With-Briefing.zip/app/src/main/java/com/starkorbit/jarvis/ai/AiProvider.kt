package com.starkorbit.jarvis.ai

import android.content.Context
import com.starkorbit.jarvis.core.ToolResult
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-compatible chat completions. Requires a user-configured endpoint, model and API key. */
class AiProvider(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_ai", Context.MODE_PRIVATE)

    fun configure(baseUrl: String, apiKey: String, model: String) {
        prefs.edit().putString("baseUrl", baseUrl.trimEnd('/'))
            .putString("apiKey", apiKey).putString("model", model).apply()
    }

    fun configured(): Boolean = !prefs.getString("baseUrl", "").isNullOrBlank() &&
        !prefs.getString("apiKey", "").isNullOrBlank() && !prefs.getString("model", "").isNullOrBlank()

    fun ask(prompt: String): ToolResult {
        val base = prefs.getString("baseUrl", "") ?: ""
        val key = prefs.getString("apiKey", "") ?: ""
        val model = prefs.getString("model", "") ?: ""
        if (base.isBlank() || key.isBlank() || model.isBlank())
            return ToolResult(false, "AI is not configured. Add a compatible API endpoint, model and key in settings.")
        return try {
            val conn = URL("$base/chat/completions").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 12000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "application/json")
            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", "You are JARVIS, a concise Android assistant. Never claim an action succeeded unless a tool confirms it. Be transparent about uncertainty."))
                .put(JSONObject().put("role", "user").put("content", prompt))
            val payload = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.2)
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) ToolResult(false, "AI provider returned HTTP $code. Check the endpoint, key, model and quota.")
            else {
                val answer = JSONObject(raw).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
                ToolResult(answer.isNotBlank(), answer.ifBlank { "The AI provider returned an empty answer." })
            }
        } catch (e: Exception) {
            ToolResult(false, "AI request failed: ${e.message ?: "network error"}")
        }
    }
}
