package com.starkorbit.jarvis.web

import android.content.Context
import com.starkorbit.jarvis.core.ToolResult
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class WebResearch(private val context: Context) {
    fun search(query: String): ToolResult {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1")
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.requestMethod = "GET"
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = org.json.JSONObject(body)
            val answer = json.optString("AbstractText")
            if (answer.isNotBlank()) ToolResult(true, answer)
            else ToolResult(true, "I found no instant answer. I can open a full web search for $query.")
        } catch (_: Exception) {
            ToolResult(false, "Web search is unavailable right now.")
        }
    }
}
