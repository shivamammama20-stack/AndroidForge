package com.starkorbit.jarvis.contacts

import android.content.Context
import android.provider.ContactsContract
import com.starkorbit.jarvis.core.ContactInfo

class ContactResolver(private val context: Context) {
    fun resolveName(query: String): ContactInfo? {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                if (name.contains(query, true)) {
                    return ContactInfo(c.getLong(0), name, c.getString(2))
                }
            }
        }
        return null
    }
}
