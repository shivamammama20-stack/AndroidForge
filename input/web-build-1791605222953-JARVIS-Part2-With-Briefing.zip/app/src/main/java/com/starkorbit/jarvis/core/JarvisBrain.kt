package com.starkorbit.jarvis.core

import android.content.Context
import com.starkorbit.jarvis.actions.AppActions
import com.starkorbit.jarvis.actions.CallActions
import com.starkorbit.jarvis.actions.MapActions
import com.starkorbit.jarvis.actions.MediaActions
import com.starkorbit.jarvis.actions.MessageActions
import com.starkorbit.jarvis.contacts.ContactResolver
import com.starkorbit.jarvis.memory.MemoryStore
import com.starkorbit.jarvis.web.WebResearch
import com.starkorbit.jarvis.briefing.BriefingService
import com.starkorbit.jarvis.ai.AiProvider

class JarvisBrain(private val context: Context) {

    private val apps = AppActions(context)
    private val calls = CallActions(context)
    private val messages = MessageActions(context)
    private val maps = MapActions(context)
    private val media = MediaActions(context)
    private val contacts = ContactResolver(context)
    private val memory = MemoryStore(context)
    private val web = WebResearch(context)
    private val briefing = BriefingService(context)
    private val ai = AiProvider(context)

    fun handle(input: String, reply: (String) -> Unit) {
        val q = input.trim()
        if (q.isBlank()) return

        memory.addConversation("user", q)

        val lower = q.lowercase()

        val result = when {
            lower == "briefing" || lower.contains("give me a briefing") || lower.contains("morning briefing") || lower.contains("jarvis briefing") -> ToolResult(true, briefing.createBriefing())
            lower.startsWith("open ") || lower.startsWith("launch ") ->
                apps.openByName(q.substringAfter(" ").trim())

            lower.contains("call ") ->
                calls.callContact(contacts.resolveName(q.substringAfter("call ").trim()))

            lower.contains("message ") || lower.contains("send a message") ->
                messages.handleMessageCommand(q, contacts)

            lower.contains("map") || lower.startsWith("navigate") || lower.contains("location") ->
                maps.openSearch(extractDestination(q))

            lower.contains("youtube") || lower.contains("play ") ->
                media.handle(q)

            lower.startsWith("search ") || lower.startsWith("research ") ->
                web.search(q.substringAfter(" ").trim())

            lower.contains("what time") ->
                ToolResult(true, java.text.SimpleDateFormat("hh:mm a").format(java.util.Date()))

            lower.contains("battery") ->
                apps.batteryStatus()

            else -> if (ai.configured()) ai.ask(q) else ToolResult(
                false,
                "I understand the request, but that command needs an AI provider or a dedicated tool. You can configure an AI provider in a future settings screen."
            )
        }

        memory.addConversation("jarvis", result.message)
        reply(result.message)
    }

    private fun extractDestination(q: String): String {
        val lower = q.lowercase()
        val keys = listOf("open", "location", "map", "maps", "navigate", "to")
        var out = q
        keys.forEach { k ->
            out = out.replace(Regex("\\b${Regex.escape(k)}\\b", RegexOption.IGNORE_CASE), " ")
        }
        return out.trim().ifBlank { "current location" }
    }
}
