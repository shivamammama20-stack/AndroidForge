package com.starkorbit.jarvis.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.starkorbit.jarvis.core.ToolResult

class MapActions(private val context: Context) {
    fun openSearch(destination: String): ToolResult {
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            ToolResult(true, "Opening maps for $destination.")
        } catch (_: Exception) {
            val web = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(destination)}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(web)
            ToolResult(true, "Opening a web map for $destination.")
        }
    }
}
