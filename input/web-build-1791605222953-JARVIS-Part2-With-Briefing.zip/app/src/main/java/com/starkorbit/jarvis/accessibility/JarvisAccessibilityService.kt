package com.starkorbit.jarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Screen interaction is implemented only after the user explicitly
        // enables Accessibility access in Android Settings.
        // Never use this service for covert surveillance.
    }

    override fun onInterrupt() {}
}
