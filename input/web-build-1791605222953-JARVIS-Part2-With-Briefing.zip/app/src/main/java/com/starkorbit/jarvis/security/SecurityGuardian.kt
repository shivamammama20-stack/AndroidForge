package com.starkorbit.jarvis.security

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local policy/event log. It does not secretly monitor people or automatically lock other apps. */
class SecurityGuardian(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_security", Context.MODE_PRIVATE)
    fun setProtected(packageName: String, enabled: Boolean) {
        prefs.edit().putBoolean("protected:$packageName", enabled).apply()
        log(if (enabled) "protected-app-enabled" else "protected-app-disabled", packageName)
    }
    fun isProtected(packageName: String) = prefs.getBoolean("protected:$packageName", false)
    fun log(event: String, packageName: String? = null) {
        val arr = JSONArray(prefs.getString("events", "[]"))
        arr.put(JSONObject().put("time", System.currentTimeMillis()).put("event", event).put("package", packageName ?: ""))
        while (arr.length() > 300) arr.remove(0)
        prefs.edit().putString("events", arr.toString()).apply()
    }
    fun events(): JSONArray = JSONArray(prefs.getString("events", "[]"))
}
