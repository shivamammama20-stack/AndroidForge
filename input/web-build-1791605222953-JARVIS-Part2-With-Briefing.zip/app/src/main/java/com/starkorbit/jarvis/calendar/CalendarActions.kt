package com.starkorbit.jarvis.calendar

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import com.starkorbit.jarvis.core.ToolResult

class CalendarActions(private val context: Context) {
    fun createEvent(title: String, begin: Long, end: Long): ToolResult {
        if (end <= begin) return ToolResult(false, "Event end must be after its start.")
        val intent = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent); ToolResult(true, "Calendar editor opened. Review and save the event.") }
            .getOrElse { ToolResult(false, "Could not open the calendar editor.") }
    }
}
