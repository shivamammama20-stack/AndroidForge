package com.starkorbit.jarvis.core

data class JarvisMessage(val role: String, val text: String)

enum class RiskLevel { LOW, MEDIUM, HIGH, CRITICAL }

data class ToolResult(val success: Boolean, val message: String)

data class ContactInfo(
    val id: Long,
    val name: String,
    val number: String?
)

data class InstalledApp(
    val label: String,
    val packageName: String
)
