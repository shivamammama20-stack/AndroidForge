package com.starkorbit.jarvis.security

import com.starkorbit.jarvis.core.RiskLevel

class RiskEngine {
    fun classify(command: String): RiskLevel {
        val q = command.lowercase()
        return when {
            listOf("factory reset", "wipe phone", "delete all", "transfer money", "purchase", "buy now").any(q::contains) -> RiskLevel.CRITICAL
            listOf("send message", "message ", "text ", "call ", "post ", "uninstall", "install").any(q::contains) -> RiskLevel.HIGH
            listOf("open ", "play ", "search ", "maps", "navigate", "battery").any(q::contains) -> RiskLevel.LOW
            else -> RiskLevel.MEDIUM
        }
    }
    fun requiresConfirmation(command: String): Boolean = classify(command) == RiskLevel.HIGH || classify(command) == RiskLevel.CRITICAL
}
