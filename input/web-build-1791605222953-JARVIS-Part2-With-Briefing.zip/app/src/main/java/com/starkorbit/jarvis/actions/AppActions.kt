package com.starkorbit.jarvis.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.starkorbit.jarvis.core.InstalledApp
import com.starkorbit.jarvis.core.ToolResult

class AppActions(private val context: Context) {

    fun listApps(): List<InstalledApp> =
        context.packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .map {
                InstalledApp(
                    context.packageManager.getApplicationLabel(it).toString(),
                    it.packageName
                )
            }
            .sortedBy { it.label.lowercase() }

    fun openByName(name: String): ToolResult {
        val target = listApps().firstOrNull {
            it.label.equals(name, true) ||
            it.label.contains(name, true) ||
            it.packageName.contains(name, true)
        } ?: return ToolResult(false, "I couldn't find $name.")

        val intent = context.packageManager.getLaunchIntentForPackage(target.packageName)
            ?: return ToolResult(false, "${target.label} cannot be launched directly.")

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ToolResult(true, "Opening ${target.label}.")
    }

    fun batteryStatus(): ToolResult {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val level = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return ToolResult(true, "Battery is at $level percent.")
    }
}
