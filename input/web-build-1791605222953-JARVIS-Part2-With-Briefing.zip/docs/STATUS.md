# JARVIS status

## Included in this ZIP
- Native Kotlin + Compose base and central command router
- SpeechRecognizer and Android TTS
- Dynamic installed-app lookup/launch
- Contacts lookup; dialer and SMS composer flows
- Maps search and YouTube search/open
- Notification listener and local notification history
- Basic conversation memory
- OpenAI-compatible chat-completions client (requires endpoint/model/API key)
- AlarmManager reminder scheduler and reminder notification receiver
- Risk classification helper
- Security event log and protected-package policy storage
- Wi-Fi/Bluetooth/app-settings shortcuts
- Media key control helpers
- Calendar editor flow and camera launch helper
- Browser fallback/basic instant-answer search and evidence-search helper

## Must be verified on a real phone
- Gradle build with Android SDK 35 and JDK 17+
- Default-assistant setup and VoiceInteractionService session
- Notification access and background limits on OxygenOS
- Exact alarm scheduling behavior
- Provider endpoint, API key, model and network connectivity

## Not guaranteed / platform limited
- Custom always-listening Jarvis wake word with screen off/locked
- Bypassing lock-screen authentication
- Silent unrestricted WhatsApp/Instagram messages
- Access to private third-party app databases
- Bypassing DRM, paid content, account or regional restrictions

## Still incomplete
- Finished settings screens to configure AI, trust levels and protected apps
- Full natural-language scheduling and editing/canceling tasks
- Production OCR/PDF extraction and document understanding
- Multi-source deep research with ranked citations
- Full confirmation UI and end-to-end action execution policy
- Successful compile/device validation (not performed in this environment)
