# JARVIS Briefing

## Voice command
Say **"Jarvis, briefing"** while JARVIS is active/available through an Android-supported assistant invocation.

## What it currently collects
- Current date and time
- Battery percentage
- Upcoming reminders created through the JARVIS automation helper
- A small number of recent notifications, if Notification Access has been granted
- Fresh headline candidates from the public GDELT news-index API, when network access works

## Freshness and honesty
Each briefing command attempts a new news fetch. If the network/API is unavailable, JARVIS says it could not refresh headlines rather than pretending old data is current. Article titles and source URLs are stored in the spoken briefing text, but a full source-verification/ranking engine is not included yet.

## About "update itself"
This feature refreshes briefing information when requested. It does **not** rewrite, download, or install new application code by itself. Self-modifying app code would be unsafe and is not a normal Android update mechanism. Future app versions should be delivered through a signed APK/update flow that the user can review and approve.
