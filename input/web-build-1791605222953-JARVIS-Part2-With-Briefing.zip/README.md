# JARVIS — Part 1

This is the first implementation part of the Android JARVIS project.

## Included

- Native Kotlin Android app
- Jetpack Compose UI
- SpeechRecognizer voice input
- Android TextToSpeech
- VoiceInteractionService integration point
- NotificationListenerService
- AccessibilityService integration point
- Installed-app discovery and launch
- Contacts lookup
- Dialer launch
- SMS composer flow
- Worldwide map search through Android map intents/web fallback
- YouTube search/open
- Battery status
- Conversation/notification memory
- Basic web instant-answer search
- Central JarvisBrain command router

## Important Android limits

A third-party app cannot legitimately guarantee a custom always-listening wake word while the phone is locked/screen-off. Android and OxygenOS control background microphone access and keyguard behavior.

This project therefore uses the official VoiceInteractionService route. Actions that Android requires to be confirmed or unlocked must remain so.

WhatsApp/Instagram and other private app data cannot be accessed through private APIs. Public intents and explicitly authorized AccessibilityService flows are the supported routes.

## Build

Open this project in an Android build environment with Android SDK 35 and JDK 17+.

Then:

    ./gradlew assembleDebug

Install:

    app/build/outputs/apk/debug/app-debug.apk

## Part 2

Part 2 will extend this project with the remaining advanced systems:
automation engine, scheduled/conditional tasks, AI provider abstraction, research/fact-check pipeline, camera/document processing, security guardian, protected-app policy layer, proactive notifications/voice, richer settings and permission center, action-risk engine, validation, and additional device/media integrations.


## Part 2 modules

Additional source modules include an OpenAI-compatible AI client, scheduled reminder notifications, a risk-classification helper, a local Security Guardian event log and protected-package preferences, device settings shortcuts, media key controls, calendar editor flow, camera launch, evidence-search helper, and notification-history reader.

Some additions are service/helper layers rather than finished end-to-end screens. See `FEATURES.md` and `docs/STATUS.md`. This source has **not** been compiled or tested on a physical OnePlus device here; do not assume a successful build until your cloud builder reports it.

## Put the project in GitHub

1. Download and extract this ZIP.
2. Create a GitHub repository named `JARVIS`.
3. Upload the **contents of the extracted folder**, not the ZIP file and not an extra nested directory.
4. At the repository root you should see `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, `docs/`, `README.md`, and `FEATURES.md`.
5. Connect that repository to AndroidForge or your Android cloud builder and run its build workflow.
6. Download the resulting APK artifact only after the workflow succeeds.
7. Never commit API keys, tokens, passwords, or signing keys.


## Briefing command

The command router now recognizes "briefing", "Jarvis briefing", "give me a briefing", and "morning briefing". It composes a fresh briefing from the current date/time, battery status, saved reminders, recent notifications (if permission is granted), and current headline candidates from GDELT when online.

The briefing refreshes its information on request; it does not rewrite or silently install new app code. A real app update should be signed and user-approved.
