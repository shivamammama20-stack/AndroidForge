package com.max.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF05080D)
private val Cyan = Color(0xFF29D9FF)
private val Blue = Color(0xFF1976FF)
private val Dim = Color(0xFF7890A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaxApp() }
    }
}

@Composable
fun MaxApp() {
    var status by remember { mutableStateOf("AWAITING COMMAND") }
    var log by remember { mutableStateOf(listOf("MAX CORE INITIALIZED", "SECURITY: READY")) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Color(0xFF0A111A),
            primary = Cyan
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF08111A), Bg, Color(0xFF020407))
                    )
                )
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("MAX", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("PERSONAL AI ASSISTANT", color = Dim, fontSize = 11.sp)
                    }
                    Surface(
                        color = Color(0xFF0C1B25),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            "● CORE ACTIVE",
                            color = Cyan,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(Modifier.weight(0.8f))

                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CoreOrb()
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    status,
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(Modifier.height(16.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xAA08121C),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF173044))
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("ACTIVITY LOG", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        log.takeLast(4).forEach {
                            Text("› $it", color = Dim, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickButton("LISTEN", Modifier.weight(1f)) {
                        status = "LISTENING"
                        log = log + "VOICE INPUT READY"
                    }
                    QuickButton("ANALYZE", Modifier.weight(1f)) {
                        status = "ANALYZING"
                        log = log + "REQUEST ANALYSIS STARTED"
                    }
                    QuickButton("RESET", Modifier.weight(1f)) {
                        status = "AWAITING COMMAND"
                        log = log + "CORE RESET"
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "VOICE • AI • TOOLS • SECURITY",
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF52697D),
                    fontSize = 9.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun CoreOrb() {
    val transition = rememberInfiniteTransition(label = "core")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "pulse"
    )
    Canvas(
        modifier = Modifier
            .size(260.dp)
            .scale(pulse)
    ) {
        val c = center
        val maxR = size.minDimension / 2f

        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFF66E8FF), Color(0xFF167DFF), Color.Transparent)
            ),
            radius = maxR * 0.30f,
            center = c
        )

        listOf(0.40f, 0.52f, 0.64f, 0.76f, 0.88f).forEachIndexed { i, factor ->
            drawCircle(
                color = if (i % 2 == 0) Cyan.copy(alpha = 0.45f) else Blue.copy(alpha = 0.32f),
                radius = maxR * factor,
                center = c,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = if (i == 2) 3f else 1.5f
                )
            )
        }

        for (i in 0 until 48) {
            val angle = Math.toRadians(i * 7.5)
            val r1 = maxR * 0.94f
            val r2 = if (i % 3 == 0) maxR * 1.0f else maxR * 0.97f
            val x1 = c.x + kotlin.math.cos(angle).toFloat() * r1
            val y1 = c.y + kotlin.math.sin(angle).toFloat() * r1
            val x2 = c.x + kotlin.math.cos(angle).toFloat() * r2
            val y2 = c.y + kotlin.math.sin(angle).toFloat() * r2
            drawLine(Cyan.copy(alpha = 0.55f), androidx.compose.ui.geometry.Offset(x1,y1),
                androidx.compose.ui.geometry.Offset(x2,y2), 2f, StrokeCap.Round)
        }
    }
}

@Composable
private fun QuickButton(text: String, modifier: Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(42.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF0B1823),
            contentColor = Cyan
        )
    ) {
        Text(text, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
