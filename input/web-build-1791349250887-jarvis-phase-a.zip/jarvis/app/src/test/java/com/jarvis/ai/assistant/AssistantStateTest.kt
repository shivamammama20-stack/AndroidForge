package com.jarvis.ai.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantStateTest {
    @Test fun idleCanStartListening() = assertTrue(AssistantState.IDLE.canTransitionTo(AssistantState.LISTENING))
    @Test fun cannotListenWhileListening() = assertFalse(AssistantState.LISTENING.canTransitionTo(AssistantState.LISTENING))
    @Test fun errorAndIdleAlwaysReachable() {
        AssistantState.entries.forEach {
            assertTrue(it.canTransitionTo(AssistantState.ERROR))
            assertTrue(it.canTransitionTo(AssistantState.IDLE))
        }
    }
    @Test fun searchingRequiresProcessing() {
        assertFalse(AssistantState.IDLE.canTransitionTo(AssistantState.SEARCHING))
        assertTrue(AssistantState.PROCESSING.canTransitionTo(AssistantState.SEARCHING))
    }
    @Test fun busyStates() {
        assertTrue(AssistantState.SPEAKING.isBusy)
        assertFalse(AssistantState.IDLE.isBusy)
    }
}
