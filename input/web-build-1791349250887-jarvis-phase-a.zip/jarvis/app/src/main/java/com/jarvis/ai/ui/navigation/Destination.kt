package com.jarvis.ai.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoMode
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.ui.graphics.vector.ImageVector

enum class Destination(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Outlined.Home),
    CONVERSATION("conversation", "Chat", Icons.Outlined.Forum),
    MEMORY("memory", "Memory", Icons.Outlined.Memory),
    SECURITY("security", "Security", Icons.Outlined.Shield),
    AUTOMATION("automation", "Auto", Icons.Outlined.AutoMode),
    SETTINGS("settings", "Settings", Icons.Outlined.Settings);

    companion object {
        fun fromRoute(route: String?): Destination = entries.firstOrNull { it.route == route } ?: HOME
    }
}
