package com.jarvis.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val JarvisColors = darkColorScheme(
    primary = JarvisCyan,
    secondary = JarvisBlue,
    tertiary = JarvisViolet,
    background = Void,
    surface = Panel,
    surfaceVariant = PanelHigh,
    onPrimary = Void,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextMuted,
    error = JarvisRed,
)

/** JARVIS is intentionally dark-only: it is a command-center aesthetic. */
@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = JarvisColors, typography = JarvisTypography, content = content)
}
