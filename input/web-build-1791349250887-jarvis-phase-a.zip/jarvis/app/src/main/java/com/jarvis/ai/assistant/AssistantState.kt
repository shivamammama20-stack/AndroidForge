package com.jarvis.ai.assistant

/** High-level state of the assistant; drives the orb and status text in the UI. */
enum class AssistantState(val label: String) {
    IDLE("Standing by"),
    LISTENING("Listening"),
    PROCESSING("Thinking"),
    SEARCHING("Searching"),
    EXECUTING("Executing"),
    SPEAKING("Speaking"),
    SECURITY("Security check"),
    ERROR("Something went wrong");

    /** True while the assistant is busy and should not accept a new command without interrupting. */
    val isBusy: Boolean
        get() = this == PROCESSING || this == SEARCHING || this == EXECUTING || this == SPEAKING

    /** Whether moving from this state to [next] is a valid transition. ERROR/IDLE/SECURITY are always reachable. */
    fun canTransitionTo(next: AssistantState): Boolean = when (next) {
        IDLE, ERROR, SECURITY -> true
        LISTENING -> this != LISTENING
        PROCESSING -> this == IDLE || this == LISTENING || this == SECURITY
        SEARCHING, EXECUTING -> this == PROCESSING || this == SEARCHING || this == EXECUTING || this == SECURITY
        SPEAKING -> this != SPEAKING
    }
}
