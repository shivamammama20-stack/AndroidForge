package com.jarvis.ai.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisCyan = Color(0xFF4FD8FF)
val JarvisBlue = Color(0xFF2B7BFF)
val JarvisAmber = Color(0xFFFFB347)
val JarvisRed = Color(0xFFFF5470)
val JarvisGreen = Color(0xFF3DDC97)
val JarvisViolet = Color(0xFF9A7BFF)
val Void = Color(0xFF05080F)
val Panel = Color(0xFF0D1522)
val PanelHigh = Color(0xFF16233A)
val TextPrimary = Color(0xFFE6F1FF)
val TextMuted = Color(0xFF8CA3C4)
