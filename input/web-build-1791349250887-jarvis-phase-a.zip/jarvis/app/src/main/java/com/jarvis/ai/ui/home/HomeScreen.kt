package com.jarvis.ai.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.ai.assistant.AssistantState
import com.jarvis.ai.ui.theme.JarvisAmber
import com.jarvis.ai.ui.theme.JarvisBlue
import com.jarvis.ai.ui.theme.JarvisCyan
import com.jarvis.ai.ui.theme.JarvisRed
import com.jarvis.ai.ui.theme.JarvisViolet

fun AssistantState.orbColor(): Color = when (this) {
    AssistantState.IDLE -> JarvisBlue
    AssistantState.LISTENING -> JarvisCyan
    AssistantState.PROCESSING, AssistantState.SEARCHING -> JarvisViolet
    AssistantState.EXECUTING, AssistantState.SPEAKING -> JarvisCyan
    AssistantState.SECURITY -> JarvisAmber
    AssistantState.ERROR -> JarvisRed
}

/** Phase A home: static orb bound to [AssistantState]. Animation and engine wiring arrive in Phases B and G. */
@Composable
fun HomeScreen(state: AssistantState = AssistantState.IDLE) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        val c = state.orbColor()
        Canvas(Modifier.size(220.dp)) {
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.9f), c.copy(alpha = 0.25f), Color.Transparent)))
            drawCircle(c, radius = size.minDimension / 4f, alpha = 0.8f)
        }
        Text("JARVIS", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onBackground)
        Text(state.label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
