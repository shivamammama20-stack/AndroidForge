package com.jarvis.ai.core

import android.util.Log

/** Thin logging facade. Verbose/debug output is suppressed in release builds and never logs secrets. */
object JarvisLog {
    private const val TAG = "JARVIS"
    @Volatile private var debug = false

    fun init(debug: Boolean) { this.debug = debug }

    fun d(scope: String, msg: String) { if (debug) Log.d(TAG, "[$scope] $msg") }
    fun i(scope: String, msg: String) { Log.i(TAG, "[$scope] $msg") }
    fun w(scope: String, msg: String, t: Throwable? = null) { Log.w(TAG, "[$scope] $msg", t) }
    fun e(scope: String, msg: String, t: Throwable? = null) { Log.e(TAG, "[$scope] $msg", t) }
}
