package com.jarvis.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jarvis.ai.ui.common.SectionScreen
import com.jarvis.ai.ui.home.HomeScreen
import com.jarvis.ai.ui.navigation.Destination

@Composable
fun JarvisApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = Destination.fromRoute(entry?.destination?.route)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Destination.entries.forEach { d ->
                    NavigationBarItem(
                        selected = d == current,
                        onClick = {
                            nav.navigate(d.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(d.icon, contentDescription = d.label) },
                        label = { Text(d.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Destination.HOME.route, modifier = Modifier.padding(padding)) {
            composable(Destination.HOME.route) { HomeScreen() }
            composable(Destination.CONVERSATION.route) { SectionScreen("Conversation", "Conversation history lands in Phase B once the assistant engine is wired.") }
            composable(Destination.MEMORY.route) { SectionScreen("Memory", "User-controlled memory lands in Phase B (foundation) and Phase F (advanced).") }
            composable(Destination.SECURITY.route) { SectionScreen("Security", "Security Guardian dashboard lands in Phase D.") }
            composable(Destination.AUTOMATION.route) { SectionScreen("Automation", "Routines and triggers land in Phase F.") }
            composable(Destination.SETTINGS.route) { SectionScreen("Settings", "Provider, voice, privacy and permission settings land across Phases B-G.") }
        }
    }
}
