package com.jarvis.ai

import android.app.Application
import com.jarvis.ai.core.JarvisLog

class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        JarvisLog.init(debug = BuildConfig.DEBUG)
        JarvisLog.i("App", "JARVIS ${BuildConfig.VERSION_NAME} started")
    }
}
