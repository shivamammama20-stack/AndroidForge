# JARVIS (Phase B)
Native Android assistant. Phase B: Brain pipeline, OpenAI-compatible provider (Groq default), Keystore-backed API key,
tools (openApp, getBattery, setAlarm), SpeechRecognizer + Android TTS, orb UI, unit tests.
Open the folder in Android Studio (Koala+ / JDK 17), let Gradle sync, run on a device. Add your API key under Settings.
Built/tested status: NOT compiled or run in the authoring environment.
