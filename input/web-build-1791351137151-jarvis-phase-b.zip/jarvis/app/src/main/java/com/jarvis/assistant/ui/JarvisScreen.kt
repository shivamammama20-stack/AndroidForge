package com.jarvis.assistant.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.core.common.JarvisState
import com.jarvis.assistant.core.permissions.AppPermission
import com.jarvis.assistant.feature.assistant.ConversationEntry
import com.jarvis.assistant.feature.assistant.JarvisViewModel
import com.jarvis.assistant.feature.assistant.UiEvent
import com.jarvis.assistant.feature.dashboard.JarvisOrb

private val Bg = Color(0xFF05080F)
private val Cyan = Color(0xFF29D3FF)
private val Muted = Color(0xFF8FA3B8)

@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var rationale by remember { mutableStateOf<AppPermission?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.onPermissionResult(AppPermission.RECORD_AUDIO, it)
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.onPermissionResult(AppPermission.POST_NOTIFICATIONS, it)
    }

    LaunchedEffect(Unit) {
        vm.events.collect { e -> if (e is UiEvent.RequestPermission) rationale = e.permission }
    }
    LaunchedEffect(ui.conversation.size) {
        if (ui.conversation.isNotEmpty()) listState.animateScrollToItem(ui.conversation.size - 1)
    }

    rationale?.let { p ->
        AlertDialog(
            onDismissRequest = { rationale = null },
            title = { Text("Permission needed") },
            text = { Text(p.rationale) },
            confirmButton = {
                TextButton(onClick = {
                    rationale = null
                    when (p) {
                        AppPermission.RECORD_AUDIO -> micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        AppPermission.POST_NOTIFICATIONS ->
                            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        AppPermission.EXACT_ALARM ->
                            if (Build.VERSION.SDK_INT >= 31) context.startActivity(
                                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}"))
                            )
                    }
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { rationale = null }) { Text("Not now") } }
        )
    }

    if (showSettings) {
        SettingsDialog(
            baseUrl = ui.baseUrl, model = ui.model, hasKey = ui.hasApiKey,
            onSave = { url, model, key -> vm.saveAiConfig(url, model, key) },
            onClearKey = vm::clearApiKey,
            onDismiss = { showSettings = false }
        )
    }

    val submit = { if (input.isNotBlank()) { vm.onTextSubmitted(input); input = "" } }

    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("JARVIS", color = Cyan, style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = { showSettings = true }) { Text("Settings") }
        }
        JarvisOrb(ui.state, level = ui.level)
        Text(ui.status, color = Muted, modifier = Modifier.padding(top = 8.dp))
        if (!ui.aiConfigured) {
            Text(
                "AI provider not configured. Battery, apps and alarms work without it; add an API key in Settings for everything else.",
                color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)
            )
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp),
            state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ui.conversation, key = { it.id }) { Bubble(it) }
            if (ui.partialTranscript.isNotBlank()) {
                item { Text(ui.partialTranscript, color = Muted, fontStyle = FontStyle.Italic) }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type a command") }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { submit() }, enabled = input.isNotBlank()) { Text("Send") }
            Spacer(Modifier.width(8.dp))
            val listening = ui.state == JarvisState.LISTENING
            FilledIconButton(
                onClick = vm::onMicClicked, enabled = ui.micAvailable,
                modifier = Modifier.semantics { contentDescription = if (listening) "Stop listening" else "Start voice command" }
            ) { Text(if (listening) "■" else "🎤") }
        }
    }
}

@Composable
private fun Bubble(e: ConversationEntry) {
    Column(Modifier.fillMaxWidth()) {
        Text(if (e.fromUser) "You" else "JARVIS", color = if (e.fromUser) Muted else Cyan, style = MaterialTheme.typography.labelSmall)
        Text(e.text, color = Color.White)
    }
}

@Composable
private fun SettingsDialog(
    baseUrl: String, model: String, hasKey: Boolean,
    onSave: (String, String, String) -> String?, onClearKey: () -> Unit, onDismiss: () -> Unit
) {
    var url by remember { mutableStateOf(baseUrl) }
    var mdl by remember { mutableStateOf(model) }
    var key by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AI provider") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(url, { url = it }, label = { Text("Base URL (OpenAI-compatible)") }, singleLine = true)
                OutlinedTextField(mdl, { mdl = it }, label = { Text("Model") }, singleLine = true)
                OutlinedTextField(
                    key, { key = it }, label = { Text(if (hasKey) "API key (saved, leave blank to keep)" else "API key") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation()
                )
                error?.let { Text(it, color = Color(0xFFFF5252)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = onSave(url, mdl, key)
                if (error == null) onDismiss()
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (hasKey) TextButton(onClick = { onClearKey(); onDismiss() }) { Text("Remove key") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
