package com.jarvis.assistant.core.ai
data class ChatMessage(val role: String, val content: String)
data class ToolCall(val name: String, val args: Map<String, String>)
data class AIReply(val text: String?, val toolCall: ToolCall?)
interface AIProvider {
    suspend fun complete(messages: List<ChatMessage>, tools: List<Tool>): AIReply
}
