package com.jarvis.assistant.feature.automation

import android.content.Context

/** Persists pending alarm trigger times so they can be re-registered after a reboot. */
class AlarmStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_alarms", Context.MODE_PRIVATE)

    fun all(): Set<Long> = prefs.getStringSet(KEY, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
    fun add(trigger: Long) = save(all() + trigger)
    fun remove(trigger: Long) = save(all() - trigger)
    private fun save(s: Set<Long>) { prefs.edit().putStringSet(KEY, s.map { it.toString() }.toSet()).apply() }

    private companion object { const val KEY = "triggers" }
}
