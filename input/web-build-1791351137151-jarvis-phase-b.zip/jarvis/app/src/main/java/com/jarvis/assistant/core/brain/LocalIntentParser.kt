package com.jarvis.assistant.core.brain

import com.jarvis.assistant.core.ai.ToolCall

/** Fast, offline intent understanding for the built-in tools. Anything else goes to the AI provider. */
class LocalIntentParser {
    fun parse(raw: String): ToolCall? {
        val t = normalize(raw)
        if (t.isEmpty()) return null
        if (ALARM.containsMatchIn(t)) {
            return if (ALARM_NEGATIVE.containsMatchIn(t)) null else ToolCall("setAlarm", mapOf("time" to t))
        }
        if (BATTERY.containsMatchIn(t)) return ToolCall("getBattery", emptyMap())
        OPEN.matchEntire(t)?.let { m ->
            val name = m.groupValues[1].trim().removePrefix("the ").replace(APP_SUFFIX, "").trim()
            if (name.isNotEmpty()) return ToolCall("openApp", mapOf("app" to name))
        }
        return null
    }

    companion object {
        private val WAKE = Regex("^(?:(?:hey|ok|okay)\\s+)?jarvis\\b[\\s,:.!-]*")
        private val ALARM = Regex("\\b(alarm|wake me)\\b")
        private val ALARM_NEGATIVE = Regex("\\b(cancel|delete|remove|turn off|disable|stop)\\b")
        private val BATTERY = Regex("\\b(battery|charging|charger)\\b")
        private val OPEN = Regex("^(?:(?:can|could|would) you )?(?:open|launch)(?: up)?\\s+(.+)$")
        private val APP_SUFFIX = Regex("\\s+(app|application)$")

        fun normalize(raw: String): String = raw.lowercase().trim()
            .replace(WAKE, "")
            .replace(Regex("\\bplease\\b"), " ")
            .trim().trimEnd('.', '?', '!', ',')
            .replace(Regex("\\s+"), " ").trim()
    }
}
