package com.jarvis.assistant.feature.apps

data class AppInfo(val label: String, val packageName: String)

sealed interface AppMatch {
    data class Found(val app: AppInfo) : AppMatch
    data class Ambiguous(val options: List<AppInfo>) : AppMatch
    object NotFound : AppMatch
}

/** Resolves a spoken/typed app name against whatever is actually installed. No package names are hardcoded. */
object AppResolver {
    fun resolve(query: String, apps: List<AppInfo>): AppMatch {
        val q = key(query)
        if (q.isEmpty()) return AppMatch.NotFound
        val scored = apps.mapNotNull { app -> score(q, key(app.label))?.let { app to it } }
        if (scored.isEmpty()) return AppMatch.NotFound
        val best = scored.maxOf { it.second }
        val top = scored.filter { it.second == best }.map { it.first }.distinctBy { it.packageName }
        return if (top.size == 1) AppMatch.Found(top[0]) else AppMatch.Ambiguous(top.sortedBy { it.label })
    }

    internal fun key(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun score(q: String, l: String): Int? {
        if (l.isEmpty()) return null
        return when {
            q == l -> 100
            l.startsWith(q) -> 80
            q.length >= 3 && l.contains(q) -> 60
            l.length >= 4 && q.contains(l) -> 50
            q.length >= 4 && l.length >= 4 -> {
                val sim = 1.0 - levenshtein(q, l).toDouble() / maxOf(q.length, l.length)
                if (sim >= 0.75) (sim * 40).toInt() else null
            }
            else -> null
        }
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }
}
