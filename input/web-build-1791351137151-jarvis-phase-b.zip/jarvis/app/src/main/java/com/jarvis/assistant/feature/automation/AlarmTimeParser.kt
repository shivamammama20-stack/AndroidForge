package com.jarvis.assistant.feature.automation

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

data class ParsedAlarm(val dateTime: ZonedDateTime, val meridiemAssumed: Boolean)

/**
 * Extracts an alarm time from natural wording ("6 AM", "tomorrow at 7:30", "wake me at 6", "18:30").
 * Digits only (speech recognizers normally return digits). With no AM/PM the earliest upcoming of the two
 * candidates is chosen and [ParsedAlarm.meridiemAssumed] is set so the reply can say so.
 */
object AlarmTimeParser {
    private val MERIDIEM_FIX = Regex("(?<=\\d)\\s*([ap])\\.?\\s?m\\b\\.?")
    private val WITH_COLON = Regex("\\b(\\d{1,2}):(\\d{2})\\s*(am|pm)?")
    private val WITH_MERIDIEM = Regex("\\b(\\d{1,2})\\s*(am|pm)\\b")
    private val BARE = Regex("\\b(?:at|for|to)\\s+(\\d{1,2})\\b(?!:)")
    private val AM_HINT = Regex("\\bmorning\\b")
    private val PM_HINT = Regex("\\b(afternoon|evening|tonight|night)\\b")
    private val TODAY = Regex("\\b(today|tonight)\\b")

    fun parse(input: String, now: ZonedDateTime): ParsedAlarm? {
        val t = MERIDIEM_FIX.replace(input.lowercase(Locale.ROOT), "\$1m")
        var hourText: String
        var minute = 0
        var mer: String? = null
        val c = WITH_COLON.find(t)
        val m = WITH_MERIDIEM.find(t)
        val b = BARE.find(t)
        when {
            c != null -> { hourText = c.groupValues[1]; minute = c.groupValues[2].toInt(); mer = c.groupValues[3].ifEmpty { null } }
            m != null -> { hourText = m.groupValues[1]; mer = m.groupValues[2] }
            b != null -> hourText = b.groupValues[1]
            else -> return null
        }
        val hour = hourText.toIntOrNull() ?: return null
        if (minute !in 0..59) return null
        if (mer != null && hour !in 1..12) return null

        val hinted: String? = mer ?: when {
            AM_HINT.containsMatchIn(t) -> "am"
            PM_HINT.containsMatchIn(t) -> "pm"
            else -> null
        }
        val hours24: List<Int> = when {
            hinted != null && hour in 1..12 -> listOf(if (hinted == "am") hour % 12 else hour % 12 + 12)
            hour in 13..23 || hour == 0 || (hourText.length == 2 && hourText[0] == '0' && hour in 1..12) -> listOf(hour)
            hour in 1..12 -> listOf(hour % 12, hour % 12 + 12)
            else -> return null
        }

        val offset: Long? = when {
            "day after tomorrow" in t -> 2L
            "tomorrow" in t -> 1L
            TODAY.containsMatchIn(t) -> 0L
            else -> null
        }
        val day = now.toLocalDate().plusDays(offset ?: 0L)
        val candidates = hours24.mapNotNull { h ->
            val dt = day.atTime(h, minute).atZone(now.zone)
            when {
                dt.isAfter(now) -> dt
                offset == null -> dt.plusDays(1)
                else -> null // explicit day, already past
            }
        }
        val chosen = candidates.minByOrNull { it.toInstant() } ?: return null
        return ParsedAlarm(chosen, meridiemAssumed = hours24.size > 1)
    }

    fun describe(dt: ZonedDateTime, now: ZonedDateTime): String {
        val time = dt.format(DateTimeFormatter.ofPattern(if (dt.minute == 0) "h a" else "h:mm a", Locale.US))
        val dayPart = when (ChronoUnit.DAYS.between(now.toLocalDate(), dt.toLocalDate())) {
            0L -> "today"
            1L -> "tomorrow"
            else -> "on " + dt.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.US))
        }
        return "$time $dayPart"
    }
}
