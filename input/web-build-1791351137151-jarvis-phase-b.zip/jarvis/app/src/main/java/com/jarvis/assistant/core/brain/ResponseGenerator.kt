package com.jarvis.assistant.core.brain

import com.jarvis.assistant.core.ai.AiException
import com.jarvis.assistant.core.ai.FailureCode
import com.jarvis.assistant.core.ai.ToolResult
import com.jarvis.assistant.core.permissions.AppPermission
import kotlin.random.Random

/** Builds user-facing text. Success wording is only ever produced from a ToolResult with success == true. */
class ResponseGenerator(private val random: Random = Random.Default) {
    private val acks = listOf("Certainly, sir.", "Right away, sir.", "Of course, sir.", "On it, sir.", "Very well, sir.")
    private var lastAck = -1

    fun ack(): String {
        var i = random.nextInt(acks.size)
        while (i == lastAck) i = random.nextInt(acks.size)
        lastAck = i
        return acks[i]
    }

    fun forSuccess(tool: String, r: ToolResult): String = when (tool) {
        "openApp" -> "${ack()} Opening ${r.target}."
        "getBattery" -> battery(r)
        "setAlarm" -> "Done, sir. Your alarm is set for ${r.data["display"]}." +
            if (r.data["meridiemAssumed"] == "true") " I assumed that time; say AM or PM if you meant the other." else ""
        else -> "Done, sir."
    }

    private fun battery(r: ToolResult): String {
        val base = "Your battery is at ${r.data["percent"]} percent, sir"
        return base + when (r.data["state"]) {
            "CHARGING" -> ", and it's charging."
            "FULL" -> ", and it's fully charged."
            "DISCHARGING", "NOT_CHARGING" -> ", and it isn't charging."
            else -> "."
        }
    }

    fun forFailure(tool: String, r: ToolResult): String = when (r.failureCode) {
        FailureCode.NOT_FOUND ->
            if (tool == "openApp") "That application doesn't appear to be installed, sir." else "I couldn't find that, sir."
        FailureCode.AMBIGUOUS -> "I found several matches: ${r.data["options"]}. Which one did you mean, sir?"
        FailureCode.LAUNCH_FAILED -> "I couldn't open that application, sir."
        FailureCode.INVALID_ARGUMENTS -> r.failureReason ?: "I didn't quite catch the details, sir."
        FailureCode.UNAVAILABLE -> r.failureReason ?: "That isn't available right now, sir."
        else -> "I couldn't complete that action, sir."
    }

    fun forPermission(p: AppPermission?): String = p?.denialMessage ?: "I need an additional permission to do that, sir."

    fun forAiError(e: AiException): String = when (e) {
        is AiException.MissingKey -> missingApiKey()
        is AiException.InvalidKey -> "The AI provider rejected the API key, sir. Please check it in Settings."
        is AiException.RateLimited -> "The AI service is rate limiting me, sir. Please try again in a moment."
        is AiException.Timeout -> "The AI service took too long to respond, sir."
        is AiException.Network -> "I'm unable to reach the AI service right now, sir."
        is AiException.Server -> "The AI service is having trouble right now, sir."
        is AiException.BadRequest -> "The AI service couldn't accept that request, sir. Please check the model name in Settings."
        is AiException.Malformed -> "I received a response from the AI service that I couldn't understand, sir."
    }

    fun missingApiKey() = "I need an AI provider API key before I can process that request."
    fun unknown() = "I'm not quite sure what you'd like me to do, sir."
    fun genericFailure() = "I couldn't complete that action, sir."
    fun cancelled() = "Understood, sir. I've cancelled that."
    fun confirmationPrompt(description: String, strict: Boolean) =
        if (strict) "This is a critical action: $description. To proceed, please say 'confirm', sir."
        else "I'd like to confirm: $description. Shall I proceed, sir?"
    fun strictReminder(description: String) = "That action is critical: $description. I need you to say 'confirm' exactly, sir, or say no to cancel."
}
