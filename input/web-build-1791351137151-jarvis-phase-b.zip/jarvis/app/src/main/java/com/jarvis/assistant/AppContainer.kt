package com.jarvis.assistant

import android.app.Application
import android.content.Context
import com.jarvis.assistant.core.ai.OpenAiCompatibleProvider
import com.jarvis.assistant.core.ai.ToolRegistry
import com.jarvis.assistant.core.brain.JarvisBrain
import com.jarvis.assistant.core.config.AiConfigRepository
import com.jarvis.assistant.core.config.KeystoreSecretStore
import com.jarvis.assistant.core.permissions.AndroidPermissionChecker
import com.jarvis.assistant.core.permissions.PermissionChecker
import com.jarvis.assistant.feature.apps.OpenAppTool
import com.jarvis.assistant.feature.apps.PackageManagerAppRepository
import com.jarvis.assistant.feature.automation.AlarmStore
import com.jarvis.assistant.feature.automation.AndroidAlarmScheduler
import com.jarvis.assistant.feature.automation.SetAlarmTool
import com.jarvis.assistant.feature.device.AndroidBatteryInfoProvider
import com.jarvis.assistant.feature.device.BatteryTool

/** Manual dependency graph (no DI framework needed yet). Created once by [JarvisApp]. */
class AppContainer(val appContext: Context) {
    val permissions: PermissionChecker = AndroidPermissionChecker(appContext)
    val aiConfig = AiConfigRepository(appContext, KeystoreSecretStore(appContext))

    val registry = ToolRegistry().apply {
        register(OpenAppTool(PackageManagerAppRepository(appContext)))
        register(BatteryTool(AndroidBatteryInfoProvider(appContext)))
        register(SetAlarmTool(AndroidAlarmScheduler(appContext, AlarmStore(appContext)), permissions))
    }

    val brain = JarvisBrain(
        registry = registry,
        providerSupplier = { aiConfig.config.value.takeIf { it.isUsable }?.let { OpenAiCompatibleProvider(it) } }
    )
}

class JarvisApp : Application() {
    val container: AppContainer by lazy { AppContainer(applicationContext) }
}
