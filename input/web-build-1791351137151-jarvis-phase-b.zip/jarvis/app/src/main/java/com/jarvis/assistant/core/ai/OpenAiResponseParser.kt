package com.jarvis.assistant.core.ai

import org.json.JSONException
import org.json.JSONObject

object OpenAiResponseParser {
    fun parse(body: String): AIReply {
        val root = try { JSONObject(body) } catch (e: JSONException) { throw AiException.Malformed() }
        val message = root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?: throw AiException.Malformed()
        val content = if (message.isNull("content")) null else message.optString("content").trim().ifEmpty { null }
        val fn = message.optJSONArray("tool_calls")?.optJSONObject(0)?.optJSONObject("function")
        val toolCall = fn?.let {
            val name = it.optString("name").trim()
            if (name.isEmpty()) throw AiException.Malformed()
            ToolCall(name, parseArgs(it.opt("arguments")))
        }
        return AIReply(content, toolCall)
    }

    private fun parseArgs(raw: Any?): Map<String, String> {
        val obj: JSONObject = when (raw) {
            null, JSONObject.NULL -> return emptyMap()
            is JSONObject -> raw
            is String -> if (raw.isBlank()) return emptyMap() else try { JSONObject(raw) } catch (e: JSONException) { throw AiException.Malformed() }
            else -> throw AiException.Malformed()
        }
        val out = linkedMapOf<String, String>()
        obj.keys().forEach { k -> if (!obj.isNull(k)) out[k] = obj.get(k).toString() }
        return out
    }
}
