package com.jarvis.assistant.core.config

data class AiConfig(
    val baseUrl: String = DEFAULT_BASE_URL,
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL
) {
    val isUsable: Boolean get() = apiKey.isNotBlank() && baseUrl.startsWith("https://") && model.isNotBlank()

    /** Never print the key. */
    override fun toString() = "AiConfig(baseUrl=$baseUrl, model=$model, apiKey=<redacted>)"

    companion object {
        const val DEFAULT_BASE_URL = "https://api.groq.com/openai/v1"
        const val DEFAULT_MODEL = "llama-3.3-70b-versatile"
    }
}
