package com.jarvis.assistant.core.ai

import org.json.JSONArray
import org.json.JSONObject

object OpenAiRequestBuilder {
    fun build(model: String, messages: List<ChatMessage>, tools: List<Tool>): String {
        val root = JSONObject()
        root.put("model", model)
        root.put("temperature", 0.2)
        val msgs = JSONArray()
        messages.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        root.put("messages", msgs)
        if (tools.isNotEmpty()) {
            val arr = JSONArray()
            tools.forEach { arr.put(toolJson(it)) }
            root.put("tools", arr)
            root.put("tool_choice", "auto")
        }
        return root.toString()
    }

    fun toolJson(tool: Tool): JSONObject {
        val props = JSONObject()
        val required = JSONArray()
        tool.parameters.forEach { (name, desc) ->
            props.put(name, JSONObject().put("type", "string").put("description", desc))
            if (!desc.startsWith("(optional)")) required.put(name)
        }
        val params = JSONObject().put("type", "object").put("properties", props).put("required", required)
        val fn = JSONObject().put("name", tool.name).put("description", tool.description).put("parameters", params)
        return JSONObject().put("type", "function").put("function", fn)
    }
}
