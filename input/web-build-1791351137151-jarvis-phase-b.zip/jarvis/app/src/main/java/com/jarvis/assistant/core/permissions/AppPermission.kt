package com.jarvis.assistant.core.permissions

enum class AppPermission(val key: String, val rationale: String, val denialMessage: String) {
    RECORD_AUDIO(
        "RECORD_AUDIO",
        "JARVIS needs the microphone to hear your voice commands. It listens only after you tap the mic button, and speech is handled by your device's speech recognition service, which may use an online service.",
        "Microphone access is required for voice commands, sir."
    ),
    POST_NOTIFICATIONS(
        "POST_NOTIFICATIONS",
        "Alarms ring as a notification, so JARVIS needs permission to post notifications.",
        "I need notification permission so the alarm can alert you, sir."
    ),
    EXACT_ALARM(
        "EXACT_ALARM",
        "Android requires special 'Alarms & reminders' access before an app can schedule an alarm at an exact time. You'll be taken to the system setting to allow it.",
        "I need permission to schedule exact alarms, sir. Please allow it in the settings screen, then repeat the request."
    );

    companion object {
        fun fromKey(key: String?): AppPermission? = values().firstOrNull { it.key == key }
    }
}
