package com.jarvis.assistant.feature.dashboard

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.core.common.JarvisState

/**
 * IDLE: slow breathing. LISTENING: size follows the real microphone level. PROCESSING / EXECUTING: spinning arcs
 * (faster while a tool is actually running). SPEAKING: pulsing ring. ERROR / SECURITY: colour change.
 */
@Composable
fun JarvisOrb(state: JarvisState, modifier: Modifier = Modifier, level: Float = 0f) {
    val transition = rememberInfiniteTransition(label = "orb")
    val breathe by transition.animateFloat(
        0.92f, 1.08f,
        infiniteRepeatable(
            tween(
                when (state) { JarvisState.IDLE -> 2800; JarvisState.SPEAKING -> 650; else -> 1100 },
                easing = FastOutSlowInEasing
            ),
            RepeatMode.Reverse
        ),
        label = "breathe"
    )
    val spin by transition.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(if (state == JarvisState.EXECUTING) 800 else 1700, easing = LinearEasing)),
        label = "spin"
    )
    val smoothLevel by animateFloatAsState(level, label = "level")
    val color = when (state) {
        JarvisState.ERROR -> Color(0xFFFF5252)
        JarvisState.SECURITY -> Color(0xFFFFB300)
        JarvisState.EXECUTING -> Color(0xFF69F0AE)
        JarvisState.PROCESSING, JarvisState.SEARCHING -> Color(0xFF7C9DFF)
        else -> Color(0xFF29D3FF)
    }
    Canvas(modifier.size(200.dp)) {
        val r = size.minDimension / 2f
        val scale = when (state) {
            JarvisState.LISTENING -> 0.9f + smoothLevel * 0.35f
            JarvisState.IDLE, JarvisState.SPEAKING -> breathe
            else -> 1f
        }
        drawCircle(color.copy(alpha = 0.12f), radius = r * 0.95f * scale)
        drawCircle(color.copy(alpha = 0.30f), radius = r * 0.62f * scale)
        drawCircle(color, radius = r * 0.30f)
        if (state == JarvisState.PROCESSING || state == JarvisState.EXECUTING || state == JarvisState.SEARCHING) {
            val arcSize = Size(r * 1.6f, r * 1.6f)
            val topLeft = Offset(center.x - r * 0.8f, center.y - r * 0.8f)
            val stroke = Stroke(width = 6f, cap = StrokeCap.Round)
            drawArc(color, spin, 90f, false, topLeft, arcSize, style = stroke)
            drawArc(color, spin + 180f, 90f, false, topLeft, arcSize, style = stroke)
        }
        if (state == JarvisState.SPEAKING) {
            drawCircle(color.copy(alpha = 0.5f), radius = r * 0.8f * breathe, style = Stroke(width = 4f))
        }
        if (state == JarvisState.ERROR) {
            drawCircle(color.copy(alpha = 0.7f), radius = r * 0.8f, style = Stroke(width = 4f))
        }
    }
}
