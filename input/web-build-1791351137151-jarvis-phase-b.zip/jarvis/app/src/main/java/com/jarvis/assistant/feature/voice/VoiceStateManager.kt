package com.jarvis.assistant.feature.voice

import com.jarvis.assistant.core.common.JarvisState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class VoiceUiState(val state: JarvisState = JarvisState.IDLE, val status: String = "Ready")

class VoiceStateManager {
    private val _state = MutableStateFlow(VoiceUiState())
    val state: StateFlow<VoiceUiState> = _state.asStateFlow()

    fun set(state: JarvisState, status: String) { _state.value = VoiceUiState(state, status) }

    /** Transition only if the current state is one of [from]; prevents stale coroutines overriding newer states. */
    fun setIfIn(from: Set<JarvisState>, state: JarvisState, status: String) {
        _state.update { if (it.state in from) VoiceUiState(state, status) else it }
    }
}
