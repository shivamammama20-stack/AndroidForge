package com.jarvis.assistant.core.ai

import com.jarvis.assistant.core.config.AiConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

/** Works with Groq and any OpenAI-compatible /chat/completions endpoint. The API key is never logged. */
class OpenAiCompatibleProvider(
    private val config: AiConfig,
    private val connectTimeoutMs: Int = 10_000,
    private val readTimeoutMs: Int = 30_000
) : AIProvider {

    override suspend fun complete(messages: List<ChatMessage>, tools: List<Tool>): AIReply = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) throw AiException.MissingKey()
        val body = OpenAiRequestBuilder.build(config.model, messages, tools)
        var conn: HttpURLConnection? = null
        try {
            conn = URL(config.baseUrl.trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = connectTimeoutMs
            conn.readTimeout = readTimeoutMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer ${config.apiKey}")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code !in 200..299) throw AiException.fromHttp(code)
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            OpenAiResponseParser.parse(text)
        } catch (e: AiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw AiException.Timeout()
        } catch (e: IOException) {
            throw AiException.Network()
        } finally {
            conn?.disconnect()
        }
    }
}
