package com.jarvis.assistant.feature.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/** Wraps android.speech.SpeechRecognizer. Must be used from the main thread. Push-to-talk only: no always-listening. */
class SpeechRecognitionManager(private val context: Context) {
    private val _results = MutableSharedFlow<SpeechResult>(extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val results: SharedFlow<SpeechResult> = _results.asSharedFlow()
    private val _level = MutableStateFlow(0f)
    /** Live microphone loudness 0..1 from the recognizer (drives the orb while listening). */
    val level: StateFlow<Float> = _level.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var cancelling = false

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String = Locale.getDefault().toLanguageTag()) {
        if (!isAvailable()) { _results.tryEmit(SpeechResult.Error(SpeechError.UNAVAILABLE, "Speech recognition unavailable")); return }
        release()
        cancelling = false
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(listener)
        recognizer = r
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        )
    }

    /** Stop capturing and deliver whatever was heard as a final result. */
    fun stop() { recognizer?.stopListening() }

    /** User cancellation: discard audio, emit Cancelled. */
    fun cancel() {
        if (recognizer == null) return
        cancelling = true
        recognizer?.cancel()
        release()
        _results.tryEmit(SpeechResult.Cancelled)
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
        _level.value = 0f
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { _results.tryEmit(SpeechResult.Ready) }
        override fun onBeginningOfSpeech() { _results.tryEmit(SpeechResult.SpeechBegan) }
        override fun onRmsChanged(rmsdB: Float) { _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { _level.value = 0f; _results.tryEmit(SpeechResult.SpeechEnded) }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (cancelling) return
            val (kind, msg) = mapSpeechError(error)
            _results.tryEmit(SpeechResult.Error(kind, msg))
            release()
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!text.isNullOrBlank()) _results.tryEmit(SpeechResult.Partial(text))
        }

        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)?.firstOrNull()
            if (text.isNullOrBlank()) _results.tryEmit(SpeechResult.Error(SpeechError.NO_SPEECH, "I didn't catch that."))
            else _results.tryEmit(SpeechResult.Final(text.trim(), conf))
            release()
        }
    }
}

internal fun mapSpeechError(code: Int): Pair<SpeechError, String> = when (code) {
    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> SpeechError.NO_SPEECH to "I didn't catch that."
    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> SpeechError.PERMISSION_DENIED to "Microphone permission missing"
    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> SpeechError.NETWORK to "Speech service unreachable"
    SpeechRecognizer.ERROR_RECOGNIZER_BUSY, 10 -> SpeechError.BUSY to "Speech recognizer busy"
    SpeechRecognizer.ERROR_AUDIO -> SpeechError.AUDIO to "Audio capture failed"
    12, 13 -> SpeechError.UNAVAILABLE to "Language not supported by the recognizer"
    else -> SpeechError.OTHER to "Speech recognition error ($code)"
}
