package com.jarvis.assistant.core.common
enum class JarvisState { IDLE, LISTENING, PROCESSING, SEARCHING, EXECUTING, SPEAKING, SECURITY, ERROR }
