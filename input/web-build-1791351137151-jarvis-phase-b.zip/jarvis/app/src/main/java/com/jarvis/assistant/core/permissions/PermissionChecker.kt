package com.jarvis.assistant.core.permissions

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

interface PermissionChecker { fun isGranted(permission: AppPermission): Boolean }

class AndroidPermissionChecker(private val context: Context) : PermissionChecker {
    override fun isGranted(permission: AppPermission): Boolean = when (permission) {
        AppPermission.RECORD_AUDIO -> runtime(Manifest.permission.RECORD_AUDIO)
        AppPermission.POST_NOTIFICATIONS -> Build.VERSION.SDK_INT < 33 || runtime(Manifest.permission.POST_NOTIFICATIONS)
        AppPermission.EXACT_ALARM -> Build.VERSION.SDK_INT < 31 ||
            context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    }

    private fun runtime(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED
}
