package com.jarvis.assistant.feature.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import com.jarvis.assistant.MainActivity

enum class ScheduleResult { SCHEDULED, PERMISSION_MISSING, FAILED }

interface AlarmScheduler {
    fun schedule(triggerAtMillis: Long): ScheduleResult
    fun isScheduled(triggerAtMillis: Long): Boolean
}

/** Uses AlarmManager.setAlarmClock (exact, Doze-exempt, shows the alarm icon in the status bar). */
class AndroidAlarmScheduler(private val context: Context, private val store: AlarmStore) : AlarmScheduler {
    private val am: AlarmManager = context.getSystemService(AlarmManager::class.java)

    override fun schedule(triggerAtMillis: Long): ScheduleResult {
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return ScheduleResult.PERMISSION_MISSING
        return try {
            val show = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val op = operation(triggerAtMillis, create = true) ?: return ScheduleResult.FAILED
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAtMillis, show), op)
            store.add(triggerAtMillis)
            ScheduleResult.SCHEDULED
        } catch (e: SecurityException) {
            ScheduleResult.PERMISSION_MISSING
        } catch (e: Exception) {
            ScheduleResult.FAILED
        }
    }

    /** Partial verification: our PendingIntent exists, we stored it, and the system's next alarm clock is at or before it. */
    override fun isScheduled(triggerAtMillis: Long): Boolean {
        val next = am.nextAlarmClock ?: return false
        return operation(triggerAtMillis, create = false) != null &&
            store.all().contains(triggerAtMillis) && next.triggerTime <= triggerAtMillis
    }

    fun rescheduleAll(nowMs: Long) {
        store.all().forEach { if (it > nowMs) schedule(it) else store.remove(it) }
    }

    private fun operation(trigger: Long, create: Boolean): PendingIntent? {
        val intent = Intent(context, AlarmReceiver::class.java)
            .setAction(AlarmReceiver.ACTION).setData(Uri.parse("jarvis://alarm/$trigger"))
        val flags = PendingIntent.FLAG_IMMUTABLE or
            if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        return PendingIntent.getBroadcast(context, 0, intent, flags)
    }
}
