package com.jarvis.assistant.core.ai

sealed class AiException(message: String) : Exception(message) {
    class MissingKey : AiException("No API key configured")
    class InvalidKey : AiException("The provider rejected the API key")
    class RateLimited : AiException("Rate limited by provider")
    class Timeout : AiException("The provider timed out")
    class Network : AiException("Network failure")
    class Server(val code: Int) : AiException("Provider error $code")
    class BadRequest(val code: Int) : AiException("Provider rejected the request ($code)")
    class Malformed : AiException("Malformed provider response")

    companion object {
        fun fromHttp(code: Int): AiException = when {
            code == 401 || code == 403 -> InvalidKey()
            code == 429 -> RateLimited()
            code in 500..599 -> Server(code)
            else -> BadRequest(code)
        }
    }
}
