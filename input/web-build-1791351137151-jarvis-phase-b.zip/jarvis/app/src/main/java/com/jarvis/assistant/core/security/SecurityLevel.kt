package com.jarvis.assistant.core.security
enum class SecurityLevel { LOW, MEDIUM, HIGH, CRITICAL;
    val needsConfirmation get() = this >= HIGH }
