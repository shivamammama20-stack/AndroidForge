package com.jarvis.assistant.core.security

enum class SecurityDecision { ALLOW, CONFIRM, CONFIRM_STRICT }

/** LOW/MEDIUM run directly (tools still enforce their own permissions). HIGH needs confirmation; CRITICAL needs the explicit word "confirm". */
class SecurityEngine {
    fun evaluate(level: SecurityLevel): SecurityDecision = when (level) {
        SecurityLevel.LOW, SecurityLevel.MEDIUM -> SecurityDecision.ALLOW
        SecurityLevel.HIGH -> SecurityDecision.CONFIRM
        SecurityLevel.CRITICAL -> SecurityDecision.CONFIRM_STRICT
    }
}
