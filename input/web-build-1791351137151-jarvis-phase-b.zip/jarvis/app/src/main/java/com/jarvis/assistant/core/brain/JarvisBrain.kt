package com.jarvis.assistant.core.brain

import com.jarvis.assistant.core.ai.AIProvider
import com.jarvis.assistant.core.ai.AiException
import com.jarvis.assistant.core.ai.ChatMessage
import com.jarvis.assistant.core.ai.Tool
import com.jarvis.assistant.core.ai.ToolCall
import com.jarvis.assistant.core.ai.ToolRegistry
import com.jarvis.assistant.core.permissions.AppPermission
import com.jarvis.assistant.core.security.SecurityDecision
import com.jarvis.assistant.core.security.SecurityEngine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.cancellation.CancellationException

/**
 * Input -> context -> intent (local fast path, else AI) -> tool selection -> security -> confirmation
 * -> execution -> result verification -> response. The AI can only *request* tools that are registered.
 */
class JarvisBrain(
    private val registry: ToolRegistry,
    private val providerSupplier: () -> AIProvider?,
    private val security: SecurityEngine = SecurityEngine(),
    private val contextCollector: ContextCollector = ContextCollector(),
    private val localParser: LocalIntentParser = LocalIntentParser(),
    private val responses: ResponseGenerator = ResponseGenerator(),
    private val nowMs: () -> Long = { System.currentTimeMillis() }
) {
    private val mutex = Mutex()
    private val history = ArrayDeque<ChatMessage>()
    private var pending: PendingAction? = null

    private sealed interface AiStep {
        data class Done(val response: BrainResponse) : AiStep
        data class Call(val call: ToolCall) : AiStep
    }

    suspend fun process(input: String, onPhase: PhaseListener = { _, _ -> }): BrainResponse = mutex.withLock {
        val text = input.trim()
        if (text.isEmpty()) return@withLock response(Outcome.UNKNOWN, responses.unknown())
        val result = handle(text, onPhase)
        remember(text, result.text)
        result
    }

    private suspend fun handle(text: String, onPhase: PhaseListener): BrainResponse {
        resolvePending(text, onPhase)?.let { return it }
        onPhase(BrainPhase.UNDERSTANDING, "")
        val ctx = contextCollector.collect()
        val call = localParser.parse(text) ?: when (val step = askAi(text, ctx, onPhase)) {
            is AiStep.Done -> return step.response
            is AiStep.Call -> step.call
        }
        return dispatch(call, onPhase)
    }

    private suspend fun askAi(text: String, ctx: BrainContext, onPhase: PhaseListener): AiStep {
        val provider = providerSupplier() ?: return AiStep.Done(response(Outcome.ERROR, responses.missingApiKey()))
        onPhase(BrainPhase.REASONING, "")
        val aiReply = try {
            provider.complete(buildMessages(text, ctx), registry.all())
        } catch (e: CancellationException) {
            throw e
        } catch (e: AiException) {
            return AiStep.Done(response(Outcome.ERROR, responses.forAiError(e)))
        } catch (e: Exception) {
            return AiStep.Done(response(Outcome.ERROR, responses.genericFailure()))
        }
        aiReply.toolCall?.let { return AiStep.Call(it) }
        val answer = aiReply.text ?: return AiStep.Done(response(Outcome.UNKNOWN, responses.unknown()))
        return AiStep.Done(response(Outcome.ANSWERED, answer))
    }

    private suspend fun dispatch(call: ToolCall, onPhase: PhaseListener): BrainResponse {
        val tool = registry.get(call.name) ?: return response(Outcome.UNKNOWN, responses.unknown()) // AI asked for something unregistered
        val decision = security.evaluate(tool.securityLevel)
        if (decision == SecurityDecision.ALLOW) return execute(tool, call, false, onPhase)
        val strict = decision == SecurityDecision.CONFIRM_STRICT
        val description = tool.describe(call.args)
        pending = PendingAction(call, description, strict, nowMs() + CONFIRM_TTL_MS)
        return response(Outcome.NEEDS_CONFIRMATION, responses.confirmationPrompt(description, strict), call.name)
    }

    private suspend fun resolvePending(text: String, onPhase: PhaseListener): BrainResponse? {
        val p = pending ?: return null
        pending = null
        if (nowMs() > p.expiresAtMs) return null
        val tool = registry.get(p.call.name) ?: return null
        return when (ConfirmationParser.parse(text)) {
            Confirmation.STRICT_YES -> execute(tool, p.call, true, onPhase)
            Confirmation.YES ->
                if (p.strict) {
                    pending = p
                    response(Outcome.NEEDS_CONFIRMATION, responses.strictReminder(p.description), p.call.name)
                } else execute(tool, p.call, true, onPhase)
            Confirmation.NO -> response(Outcome.CANCELLED, responses.cancelled())
            Confirmation.UNRELATED -> null // pending dropped; treat as a new command
        }
    }

    private suspend fun execute(tool: Tool, call: ToolCall, confirmed: Boolean, onPhase: PhaseListener): BrainResponse {
        onPhase(BrainPhase.EXECUTING, tool.name)
        val r = registry.run(call.name, call.args, confirmed)
        return when {
            r.success -> BrainResponse(responses.forSuccess(call.name, r), Outcome.EXECUTED, call.name, r)
            r.requiresPermission != null -> {
                val p = AppPermission.fromKey(r.requiresPermission)
                BrainResponse(responses.forPermission(p), Outcome.NEEDS_PERMISSION, call.name, r, p)
            }
            else -> BrainResponse(responses.forFailure(call.name, r), Outcome.FAILED, call.name, r)
        }
    }

    private fun response(outcome: Outcome, text: String, toolName: String? = null) = BrainResponse(text, outcome, toolName)

    private fun buildMessages(text: String, ctx: BrainContext): List<ChatMessage> =
        listOf(ChatMessage("system", SYSTEM_PROMPT + "\n" + ctx.toPromptBlock())) + history + ChatMessage("user", text)

    private fun remember(user: String, assistant: String) {
        history.addLast(ChatMessage("user", user))
        history.addLast(ChatMessage("assistant", assistant))
        while (history.size > MAX_HISTORY) history.removeFirst()
    }

    private companion object {
        const val CONFIRM_TTL_MS = 60_000L
        const val MAX_HISTORY = 12
        const val SYSTEM_PROMPT =
            "You are JARVIS, a calm, mature, concise personal assistant on the user's Android phone. " +
            "Address the user as 'sir' only occasionally. Keep replies under three sentences. " +
            "You can act ONLY by calling one of the provided tools; never invent tools and never write code. " +
            "Do not claim an action was done: the app reports the real result. " +
            "If no tool fits, answer briefly in plain text. " +
            "You currently have no web access or live data, so say so if asked about current events."
    }
}
