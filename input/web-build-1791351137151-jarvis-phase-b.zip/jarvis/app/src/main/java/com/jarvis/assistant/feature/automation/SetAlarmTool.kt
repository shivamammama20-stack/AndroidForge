package com.jarvis.assistant.feature.automation

import com.jarvis.assistant.core.ai.FailureCode
import com.jarvis.assistant.core.ai.Tool
import com.jarvis.assistant.core.ai.ToolResult
import com.jarvis.assistant.core.permissions.AppPermission
import com.jarvis.assistant.core.permissions.PermissionChecker
import com.jarvis.assistant.core.security.SecurityLevel
import java.time.Clock
import java.time.ZonedDateTime

class SetAlarmTool(
    private val scheduler: AlarmScheduler,
    private val permissions: PermissionChecker,
    private val clock: Clock = Clock.systemDefaultZone()
) : Tool {
    override val name = "setAlarm"
    override val description = "Set an alarm for a specific time."
    override val parameters = mapOf("time" to "When the alarm should ring, in the user's own words, e.g. '6 AM', 'tomorrow at 7:30', 'wake me at 6'")
    override val securityLevel = SecurityLevel.MEDIUM
    override val requiredPermissions = listOf(AppPermission.POST_NOTIFICATIONS.key, AppPermission.EXACT_ALARM.key)

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val now = ZonedDateTime.now(clock)
        val parsed = AlarmTimeParser.parse(args["time"].orEmpty(), now)
            ?: return ToolResult(
                false, failureReason = "I couldn't work out a valid future time for that alarm, sir. Try something like '6:30 AM'.",
                failureCode = FailureCode.INVALID_ARGUMENTS
            )
        for (p in listOf(AppPermission.POST_NOTIFICATIONS, AppPermission.EXACT_ALARM)) {
            if (!permissions.isGranted(p)) return permissionNeeded(p)
        }
        val trigger = parsed.dateTime.toInstant().toEpochMilli()
        return when (scheduler.schedule(trigger)) {
            ScheduleResult.PERMISSION_MISSING -> permissionNeeded(AppPermission.EXACT_ALARM)
            ScheduleResult.FAILED -> ToolResult(false, failureReason = "AlarmManager did not accept the alarm", failureCode = FailureCode.EXECUTION_ERROR)
            ScheduleResult.SCHEDULED ->
                if (!scheduler.isScheduled(trigger)) {
                    ToolResult(false, failureReason = "The alarm could not be verified after scheduling", failureCode = FailureCode.UNAVAILABLE)
                } else ToolResult(
                    true, actionPerformed = "alarm_scheduled", verification = "alarm_clock_registered",
                    target = "alarm",
                    data = mapOf(
                        "display" to AlarmTimeParser.describe(parsed.dateTime, now),
                        "triggerAtMillis" to trigger.toString(),
                        "meridiemAssumed" to parsed.meridiemAssumed.toString()
                    )
                )
        }
    }

    private fun permissionNeeded(p: AppPermission) = ToolResult(
        false, failureReason = "Permission required: ${p.key}", requiresPermission = p.key, failureCode = FailureCode.PERMISSION_REQUIRED
    )
}
