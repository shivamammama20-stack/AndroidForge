package com.jarvis.assistant.core.ai

import com.jarvis.assistant.core.security.SecurityLevel

enum class FailureCode {
    NOT_FOUND, AMBIGUOUS, LAUNCH_FAILED, PERMISSION_REQUIRED, INVALID_ARGUMENTS,
    UNAVAILABLE, CONFIRMATION_REQUIRED, UNKNOWN_TOOL, EXECUTION_ERROR
}

data class ToolResult(
    val success: Boolean,
    val actionPerformed: String = "",
    val verification: String = "",
    val failureReason: String? = null,
    val requiresPermission: String? = null,
    val requiresConfirmation: Boolean = false,
    val target: String = "",
    val data: Map<String, String> = emptyMap(),
    val failureCode: FailureCode? = null
)

interface Tool {
    val name: String
    val description: String
    /** parameter name -> description. All parameters are strings; prefix the description with "(optional)" for optional ones. */
    val parameters: Map<String, String>
    val securityLevel: SecurityLevel
    val requiredPermissions: List<String> get() = emptyList()
    /** Human-readable description of what this call would do (used in confirmation prompts). */
    fun describe(args: Map<String, String>): String = description
    suspend fun execute(args: Map<String, String>): ToolResult
}
