package com.jarvis.assistant.feature.assistant

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.AppContainer
import com.jarvis.assistant.core.brain.BrainPhase
import com.jarvis.assistant.core.brain.BrainResponse
import com.jarvis.assistant.core.brain.Outcome
import com.jarvis.assistant.core.common.JarvisState
import com.jarvis.assistant.core.config.AiConfig
import com.jarvis.assistant.core.permissions.AppPermission
import com.jarvis.assistant.feature.voice.AndroidTTSProvider
import com.jarvis.assistant.feature.voice.SpeechError
import com.jarvis.assistant.feature.voice.SpeechRecognitionManager
import com.jarvis.assistant.feature.voice.SpeechResult
import com.jarvis.assistant.feature.voice.TTSManager
import com.jarvis.assistant.feature.voice.VoiceCommandRouter
import com.jarvis.assistant.feature.voice.VoiceStateManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ConversationEntry(val id: Long, val fromUser: Boolean, val text: String)

data class JarvisUiState(
    val state: JarvisState = JarvisState.IDLE,
    val status: String = "Ready",
    val partialTranscript: String = "",
    val level: Float = 0f,
    val conversation: List<ConversationEntry> = emptyList(),
    val aiConfigured: Boolean = false,
    val hasApiKey: Boolean = false,
    val baseUrl: String = AiConfig.DEFAULT_BASE_URL,
    val model: String = AiConfig.DEFAULT_MODEL,
    val micAvailable: Boolean = true,
    val voiceOutputAvailable: Boolean = false,
    val autoSpeak: Boolean = true
)

sealed interface UiEvent { data class RequestPermission(val permission: AppPermission) : UiEvent }

class JarvisViewModel(private val container: AppContainer) : ViewModel() {
    private val context = container.appContext
    private val speech = SpeechRecognitionManager(context)
    private val tts = TTSManager(AndroidTTSProvider(context))
    private val voice = VoiceStateManager()
    private val router = VoiceCommandRouter()
    private var job: Job? = null
    private var nextId = 0L

    private val _ui = MutableStateFlow(JarvisUiState())
    val ui: StateFlow<JarvisUiState> = _ui.asStateFlow()
    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<UiEvent> = _events.asSharedFlow()

    init {
        val micOk = speech.isAvailable()
        _ui.update { it.copy(micAvailable = micOk) }
        if (!micOk) voice.set(JarvisState.IDLE, "Voice recognition unavailable on this device. Type a command instead.")
        tts.initialize { ok -> _ui.update { it.copy(voiceOutputAvailable = ok) } }
        viewModelScope.launch { voice.state.collect { v -> _ui.update { it.copy(state = v.state, status = v.status) } } }
        viewModelScope.launch { speech.level.collect { l -> _ui.update { it.copy(level = l) } } }
        viewModelScope.launch { speech.results.collect { onSpeech(it) } }
        viewModelScope.launch {
            container.aiConfig.config.collect { c ->
                _ui.update { it.copy(aiConfigured = c.isUsable, hasApiKey = c.apiKey.isNotBlank(), baseUrl = c.baseUrl, model = c.model) }
            }
        }
    }

    // ---- user actions ----
    fun onMicClicked() {
        when (voice.state.value.state) {
            JarvisState.LISTENING -> { speech.cancel(); voice.set(JarvisState.IDLE, "Cancelled") }
            JarvisState.SPEAKING, JarvisState.ERROR -> { tts.stop(); startListening() } // barge-in
            JarvisState.PROCESSING, JarvisState.EXECUTING -> cancelCurrent()
            else -> startListening()
        }
    }

    fun onTextSubmitted(text: String) = submit(text)

    fun onPermissionResult(permission: AppPermission, granted: Boolean) {
        when (permission) {
            AppPermission.RECORD_AUDIO -> if (granted) startListening() else say(permission.denialMessage, true)
            AppPermission.POST_NOTIFICATIONS ->
                say(if (granted) "Thank you, sir. Please repeat the request." else permission.denialMessage, !granted)
            AppPermission.EXACT_ALARM -> Unit // granted in system settings; user repeats the request
        }
    }

    /** Returns an error message, or null on success. */
    fun saveAiConfig(baseUrl: String, model: String, apiKey: String): String? {
        val url = baseUrl.trim().trimEnd('/')
        if (!url.startsWith("https://")) return "The base URL must start with https://"
        if (model.isBlank()) return "A model name is required."
        return try {
            container.aiConfig.update(url, model, apiKey.trim().ifEmpty { null })
            null
        } catch (e: Exception) {
            "I couldn't store the key securely on this device."
        }
    }

    fun clearApiKey() = container.aiConfig.clearKey()

    // ---- voice input ----
    private fun startListening() {
        if (!container.permissions.isGranted(AppPermission.RECORD_AUDIO)) {
            _events.tryEmit(UiEvent.RequestPermission(AppPermission.RECORD_AUDIO)); return
        }
        if (!speech.isAvailable()) {
            say("Speech recognition isn't available right now, sir. You can type the command instead.", true); return
        }
        tts.stop()
        _ui.update { it.copy(partialTranscript = "") }
        voice.set(JarvisState.IDLE, "Starting microphone…")
        speech.start()
    }

    private fun onSpeech(r: SpeechResult) {
        when (r) {
            is SpeechResult.Ready -> voice.set(JarvisState.LISTENING, "Listening…")
            is SpeechResult.SpeechBegan -> voice.set(JarvisState.LISTENING, "Hearing you…")
            is SpeechResult.Partial -> _ui.update { it.copy(partialTranscript = r.text) }
            is SpeechResult.SpeechEnded -> voice.set(JarvisState.PROCESSING, "Recognising speech…")
            is SpeechResult.Final -> { _ui.update { it.copy(partialTranscript = "") }; submit(r.text) }
            is SpeechResult.Cancelled -> _ui.update { it.copy(partialTranscript = "") }
            is SpeechResult.Error -> {
                _ui.update { it.copy(partialTranscript = "") }
                when (r.kind) {
                    SpeechError.NO_SPEECH -> voice.set(JarvisState.IDLE, "I didn't catch that. Tap the mic to try again.")
                    SpeechError.PERMISSION_DENIED -> say(AppPermission.RECORD_AUDIO.denialMessage, true)
                    else -> say("Speech recognition isn't available right now, sir. You can type the command instead.", true)
                }
            }
        }
    }

    // ---- brain pipeline (typed and spoken input both land here) ----
    private fun submit(raw: String) {
        val cmd = router.normalize(raw) ?: return
        if (voice.state.value.state == JarvisState.LISTENING) speech.cancel()
        tts.stop()
        job?.cancel()
        addEntry(fromUser = true, text = raw.trim())
        job = viewModelScope.launch {
            voice.set(JarvisState.PROCESSING, "Understanding…")
            val response: BrainResponse = container.brain.process(cmd) { phase, detail ->
                when (phase) {
                    BrainPhase.UNDERSTANDING -> voice.set(JarvisState.PROCESSING, "Understanding…")
                    BrainPhase.REASONING -> voice.set(JarvisState.PROCESSING, "Thinking…")
                    BrainPhase.EXECUTING -> voice.set(JarvisState.EXECUTING, "Running $detail…")
                }
            }
            response.permission?.let { _events.tryEmit(UiEvent.RequestPermission(it)) }
            deliver(response.text, response.isError, response.outcome == Outcome.NEEDS_CONFIRMATION)
        }
    }

    private fun say(text: String, isError: Boolean) {
        job?.cancel()
        job = viewModelScope.launch { deliver(text, isError, listenAfter = false) }
    }

    private suspend fun deliver(text: String, isError: Boolean, listenAfter: Boolean) {
        addEntry(fromUser = false, text = text)
        val s = _ui.value
        val canSpeak = s.autoSpeak && s.voiceOutputAvailable
        when {
            isError -> voice.set(JarvisState.ERROR, "Needs attention")
            canSpeak -> voice.set(JarvisState.SPEAKING, "Speaking…")
            else -> voice.set(JarvisState.IDLE, "Ready")
        }
        if (canSpeak) tts.speak(text) else if (isError) delay(1500)
        voice.setIfIn(
            setOf(JarvisState.SPEAKING, JarvisState.ERROR), JarvisState.IDLE,
            if (listenAfter) "Awaiting your reply" else "Ready"
        )
        // Only auto-listen for a confirmation if nothing else (e.g. barge-in) has taken over.
        if (listenAfter && voice.state.value.state == JarvisState.IDLE &&
            container.permissions.isGranted(AppPermission.RECORD_AUDIO) && speech.isAvailable()
        ) startListening()
    }

    private fun cancelCurrent() {
        job?.cancel()
        voice.set(JarvisState.IDLE, "Cancelled")
    }

    private fun addEntry(fromUser: Boolean, text: String) {
        _ui.update { it.copy(conversation = it.conversation + ConversationEntry(nextId++, fromUser, text)) }
    }

    override fun onCleared() {
        speech.release()
        tts.shutdown()
    }
}

class JarvisViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = JarvisViewModel(container) as T
}
