package com.jarvis.assistant.feature.voice

enum class SpeechError { NO_SPEECH, PERMISSION_DENIED, NETWORK, BUSY, UNAVAILABLE, AUDIO, OTHER }

sealed interface SpeechResult {
    object Ready : SpeechResult
    object SpeechBegan : SpeechResult
    object SpeechEnded : SpeechResult
    object Cancelled : SpeechResult
    data class Partial(val text: String) : SpeechResult
    data class Final(val text: String, val confidence: Float?) : SpeechResult
    data class Error(val kind: SpeechError, val message: String) : SpeechResult
}
