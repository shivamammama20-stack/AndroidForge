package com.jarvis.assistant.core.config

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AiConfigRepository(context: Context, private val secrets: SecretStore) {
    private val prefs = context.getSharedPreferences("jarvis_ai_config", Context.MODE_PRIVATE)
    private val _config = MutableStateFlow(load())
    val config: StateFlow<AiConfig> = _config.asStateFlow()

    /** [apiKey] == null keeps the stored key. */
    fun update(baseUrl: String, model: String, apiKey: String?) {
        if (apiKey != null) secrets.write(apiKey)
        prefs.edit().putString(K_URL, baseUrl.trim().trimEnd('/')).putString(K_MODEL, model.trim()).apply()
        _config.value = load()
    }

    fun clearKey() { secrets.clear(); _config.value = load() }

    private fun load() = AiConfig(
        baseUrl = prefs.getString(K_URL, null) ?: AiConfig.DEFAULT_BASE_URL,
        apiKey = runCatching { secrets.read() }.getOrNull().orEmpty(),
        model = prefs.getString(K_MODEL, null) ?: AiConfig.DEFAULT_MODEL
    )

    private companion object { const val K_URL = "base_url"; const val K_MODEL = "model" }
}
