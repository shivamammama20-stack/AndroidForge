package com.jarvis.assistant.core.config

interface SecretStore {
    fun read(): String?
    fun write(value: String)
    fun clear()
}
