package com.jarvis.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.jarvis.assistant.feature.assistant.JarvisViewModel
import com.jarvis.assistant.feature.assistant.JarvisViewModelFactory
import com.jarvis.assistant.ui.JarvisScreen

class MainActivity : ComponentActivity() {
    private val viewModel: JarvisViewModel by viewModels {
        JarvisViewModelFactory((application as JarvisApp).container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF05080F), primary = Color(0xFF29D3FF))) {
                JarvisScreen(viewModel)
            }
        }
    }
}
