package com.jarvis.assistant.feature.voice

/** Normalises spoken or typed input so both enter the Brain identically. */
class VoiceCommandRouter {
    fun normalize(raw: String): String? {
        val cleaned = raw.trim().replace(WAKE, "").trim()
        return cleaned.ifBlank { null }
    }

    private companion object {
        val WAKE = Regex("^(?:(?:hey|ok|okay)\\s+)?jarvis\\b[\\s,:.!-]*", RegexOption.IGNORE_CASE)
    }
}
