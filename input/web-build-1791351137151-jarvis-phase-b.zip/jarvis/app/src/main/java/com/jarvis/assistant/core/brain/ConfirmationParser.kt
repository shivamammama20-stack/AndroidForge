package com.jarvis.assistant.core.brain

enum class Confirmation { YES, STRICT_YES, NO, UNRELATED }

object ConfirmationParser {
    private val FILLER = setOf("sir", "please", "jarvis")
    private val STRICT = setOf("confirm", "i confirm", "confirmed")
    private val YES = setOf("yes", "yeah", "yep", "yup", "sure", "ok", "okay", "go ahead", "proceed", "do it", "send it", "haan", "ha")
    private val NO = setOf("no", "nope", "cancel", "stop", "dont", "don't", "do not", "never mind", "nevermind", "nahi", "negative", "abort")

    fun parse(text: String): Confirmation {
        val t = text.lowercase().replace(Regex("[^a-z' ]"), " ").split(' ')
            .filter { it.isNotBlank() && it !in FILLER }.joinToString(" ")
        return when (t) {
            in STRICT -> Confirmation.STRICT_YES
            in YES -> Confirmation.YES
            in NO -> Confirmation.NO
            else -> Confirmation.UNRELATED
        }
    }
}
