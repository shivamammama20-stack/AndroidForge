package com.jarvis.assistant.core.ai

import kotlin.coroutines.cancellation.CancellationException

class ToolRegistry {
    private val tools = linkedMapOf<String, Tool>()
    fun register(tool: Tool) { tools[tool.name] = tool }
    fun get(name: String): Tool? = tools[name]
    fun all(): List<Tool> = tools.values.toList()

    /** Only registered tools can run. HIGH/CRITICAL tools never run unless [confirmed] is true. */
    suspend fun run(name: String, args: Map<String, String>, confirmed: Boolean = false): ToolResult {
        val t = tools[name] ?: return ToolResult(false, failureReason = "Unknown tool: $name", failureCode = FailureCode.UNKNOWN_TOOL)
        if (t.securityLevel.needsConfirmation && !confirmed) {
            return ToolResult(false, requiresConfirmation = true, failureReason = "Confirmation required", failureCode = FailureCode.CONFIRMATION_REQUIRED)
        }
        return try {
            t.execute(args)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ToolResult(false, failureReason = e.message ?: e::class.java.simpleName, failureCode = FailureCode.EXECUTION_ERROR)
        }
    }
}
