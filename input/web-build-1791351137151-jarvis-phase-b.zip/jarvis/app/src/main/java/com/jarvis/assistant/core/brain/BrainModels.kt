package com.jarvis.assistant.core.brain

import com.jarvis.assistant.core.ai.ToolCall
import com.jarvis.assistant.core.ai.ToolResult
import com.jarvis.assistant.core.permissions.AppPermission
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class BrainPhase { UNDERSTANDING, REASONING, EXECUTING }
typealias PhaseListener = (BrainPhase, String) -> Unit

enum class Outcome { ANSWERED, EXECUTED, FAILED, NEEDS_CONFIRMATION, NEEDS_PERMISSION, CANCELLED, UNKNOWN, ERROR }

data class BrainResponse(
    val text: String,
    val outcome: Outcome,
    val toolName: String? = null,
    val toolResult: ToolResult? = null,
    val permission: AppPermission? = null
) {
    val isError: Boolean get() = outcome == Outcome.FAILED || outcome == Outcome.ERROR ||
        outcome == Outcome.UNKNOWN || outcome == Outcome.NEEDS_PERMISSION
}

data class PendingAction(val call: ToolCall, val description: String, val strict: Boolean, val expiresAtMs: Long)

data class BrainContext(val now: ZonedDateTime, val locale: Locale) {
    fun toPromptBlock(): String =
        "Current local date and time: ${now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH))} (${now.zone})."
}

class ContextCollector(
    private val clock: java.time.Clock = java.time.Clock.systemDefaultZone(),
    private val locale: Locale = Locale.getDefault()
) {
    fun collect() = BrainContext(ZonedDateTime.now(clock), locale)
}
