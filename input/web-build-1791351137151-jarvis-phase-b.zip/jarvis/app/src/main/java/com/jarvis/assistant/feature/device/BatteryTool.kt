package com.jarvis.assistant.feature.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.jarvis.assistant.core.ai.FailureCode
import com.jarvis.assistant.core.ai.Tool
import com.jarvis.assistant.core.ai.ToolResult
import com.jarvis.assistant.core.security.SecurityLevel
import kotlin.math.roundToInt

enum class ChargeState { CHARGING, DISCHARGING, FULL, NOT_CHARGING, UNKNOWN }

data class BatteryInfo(val percent: Int, val state: ChargeState, val source: String) {
    companion object {
        fun fromRaw(level: Int, scale: Int, status: Int, plugged: Int): BatteryInfo? {
            if (level < 0 || scale <= 0) return null
            val pct = (level * 100f / scale).roundToInt().coerceIn(0, 100)
            val state = when (status) {
                BatteryManager.BATTERY_STATUS_CHARGING -> ChargeState.CHARGING
                BatteryManager.BATTERY_STATUS_DISCHARGING -> ChargeState.DISCHARGING
                BatteryManager.BATTERY_STATUS_FULL -> ChargeState.FULL
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> ChargeState.NOT_CHARGING
                else -> ChargeState.UNKNOWN
            }
            val source = when {
                plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC"
                plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
                plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "wireless"
                else -> "none"
            }
            return BatteryInfo(pct, state, source)
        }
    }
}

interface BatteryInfoProvider { fun read(): BatteryInfo? }

class AndroidBatteryInfoProvider(private val context: Context) : BatteryInfoProvider {
    override fun read(): BatteryInfo? {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        return BatteryInfo.fromRaw(
            i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1), i.getIntExtra(BatteryManager.EXTRA_SCALE, -1),
            i.getIntExtra(BatteryManager.EXTRA_STATUS, -1), i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        )
    }
}

class BatteryTool(private val provider: BatteryInfoProvider) : Tool {
    override val name = "getBattery"
    override val description = "Get the phone's battery percentage and charging state."
    override val parameters = emptyMap<String, String>()
    override val securityLevel = SecurityLevel.LOW

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val info = provider.read()
            ?: return ToolResult(false, failureReason = "Battery information is unavailable", failureCode = FailureCode.UNAVAILABLE)
        return ToolResult(
            true, actionPerformed = "battery_read", verification = "read_from_ACTION_BATTERY_CHANGED", target = "battery",
            data = mapOf("percent" to info.percent.toString(), "state" to info.state.name, "source" to info.source)
        )
    }
}
