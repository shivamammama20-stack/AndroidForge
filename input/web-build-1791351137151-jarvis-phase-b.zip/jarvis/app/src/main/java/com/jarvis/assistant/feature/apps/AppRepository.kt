package com.jarvis.assistant.feature.apps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

enum class LaunchStatus { DISPATCHED, NO_LAUNCH_INTENT, FAILED }

interface AppRepository {
    fun launchableApps(): List<AppInfo>
    fun launch(packageName: String): LaunchStatus
}

class PackageManagerAppRepository(private val context: Context) : AppRepository {
    @Suppress("DEPRECATION")
    override fun launchableApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            pm.queryIntentActivities(intent, 0)
        }
        return infos.map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    override fun launch(packageName: String): LaunchStatus {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return LaunchStatus.NO_LAUNCH_INTENT
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            LaunchStatus.DISPATCHED
        } catch (e: Exception) {
            LaunchStatus.FAILED
        }
    }
}
