package com.jarvis.assistant.feature.apps

import com.jarvis.assistant.core.ai.FailureCode
import com.jarvis.assistant.core.ai.Tool
import com.jarvis.assistant.core.ai.ToolResult
import com.jarvis.assistant.core.security.SecurityLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class OpenAppTool(private val repo: AppRepository) : Tool {
    override val name = "openApp"
    override val description = "Open an installed application by its name."
    override val parameters = mapOf("app" to "Name of the application to open, e.g. 'YouTube'")
    override val securityLevel = SecurityLevel.LOW

    override suspend fun execute(args: Map<String, String>): ToolResult {
        val query = args["app"]?.trim().orEmpty()
        if (query.isEmpty()) {
            return ToolResult(false, failureReason = "Which application should I open, sir?", failureCode = FailureCode.INVALID_ARGUMENTS)
        }
        val apps = withContext(Dispatchers.IO) { repo.launchableApps() }
        return when (val m = AppResolver.resolve(query, apps)) {
            is AppMatch.NotFound -> ToolResult(false, failureReason = "No installed app matches '$query'", target = query, failureCode = FailureCode.NOT_FOUND)
            is AppMatch.Ambiguous -> ToolResult(
                false, failureReason = "Multiple apps match '$query'", target = query,
                data = mapOf("options" to m.options.joinToString(", ") { it.label }), failureCode = FailureCode.AMBIGUOUS
            )
            is AppMatch.Found -> when (repo.launch(m.app.packageName)) {
                LaunchStatus.DISPATCHED -> ToolResult(
                    true, actionPerformed = "launch_requested",
                    verification = "launch_intent_dispatched_without_error (foreground state not verifiable until Accessibility is enabled)",
                    target = m.app.label, data = mapOf("package" to m.app.packageName)
                )
                else -> ToolResult(false, failureReason = "Android did not launch ${m.app.label}", target = m.app.label, failureCode = FailureCode.LAUNCH_FAILED)
            }
        }
    }
}
