package com.jarvis.assistant.feature.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/** Lower, slightly slower than default for a calm, mature delivery. No real person's voice is imitated. */
data class VoiceSettings(
    val locale: Locale = Locale.getDefault(),
    val speechRate: Float = 0.95f,
    val pitch: Float = 0.85f,
    val volume: Float = 1f
)

interface TTSProvider {
    interface UtteranceListener {
        fun onStart(id: String)
        fun onFinished(id: String, completed: Boolean)
    }

    val isReady: Boolean
    fun initialize(onResult: (Boolean) -> Unit)
    fun speak(text: String, utteranceId: String, settings: VoiceSettings, listener: UtteranceListener)
    fun stop()
    fun shutdown()
}

class AndroidTTSProvider(private val context: Context) : TTSProvider {
    private var engine: TextToSpeech? = null
    @Volatile private var ready = false
    private val listeners = ConcurrentHashMap<String, TTSProvider.UtteranceListener>()
    override val isReady: Boolean get() = ready

    override fun initialize(onResult: (Boolean) -> Unit) {
        if (engine != null) { onResult(ready); return }
        engine = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) engine?.setOnUtteranceProgressListener(progress)
            onResult(ready)
        }
    }

    override fun speak(text: String, utteranceId: String, settings: VoiceSettings, listener: TTSProvider.UtteranceListener) {
        val tts = engine
        if (tts == null || !ready) { listener.onFinished(utteranceId, false); return }
        val lang = tts.setLanguage(settings.locale)
        if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault())
        tts.setSpeechRate(settings.speechRate)
        tts.setPitch(settings.pitch)
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, settings.volume) }
        listeners[utteranceId] = listener
        val result = tts.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        if (result == TextToSpeech.ERROR) listeners.remove(utteranceId)?.onFinished(utteranceId, false)
    }

    override fun stop() { engine?.stop() }

    override fun shutdown() {
        engine?.stop(); engine?.shutdown(); engine = null; ready = false; listeners.clear()
    }

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String) { listeners[utteranceId]?.onStart(utteranceId) }
        override fun onDone(utteranceId: String) { listeners.remove(utteranceId)?.onFinished(utteranceId, true) }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String) { listeners.remove(utteranceId)?.onFinished(utteranceId, false) }
        override fun onError(utteranceId: String, errorCode: Int) { listeners.remove(utteranceId)?.onFinished(utteranceId, false) }
        override fun onStop(utteranceId: String, interrupted: Boolean) { listeners.remove(utteranceId)?.onFinished(utteranceId, false) }
    }
}

/** Provider-agnostic speech output. A premium provider can later implement [TTSProvider] and be swapped in. */
class TTSManager(private val provider: TTSProvider, settings: VoiceSettings = VoiceSettings()) {
    private val counter = AtomicLong()
    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()
    @Volatile var settings: VoiceSettings = settings

    val isReady: Boolean get() = provider.isReady
    fun initialize(onResult: (Boolean) -> Unit) = provider.initialize(onResult)

    /** Suspends until speech finishes. Returns true only if it played to the end. Cancelling the caller stops speech. */
    suspend fun speak(text: String): Boolean = suspendCancellableCoroutine { cont ->
        if (!provider.isReady) { cont.resume(false); return@suspendCancellableCoroutine }
        val id = "jarvis-${counter.incrementAndGet()}"
        cont.invokeOnCancellation { provider.stop(); _speaking.value = false }
        provider.speak(text, id, settings, object : TTSProvider.UtteranceListener {
            override fun onStart(id: String) { _speaking.value = true }
            override fun onFinished(id: String, completed: Boolean) {
                _speaking.value = false
                if (cont.isActive) cont.resume(completed)
            }
        })
    }

    fun stop() = provider.stop()
    fun shutdown() { provider.shutdown(); _speaking.value = false }
}
