package com.jarvis.assistant.feature

import com.jarvis.assistant.feature.automation.AlarmTimeParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

class AlarmTimeParserTest {
    // Wednesday 7 Oct 2026, 20:00
    private val now = ZonedDateTime.of(2026, 10, 7, 20, 0, 0, 0, ZoneId.of("Asia/Kolkata"))
    private fun parse(s: String) = AlarmTimeParser.parse(s, now)
    private fun at(d: Int, h: Int, m: Int) = LocalDateTime.of(2026, 10, d, h, m)

    @Test fun explicitAm_rollsToTomorrow() {
        val p = parse("set an alarm for 6 am")!!
        assertEquals(at(8, 6, 0), p.dateTime.toLocalDateTime()); assertFalse(p.meridiemAssumed)
    }
    @Test fun dottedMeridiem() = assertEquals(at(8, 6, 0), parse("alarm for 6 a.m.")!!.dateTime.toLocalDateTime())
    @Test fun explicitPm_today() = assertEquals(at(7, 21, 0), parse("alarm at 9 pm")!!.dateTime.toLocalDateTime())
    @Test fun tomorrowAt730_assumesEarliest() {
        val p = parse("set an alarm for tomorrow at 7:30")!!
        assertEquals(at(8, 7, 30), p.dateTime.toLocalDateTime()); assertTrue(p.meridiemAssumed)
    }
    @Test fun wakeMeUpAtSix() = assertEquals(at(8, 6, 0), parse("wake me up at 6")!!.dateTime.toLocalDateTime())
    @Test fun twentyFourHour_pastRollsOver() = assertEquals(at(8, 18, 30), parse("alarm for 18:30")!!.dateTime.toLocalDateTime())
    @Test fun inTheMorning() = assertEquals(at(8, 6, 0), parse("alarm for 6 in the morning")!!.dateTime.toLocalDateTime())
    @Test fun explicitTodayPassedAmFallsToPm() = assertEquals(at(7, 21, 0), parse("alarm at 9 today")!!.dateTime.toLocalDateTime())
    @Test fun midnight() = assertEquals(at(8, 0, 0), parse("alarm at 12 am")!!.dateTime.toLocalDateTime())
    @Test fun noTime_returnsNull() = assertNull(parse("set an alarm"))
    @Test fun invalidHour_returnsNull() = assertNull(parse("alarm for 25:00"))
    @Test fun describe() {
        val dt = parse("alarm for 6 am")!!.dateTime
        assertEquals("6 AM tomorrow", AlarmTimeParser.describe(dt, now))
        assertEquals("7:30 AM tomorrow", AlarmTimeParser.describe(parse("alarm for 7:30 am")!!.dateTime, now))
    }
}
