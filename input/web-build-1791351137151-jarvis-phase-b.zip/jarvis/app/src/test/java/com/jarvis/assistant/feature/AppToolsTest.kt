package com.jarvis.assistant.feature

import com.jarvis.assistant.core.ai.FailureCode
import com.jarvis.assistant.core.permissions.AppPermission
import com.jarvis.assistant.core.permissions.PermissionChecker
import com.jarvis.assistant.feature.apps.AppInfo
import com.jarvis.assistant.feature.apps.AppMatch
import com.jarvis.assistant.feature.apps.AppRepository
import com.jarvis.assistant.feature.apps.AppResolver
import com.jarvis.assistant.feature.apps.LaunchStatus
import com.jarvis.assistant.feature.apps.OpenAppTool
import com.jarvis.assistant.feature.automation.AlarmScheduler
import com.jarvis.assistant.feature.automation.ScheduleResult
import com.jarvis.assistant.feature.automation.SetAlarmTool
import com.jarvis.assistant.feature.device.BatteryInfo
import com.jarvis.assistant.feature.device.BatteryInfoProvider
import com.jarvis.assistant.feature.device.BatteryTool
import com.jarvis.assistant.feature.device.ChargeState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.ZoneId

private val APPS = listOf(
    AppInfo("YouTube", "p.yt"), AppInfo("YouTube Music", "p.ytm"), AppInfo("WhatsApp", "p.wa"),
    AppInfo("Spotify", "p.sp"), AppInfo("Google Maps", "p.maps"), AppInfo("Google Chrome", "p.chrome"), AppInfo("Instagram", "p.ig")
)

class AppResolverTest {
    private fun found(q: String) = (AppResolver.resolve(q, APPS) as AppMatch.Found).app.label
    @Test fun exactBeatsPrefix() = assertEquals("YouTube", found("YouTube"))
    @Test fun spokenWithSpaces() = assertEquals("WhatsApp", found("what's app"))
    @Test fun prefix() = assertEquals("Instagram", found("insta"))
    @Test fun contains() = assertEquals("Google Maps", found("maps"))
    @Test fun fuzzyMisrecognition() = assertEquals("Spotify", found("spotfy"))
    @Test fun ambiguous() {
        val m = AppResolver.resolve("google", APPS) as AppMatch.Ambiguous
        assertEquals(listOf("Google Chrome", "Google Maps"), m.options.map { it.label })
    }
    @Test fun notInstalled() = assertTrue(AppResolver.resolve("netflix", APPS) is AppMatch.NotFound)
    @Test fun blankQuery() = assertTrue(AppResolver.resolve("  ", APPS) is AppMatch.NotFound)
}

class OpenAppToolTest {
    private class Repo(val status: LaunchStatus) : AppRepository {
        var launched: String? = null
        override fun launchableApps() = APPS
        override fun launch(packageName: String): LaunchStatus { launched = packageName; return status }
    }
    @Test fun launches() = runBlocking {
        val repo = Repo(LaunchStatus.DISPATCHED)
        val r = OpenAppTool(repo).execute(mapOf("app" to "spotify"))
        assertTrue(r.success); assertEquals("Spotify", r.target); assertEquals("p.sp", repo.launched)
    }
    @Test fun notInstalled_doesNotLaunch() = runBlocking {
        val repo = Repo(LaunchStatus.DISPATCHED)
        val r = OpenAppTool(repo).execute(mapOf("app" to "netflix"))
        assertFalse(r.success); assertEquals(FailureCode.NOT_FOUND, r.failureCode); assertNull(repo.launched)
    }
    @Test fun androidRefuses() = runBlocking {
        val r = OpenAppTool(Repo(LaunchStatus.FAILED)).execute(mapOf("app" to "youtube"))
        assertFalse(r.success); assertEquals(FailureCode.LAUNCH_FAILED, r.failureCode)
    }
    @Test fun missingArgument() = runBlocking {
        assertEquals(FailureCode.INVALID_ARGUMENTS, OpenAppTool(Repo(LaunchStatus.DISPATCHED)).execute(emptyMap()).failureCode)
    }
}

class BatteryToolTest {
    private class P(val info: BatteryInfo?) : BatteryInfoProvider { override fun read() = info }
    @Test fun reportsPercentAndState() = runBlocking {
        val r = BatteryTool(P(BatteryInfo(78, ChargeState.CHARGING, "USB"))).execute(emptyMap())
        assertTrue(r.success); assertEquals("78", r.data["percent"]); assertEquals("CHARGING", r.data["state"])
    }
    @Test fun unavailable() = runBlocking {
        val r = BatteryTool(P(null)).execute(emptyMap())
        assertFalse(r.success); assertEquals(FailureCode.UNAVAILABLE, r.failureCode)
    }
    @Test fun fromRaw_scalesAndMapsStatus() {
        val i = BatteryInfo.fromRaw(level = 39, scale = 50, status = 2 /*CHARGING*/, plugged = 2 /*USB*/)!!
        assertEquals(78, i.percent); assertEquals(ChargeState.CHARGING, i.state); assertEquals("USB", i.source)
        assertNull(BatteryInfo.fromRaw(-1, 100, 2, 0))
        assertEquals(ChargeState.DISCHARGING, BatteryInfo.fromRaw(50, 100, 3, 0)!!.state)
    }
}

class SetAlarmToolTest {
    private val clock = Clock.fixed(Instant.parse("2026-10-07T14:30:00Z"), ZoneId.of("Asia/Kolkata")) // 20:00 local
    private class Perms(val denied: Set<AppPermission> = emptySet()) : PermissionChecker {
        override fun isGranted(permission: AppPermission) = permission !in denied
    }
    private class Sched(val result: ScheduleResult = ScheduleResult.SCHEDULED, val verified: Boolean = true) : AlarmScheduler {
        var scheduledAt: Long? = null
        override fun schedule(triggerAtMillis: Long): ScheduleResult { scheduledAt = triggerAtMillis; return result }
        override fun isScheduled(triggerAtMillis: Long) = verified
    }
    private fun tool(s: Sched, p: Perms = Perms()) = SetAlarmTool(s, p, clock)

    @Test fun schedulesAndReports() = runBlocking {
        val s = Sched()
        val r = tool(s).execute(mapOf("time" to "set an alarm for 6 am"))
        assertTrue(r.success); assertEquals("6 AM tomorrow", r.data["display"])
        assertEquals(Instant.parse("2026-10-08T00:30:00Z").toEpochMilli(), s.scheduledAt)
    }
    @Test fun exactAlarmPermissionMissing_doesNotSchedule() = runBlocking {
        val s = Sched()
        val r = tool(s, Perms(setOf(AppPermission.EXACT_ALARM))).execute(mapOf("time" to "6 am"))
        assertFalse(r.success); assertEquals("EXACT_ALARM", r.requiresPermission); assertNull(s.scheduledAt)
    }
    @Test fun notificationPermissionMissing() = runBlocking {
        val r = tool(Sched(), Perms(setOf(AppPermission.POST_NOTIFICATIONS))).execute(mapOf("time" to "6 am"))
        assertEquals("POST_NOTIFICATIONS", r.requiresPermission)
    }
    @Test fun unverifiedAlarmIsNotReportedAsSuccess() = runBlocking {
        val r = tool(Sched(verified = false)).execute(mapOf("time" to "6 am"))
        assertFalse(r.success)
    }
    @Test fun systemRefusal() = runBlocking {
        assertFalse(tool(Sched(ScheduleResult.FAILED)).execute(mapOf("time" to "6 am")).success)
    }
    @Test fun unparseableTime() = runBlocking {
        assertEquals(FailureCode.INVALID_ARGUMENTS, tool(Sched()).execute(mapOf("time" to "soon")).failureCode)
    }
}
