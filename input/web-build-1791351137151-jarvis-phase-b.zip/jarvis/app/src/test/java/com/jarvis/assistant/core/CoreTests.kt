package com.jarvis.assistant.core

import com.jarvis.assistant.core.ai.AIProvider
import com.jarvis.assistant.core.ai.AIReply
import com.jarvis.assistant.core.ai.AiException
import com.jarvis.assistant.core.ai.ChatMessage
import com.jarvis.assistant.core.ai.FailureCode
import com.jarvis.assistant.core.ai.OpenAiRequestBuilder
import com.jarvis.assistant.core.ai.OpenAiResponseParser
import com.jarvis.assistant.core.ai.Tool
import com.jarvis.assistant.core.ai.ToolCall
import com.jarvis.assistant.core.ai.ToolRegistry
import com.jarvis.assistant.core.ai.ToolResult
import com.jarvis.assistant.core.brain.Confirmation
import com.jarvis.assistant.core.brain.ConfirmationParser
import com.jarvis.assistant.core.brain.JarvisBrain
import com.jarvis.assistant.core.brain.LocalIntentParser
import com.jarvis.assistant.core.brain.Outcome
import com.jarvis.assistant.core.security.SecurityDecision
import com.jarvis.assistant.core.security.SecurityEngine
import com.jarvis.assistant.core.security.SecurityLevel
import com.jarvis.assistant.feature.device.BatteryInfo
import com.jarvis.assistant.feature.device.BatteryInfoProvider
import com.jarvis.assistant.feature.device.BatteryTool
import com.jarvis.assistant.feature.device.ChargeState
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

private class FakeTool(
    override val name: String,
    override val securityLevel: SecurityLevel,
    private val result: ToolResult = ToolResult(true, actionPerformed = "ran")
) : Tool {
    var runs = 0
    override val description = "do the $name thing"
    override val parameters = emptyMap<String, String>()
    override suspend fun execute(args: Map<String, String>): ToolResult { runs++; return result }
}

private class ScriptedProvider(private val reply: () -> AIReply) : AIProvider {
    var calls = 0
    override suspend fun complete(messages: List<ChatMessage>, tools: List<Tool>): AIReply { calls++; return reply() }
}

class SecurityEngineTest {
    private val e = SecurityEngine()
    @Test fun levels() {
        assertEquals(SecurityDecision.ALLOW, e.evaluate(SecurityLevel.LOW))
        assertEquals(SecurityDecision.ALLOW, e.evaluate(SecurityLevel.MEDIUM))
        assertEquals(SecurityDecision.CONFIRM, e.evaluate(SecurityLevel.HIGH))
        assertEquals(SecurityDecision.CONFIRM_STRICT, e.evaluate(SecurityLevel.CRITICAL))
    }
    @Test fun highAndCriticalNeedConfirmation() {
        assertTrue(SecurityLevel.HIGH.needsConfirmation); assertTrue(SecurityLevel.CRITICAL.needsConfirmation)
        assertFalse(SecurityLevel.LOW.needsConfirmation); assertFalse(SecurityLevel.MEDIUM.needsConfirmation)
    }
}

class ToolRegistryTest {
    @Test fun unknownTool() = runBlocking {
        assertEquals(FailureCode.UNKNOWN_TOOL, ToolRegistry().run("nope", emptyMap()).failureCode)
    }
    @Test fun highRiskBlockedUntilConfirmed() = runBlocking {
        val t = FakeTool("send", SecurityLevel.HIGH)
        val reg = ToolRegistry().apply { register(t) }
        val blocked = reg.run("send", emptyMap())
        assertTrue(blocked.requiresConfirmation); assertEquals(0, t.runs)
        assertTrue(reg.run("send", emptyMap(), confirmed = true).success); assertEquals(1, t.runs)
    }
    @Test fun lowRiskRunsDirectly() = runBlocking {
        val t = FakeTool("peek", SecurityLevel.LOW)
        assertTrue(ToolRegistry().apply { register(t) }.run("peek", emptyMap()).success)
    }
    @Test fun toolExceptionBecomesFailure() = runBlocking {
        val boom = object : Tool {
            override val name = "boom"; override val description = ""; override val parameters = emptyMap<String, String>()
            override val securityLevel = SecurityLevel.LOW
            override suspend fun execute(args: Map<String, String>): ToolResult = throw IllegalStateException("x")
        }
        val r = ToolRegistry().apply { register(boom) }.run("boom", emptyMap())
        assertFalse(r.success); assertEquals(FailureCode.EXECUTION_ERROR, r.failureCode)
    }
}

class LocalIntentParserTest {
    private val p = LocalIntentParser()
    @Test fun battery() {
        listOf("What's my battery?", "Jarvis, how much battery do I have", "Is my phone charging?")
            .forEach { assertEquals(it, "getBattery", p.parse(it)?.name) }
    }
    @Test fun openApp() {
        assertEquals(ToolCall("openApp", mapOf("app" to "youtube")), p.parse("Open YouTube."))
        assertEquals("whatsapp", p.parse("Launch WhatsApp")!!.args["app"])
        assertEquals("spotify", p.parse("Jarvis, can you open the Spotify app?")!!.args["app"])
    }
    @Test fun alarm() {
        assertEquals("setAlarm", p.parse("Set an alarm for 6 AM.")!!.name)
        assertTrue(p.parse("Set an alarm for 6 AM.")!!.args["time"]!!.contains("6 am"))
        assertEquals("setAlarm", p.parse("Wake me up at 6")!!.name)
    }
    @Test fun notLocal() {
        assertNull(p.parse("What's the capital of France?"))
        assertNull(p.parse("Cancel my alarm"))
        assertNull(p.parse("open"))
    }
}

class ConfirmationParserTest {
    @Test fun parses() {
        assertEquals(Confirmation.YES, ConfirmationParser.parse("Yes, please."))
        assertEquals(Confirmation.YES, ConfirmationParser.parse("go ahead sir"))
        assertEquals(Confirmation.STRICT_YES, ConfirmationParser.parse("Confirm."))
        assertEquals(Confirmation.NO, ConfirmationParser.parse("no"))
        assertEquals(Confirmation.NO, ConfirmationParser.parse("never mind"))
        assertEquals(Confirmation.UNRELATED, ConfirmationParser.parse("what's my battery"))
    }
}

class OpenAiParsingTest {
    @Test fun textReply() {
        val r = OpenAiResponseParser.parse("""{"choices":[{"message":{"role":"assistant","content":"Hello, sir."}}]}""")
        assertEquals("Hello, sir.", r.text); assertNull(r.toolCall)
    }
    @Test fun toolCallWithStringArguments() {
        val body = """{"choices":[{"message":{"content":null,"tool_calls":[{"type":"function","function":{"name":"openApp","arguments":"{\"app\":\"YouTube\"}"}}]}}]}"""
        val r = OpenAiResponseParser.parse(body)
        assertNull(r.text); assertEquals(ToolCall("openApp", mapOf("app" to "YouTube")), r.toolCall)
    }
    @Test fun emptyArguments() {
        val body = """{"choices":[{"message":{"content":null,"tool_calls":[{"function":{"name":"getBattery","arguments":""}}]}}]}"""
        assertEquals(emptyMap<String, String>(), OpenAiResponseParser.parse(body).toolCall!!.args)
    }
    @Test fun malformed() {
        listOf("not json", """{"choices":[]}""", """{"x":1}""",
            """{"choices":[{"message":{"tool_calls":[{"function":{"name":"a","arguments":"{bad"}}]}}]}""").forEach {
            try { OpenAiResponseParser.parse(it); fail("expected Malformed for $it") } catch (e: AiException.Malformed) { /* ok */ }
        }
    }
    @Test fun httpMapping() {
        assertTrue(AiException.fromHttp(401) is AiException.InvalidKey)
        assertTrue(AiException.fromHttp(403) is AiException.InvalidKey)
        assertTrue(AiException.fromHttp(429) is AiException.RateLimited)
        assertTrue(AiException.fromHttp(503) is AiException.Server)
        assertTrue(AiException.fromHttp(400) is AiException.BadRequest)
    }
    @Test fun requestContainsToolSchemaAndNoSecrets() {
        val body = OpenAiRequestBuilder.build("m", listOf(ChatMessage("user", "hi")), listOf(FakeTool("peek", SecurityLevel.LOW)))
        assertTrue(body.contains("\"name\":\"peek\"")); assertTrue(body.contains("\"model\":\"m\""))
        assertFalse(body.contains("Bearer"))
    }
}

class JarvisBrainTest {
    private var clock = 0L
    private fun brain(reg: ToolRegistry, provider: AIProvider? = null) =
        JarvisBrain(reg, providerSupplier = { provider }, nowMs = { clock })
    private class Bat(val info: BatteryInfo?) : BatteryInfoProvider { override fun read() = info }

    @Test fun localBatteryWorksWithoutApiKey() = runBlocking {
        val reg = ToolRegistry().apply { register(BatteryTool(Bat(BatteryInfo(78, ChargeState.CHARGING, "USB")))) }
        val r = brain(reg).process("Jarvis, what's my battery?")
        assertEquals(Outcome.EXECUTED, r.outcome); assertTrue(r.text, r.text.contains("78 percent"))
    }
    @Test fun noApiKeyForNonLocalRequest() = runBlocking {
        val r = brain(ToolRegistry()).process("tell me a joke")
        assertEquals("I need an AI provider API key before I can process that request.", r.text)
    }
    @Test fun aiAnswerWithoutToolIsReturned() = runBlocking {
        val r = brain(ToolRegistry(), ScriptedProvider { AIReply("Paris, sir.", null) }).process("capital of France?")
        assertEquals(Outcome.ANSWERED, r.outcome); assertEquals("Paris, sir.", r.text)
    }
    @Test fun aiCannotCallUnregisteredTools() = runBlocking {
        val r = brain(ToolRegistry(), ScriptedProvider { AIReply(null, ToolCall("rm -rf /", emptyMap())) }).process("do something")
        assertEquals(Outcome.UNKNOWN, r.outcome); assertEquals("I'm not quite sure what you'd like me to do, sir.", r.text)
    }
    @Test fun networkFailureMessage() = runBlocking {
        val r = brain(ToolRegistry(), ScriptedProvider { throw AiException.Network() }).process("hello there")
        assertEquals("I'm unable to reach the AI service right now, sir.", r.text)
    }
    @Test fun highRiskNeedsConfirmationThenRunsOnYes() = runBlocking {
        val t = FakeTool("sendMessage", SecurityLevel.HIGH)
        val b = brain(ToolRegistry().apply { register(t) }, ScriptedProvider { AIReply(null, ToolCall("sendMessage", emptyMap())) })
        assertEquals(Outcome.NEEDS_CONFIRMATION, b.process("message mom").outcome); assertEquals(0, t.runs)
        assertEquals(Outcome.EXECUTED, b.process("yes").outcome); assertEquals(1, t.runs)
    }
    @Test fun declineCancels() = runBlocking {
        val t = FakeTool("sendMessage", SecurityLevel.HIGH)
        val b = brain(ToolRegistry().apply { register(t) }, ScriptedProvider { AIReply(null, ToolCall("sendMessage", emptyMap())) })
        b.process("message mom")
        assertEquals(Outcome.CANCELLED, b.process("no").outcome); assertEquals(0, t.runs)
    }
    @Test fun criticalNeedsExplicitConfirm() = runBlocking {
        val t = FakeTool("wipe", SecurityLevel.CRITICAL)
        val b = brain(ToolRegistry().apply { register(t) }, ScriptedProvider { AIReply(null, ToolCall("wipe", emptyMap())) })
        b.process("wipe it")
        assertEquals(Outcome.NEEDS_CONFIRMATION, b.process("yes").outcome); assertEquals(0, t.runs)
        assertEquals(Outcome.EXECUTED, b.process("confirm").outcome); assertEquals(1, t.runs)
    }
    @Test fun confirmationExpires() = runBlocking {
        val t = FakeTool("sendMessage", SecurityLevel.HIGH)
        val provider = ScriptedProvider { AIReply("Noted.", null) }
        val b = brain(ToolRegistry().apply { register(t) }, ScriptedProvider { AIReply(null, ToolCall("sendMessage", emptyMap())) })
        b.process("message mom")
        clock += 61_000
        val r = b.process("yes")           // expired -> treated as a new command, tool must not run
        assertEquals(0, t.runs); assertNotNull(r)
    }
    @Test fun failedToolIsNeverReportedAsSuccess() = runBlocking {
        val bad = FakeTool("flaky", SecurityLevel.LOW, ToolResult(false, failureCode = FailureCode.EXECUTION_ERROR))
        val b = brain(ToolRegistry().apply { register(bad) }, ScriptedProvider { AIReply(null, ToolCall("flaky", emptyMap())) })
        val r = b.process("do flaky")
        assertEquals(Outcome.FAILED, r.outcome); assertEquals("I couldn't complete that action, sir.", r.text)
        assertFalse(r.text.contains("Done"))
    }
    @Test fun permissionRequestSurfaced() = runBlocking {
        val needs = FakeTool("alarmish", SecurityLevel.MEDIUM,
            ToolResult(false, requiresPermission = "EXACT_ALARM", failureCode = FailureCode.PERMISSION_REQUIRED))
        val b = brain(ToolRegistry().apply { register(needs) }, ScriptedProvider { AIReply(null, ToolCall("alarmish", emptyMap())) })
        val r = b.process("do alarmish")
        assertEquals(Outcome.NEEDS_PERMISSION, r.outcome); assertNotNull(r.permission)
    }
}
